#include <pebble.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <limits.h>
#include "dashboard.h"
#include "dashboard_deadline.h"

#define SCREEN_W 200
#define SCREEN_H 228
#define CONTENT_W (SCREEN_W - ACTION_BAR_WIDTH)
#define FONT_COUNT 13
#define VIEW_TIMEOUT_MS 6000
#define ACTION_TIMEOUT_MS 12000
#define OUTBOX_CAPACITY 4
#define GUIDE_SEEN_KEY 1
#define THEME_DARK_KEY 2
#define HOLD_PREVIEW_MS 250

typedef struct {uint8_t op,mode,action,confirm;uint16_t offset,index;uint32_t request,token,version;} Outbound;
typedef struct {uint32_t request,token,version;uint8_t action,result;char text[65];bool active,confirmation,ended;} Command;
static Window *s_window;
static Layer *s_canvas;
static DbState s_state;
static uint32_t s_counter;
static Outbound s_queue[OUTBOX_CAPACITY];
static uint8_t s_queue_count;
static bool s_sending,s_focused=true,s_has_connection=true;
static Command s_command;
static AppTimer *s_view_timeout,*s_action_timeout,*s_repeat,*s_hold_timer;
static DbDeadline s_expiry;
static bool s_guide,s_select_down,s_hold_preview,s_hold_intent,s_confirm_accept;
#ifndef DASHBOARD_FIXTURE
static bool s_saved_dark;
#endif
static int s_repeat_delta;
static bool s_repeat_held;
static uint32_t s_press_token,s_press_version;
static uint8_t s_press_mode;
static GFont s_fonts[FONT_COUNT];
static uint8_t s_tick_seconds;
static unsigned s_last_minute;
static uint32_t s_last_tick;
static const uint8_t s_font_points[]={11,12,14,16,20,24,20,24,26,28,32,40,18};
static const uint32_t s_font_ids[]={RESOURCE_ID_FONT_BODY_11,RESOURCE_ID_FONT_BODY_12,RESOURCE_ID_FONT_BODY_14,
  RESOURCE_ID_FONT_BODY_16,RESOURCE_ID_FONT_BODY_20,RESOURCE_ID_FONT_BODY_24,
  RESOURCE_ID_FONT_CLOCK_20,RESOURCE_ID_FONT_CLOCK_24,RESOURCE_ID_FONT_CLOCK_26,
  RESOURCE_ID_FONT_BODY_28,RESOURCE_ID_FONT_CLOCK_32,RESOURCE_ID_FONT_CLOCK_40,RESOURCE_ID_FONT_BODY_18};

static uint32_t utc_now(void){return (uint32_t)time(NULL);}
static uint32_t next_request(void){s_counter=s_counter>=INT32_MAX?1:s_counter+1;return s_counter;}
static void repaint(void){if(s_canvas&&s_focused)layer_mark_dirty(s_canvas);}
static void update_ticks(void);
static void configure_clicks(void *context);
static void send_queued(void);
static void stop_repeat(void);
static void request_view(uint8_t mode,uint16_t offset,uint16_t index,uint32_t token,bool hello);
static const DbItem *pressed_item(void);
static bool control_available(const DbItem *item,unsigned index);
static void cancel_hold_preview(void){
  if(s_hold_timer){app_timer_cancel(s_hold_timer);s_hold_timer=NULL;}
  if(s_hold_preview){s_hold_preview=false;repaint();}
}
static const DbItem *preview_item(void){
  const DbItem *item=pressed_item();
  return s_hold_preview&&s_select_down&&!s_guide&&!s_command.confirmation&&s_has_connection&&
    db_item_capability_current(item,utc_now())&&(item->flags&DB_APP)?item:NULL;
}
static GColor background(void){return s_state.snapshot.dark?GColorBlack:GColorWhite;}
static GColor foreground(void){return s_state.snapshot.dark?GColorWhite:GColorBlack;}
static GColor muted(void){return s_state.snapshot.dark?GColorLightGray:GColorDarkGray;}
static GColor stroke(void){return s_state.snapshot.dark?GColorDarkGray:GColorLightGray;}
static GColor accent(void){return s_state.snapshot.dark?GColorTiffanyBlue:GColorJaegerGreen;}
static GFont font_at(unsigned index){
  if(index>=FONT_COUNT)index=3;
  if(!s_fonts[index])s_fonts[index]=fonts_load_custom_font(resource_get_handle(s_font_ids[index]));
  return s_fonts[index]?s_fonts[index]:fonts_get_system_font(FONT_KEY_GOTHIC_18_BOLD);
}
static unsigned body_index(unsigned point){return point<=11?0:point<=12?1:point<=14?2:point<=16?3:point<=18?12:point<=20?4:point<=24?5:9;}
static int width_of(const char *value,unsigned index){
  return graphics_text_layout_get_content_size(value,font_at(index),GRect(0,0,2048,512),GTextOverflowModeFill,GTextAlignmentLeft).w;
}
static void pop_utf8(char *text){size_t n=strlen(text);if(!n)return;do{n--;}while(n&&((unsigned char)text[n]&0xc0)==0x80);text[n]=0;}
static void clean_text(char *out,size_t size,const char *value){
  if(!size)return;
  snprintf(out,size,"%s",value?value:"");
  for(char *p=out;*p;p++)if(*p=='\n'||*p=='\r'||*p=='\t')*p=' ';
}
static void draw_text(GContext *ctx,const char *value,unsigned index,int x,int baseline,int width,GColor color,GTextAlignment alignment){
  if(width<=0)return;
  char text[265];clean_text(text,sizeof(text),value);
  if(width_of(text,index)>width){
    while(text[0]){pop_utf8(text);size_t n=strlen(text);if(n+4>=sizeof(text))continue;memcpy(text+n,"…",4);
      if(width_of(text,index)<=width)break;
      text[n]=0;}
  }
  graphics_context_set_text_color(ctx,color);
  graphics_draw_text(ctx,text,font_at(index),GRect(x,baseline-s_font_points[index],width,s_font_points[index]+12),GTextOverflowModeFill,alignment,NULL);
}
static void text(GContext *ctx,const char *value,unsigned point,int x,int baseline,int width,GColor color){draw_text(ctx,value,body_index(point),x,baseline,width,color,GTextAlignmentLeft);}
static void centered(GContext *ctx,const char *value,unsigned point,int baseline,GColor color){draw_text(ctx,value,body_index(point),6,baseline,CONTENT_W-12,color,GTextAlignmentCenter);}
static bool clock_chars(const char *text){
  const unsigned char *p=(const unsigned char *)text;
  while(*p){
    if((*p>='0'&&*p<='9')||*p==':'||*p=='.'||*p==','||*p=='%'||*p=='-'||*p=='+'||*p=='C'||*p=='F'){p++;continue;}
    if(p[0]==0xc2&&p[1]==0xb0){p+=2;continue;}
    if(p[0]==0xe2&&p[1]&&p[1]==0x88&&p[2]==0x92){p+=3;continue;}
    return false;
  }
  return true;
}
static void value_text(GContext *ctx,const char *value,int x,int baseline,int width,unsigned preferred,GColor color,GTextAlignment align){
  static const unsigned clocks[]={11,10,8,7,6},bodies[]={9,5,4};
  const unsigned *choices=clock_chars(value)?clocks:bodies;unsigned count=clock_chars(value)?5:3;
  for(unsigned i=0;i<count;i++){unsigned index=choices[i];if(s_font_points[index]<=preferred&&width_of(value,index)<=width){draw_text(ctx,value,index,x,baseline,width,color,align);return;}}
  draw_text(ctx,"Too long",4,x,baseline,width,color,align);
}
static void fill(GContext *ctx,GRect bounds,GColor color,int radius){graphics_context_set_fill_color(ctx,color);graphics_fill_rect(ctx,bounds,radius,GCornersAll);}
static void edge(GContext *ctx,GRect bounds,GColor color,int radius){graphics_context_set_stroke_color(ctx,color);graphics_context_set_stroke_width(ctx,1);graphics_draw_round_rect(ctx,bounds,radius);}
static void segment(GContext *ctx,int x,int y,int x2,int y2,GColor color){graphics_context_set_stroke_color(ctx,color);graphics_context_set_stroke_width(ctx,1);graphics_draw_line(ctx,GPoint(x,y),GPoint(x2,y2));}
static bool item_selected(const DbItem *item){return item&&s_state.selected_token==item->token&&!s_state.loading&&!s_state.selection_lost;}
static GColor panel(GContext *ctx,const DbItem *item,GRect bounds,bool outlined){
  if(item_selected(item)){fill(ctx,bounds,foreground(),4);return background();}
  if(outlined)edge(ctx,bounds,stroke(),4);
  return foreground();
}
static void symbol(GContext *ctx,uint8_t kind,int x,int y,int size,GColor color){
  graphics_context_set_stroke_color(ctx,color);graphics_context_set_fill_color(ctx,color);graphics_context_set_stroke_width(ctx,size>=18?2:1);
  int a=size/5,b=size-a,c=size/2;
  switch(kind){
    case DB_TIMER:
      graphics_draw_line(ctx,GPoint(x+a,y+1),GPoint(x+b,y+1));graphics_draw_line(ctx,GPoint(x+a,y+size-1),GPoint(x+b,y+size-1));
      graphics_draw_line(ctx,GPoint(x+a,y+2),GPoint(x+a,y+size/4));graphics_draw_line(ctx,GPoint(x+b,y+2),GPoint(x+b,y+size/4));
      graphics_draw_line(ctx,GPoint(x+a,y+size/4),GPoint(x+b,y+size*3/4));graphics_draw_line(ctx,GPoint(x+b,y+size/4),GPoint(x+a,y+size*3/4));
      graphics_draw_line(ctx,GPoint(x+a,y+size*3/4),GPoint(x+a,y+size-2));graphics_draw_line(ctx,GPoint(x+b,y+size*3/4),GPoint(x+b,y+size-2));break;
    case DB_MUSIC:
      graphics_draw_line(ctx,GPoint(x+c-2,y+size*3/4),GPoint(x+c-2,y+3));graphics_draw_line(ctx,GPoint(x+c-2,y+3),GPoint(x+b,y+1));
      graphics_draw_line(ctx,GPoint(x+b,y+1),GPoint(x+b,y+size*2/3));graphics_fill_circle(ctx,GPoint(x+c-4,y+size*3/4),size/6);graphics_fill_circle(ctx,GPoint(x+b-2,y+size*2/3),size/6);break;
    case DB_PHONE:case DB_FIND:
      graphics_draw_round_rect(ctx,GRect(x+a,y+1,size-2*a,size-2),1);graphics_draw_line(ctx,GPoint(x+c-1,y+size-4),GPoint(x+c+1,y+size-4));
      if(kind==DB_FIND){graphics_draw_line(ctx,GPoint(x,y+a),GPoint(x,y+b));graphics_draw_line(ctx,GPoint(x+size,y+a),GPoint(x+size,y+b));}break;
    case DB_NOTICE:
      graphics_draw_rect(ctx,GRect(x+1,y+1,size-2,size*2/3));graphics_draw_line(ctx,GPoint(x+3,y+size*2/3),GPoint(x+3,y+size-1));graphics_draw_line(ctx,GPoint(x+3,y+size-1),GPoint(x+c,y+size*2/3));
      graphics_draw_line(ctx,GPoint(x+4,y+4),GPoint(x+size-4,y+4));break;
    case DB_WEATHER:
      graphics_draw_circle(ctx,GPoint(x+size/3,y+size/3),size/4);graphics_draw_round_rect(ctx,GRect(x+size/4,y+c,size*3/4,size/3),size/6);break;
    case DB_BATTERY:
      graphics_draw_rect(ctx,GRect(x,y+size/4,size-2,size/2));graphics_fill_rect(ctx,GRect(x+size-2,y+c-1,2,3),0,GCornerNone);
      graphics_fill_rect(ctx,GRect(x+3,y+size/4+3,size/2,size/2-5),0,GCornerNone);break;
    case DB_LIGHT:
      graphics_draw_circle(ctx,GPoint(x+c,y+size/3),size/3);graphics_draw_line(ctx,GPoint(x+size/3,y+size*2/3),GPoint(x+size*2/3,y+size*2/3));graphics_draw_line(ctx,GPoint(x+size/3,y+size-1),GPoint(x+size*2/3,y+size-1));break;
    case DB_NAVIGATION:
      graphics_draw_line(ctx,GPoint(x+a,y+b),GPoint(x+a,y+c));graphics_draw_line(ctx,GPoint(x+a,y+c),GPoint(x+b,y+c));graphics_draw_line(ctx,GPoint(x+c,y+a),GPoint(x+b,y+c));graphics_draw_line(ctx,GPoint(x+c,y+b),GPoint(x+b,y+c));break;
    case DB_CALENDAR:
      graphics_draw_rect(ctx,GRect(x+1,y+3,size-2,size-4));graphics_draw_line(ctx,GPoint(x+1,y+size/3),GPoint(x+size-1,y+size/3));break;
    case DB_WORKOUT:
      graphics_fill_circle(ctx,GPoint(x+c,y+2),2);graphics_draw_line(ctx,GPoint(x+c,y+5),GPoint(x+c-3,y+c+2));graphics_draw_line(ctx,GPoint(x+c-3,y+c+2),GPoint(x+b,y+size-1));graphics_draw_line(ctx,GPoint(x+c-3,y+c+2),GPoint(x+a,y+size-1));graphics_draw_line(ctx,GPoint(x+a,y+c),GPoint(x+b,y+c));break;
    default:
      graphics_draw_circle(ctx,GPoint(x+c,y+c),size/3);graphics_fill_circle(ctx,GPoint(x+c,y+c),size/7);break;
  }
  graphics_context_set_stroke_width(ctx,1);
}
static void picture(GContext *ctx,const DbItem *item,int x,int y,int size,GColor fallback){
  if(!item->width||!item->height||!db_item_current(item,utc_now())){symbol(ctx,item->kind,x,y,size,fallback);return;}
  unsigned stride=(item->width+1)/2;
  for(int row=0;row<size;row++){
    unsigned source_y=(unsigned)row*item->height/size;int start=0;uint8_t previous=0;
    for(int col=0;col<=size;col++){
      uint8_t color=0;
      if(col<size){unsigned source_x=(unsigned)col*item->width/size;uint8_t value=item->pixels[source_y*stride+source_x/2];unsigned index=source_x&1?value&15:value>>4;color=item->palette[index];}
      if(col==size||color!=previous){if(previous&0xc0)fill(ctx,GRect(x+start,y+row,col-start,1),(GColor){.argb=previous},0);previous=color;start=col;}
    }
  }
}
static const char *status_text(void){
  if(!s_has_connection)return "Connect your phone";
  switch(s_state.snapshot.status){case DB_PERMISSION:return "Allow access on phone";case DB_ERROR:return "Data unavailable";case DB_OFFLINE:return "Connect your phone";case DB_LOADING:return "Loading sources…";default:return "Nothing here yet";}
}
static const char *command_error(void){
  if(!s_command.active||s_command.confirmation)return NULL;
  switch(s_command.result){
    case DB_DENIED:return "Allow access";
    case DB_STALE:return "Item changed";
    case DB_FAILED:return s_command.text[0]?s_command.text:"Action failed";
    case DB_CANCELLED:return "Cancelled";
    default:return NULL;
  }
}
static void header(GContext *ctx){
  const DbItem *preview=preview_item(),*item=db_selected(&s_state);const char *status=NULL;
  char context[40];context[0]=0;
  if(preview)status=preview->app_label;
  else if(!s_has_connection||s_state.snapshot.status==DB_OFFLINE)status="Offline";
  else if(command_error())status=command_error();
  else if(item&&item->role==DB_ROLE_PIN&&!db_item_current(item,utc_now()))status=(item->flags&DB_UNAVAILABLE)&&item->subtitle[0]?item->subtitle:"No data";
  else if(item&&s_state.desired_mode==DB_MEDIA&&db_control_present(item,s_state.focus)&&!control_available(item,s_state.focus))status="Unavailable";
  const char *title=s_guide?"Buttons":s_command.confirmation?"Confirm":s_state.desired_mode==DB_ACTIVITIES?"Activities":s_state.desired_mode==DB_PINNED?"Pinned":s_state.desired_mode==DB_MEDIA?"Controls":"Dashboard";
  if(!status&&(s_state.desired_mode==DB_ACTIVITIES||s_state.desired_mode==DB_PINNED)){
    if(s_state.loading)snprintf(context,sizeof(context),"Loading…");else snprintf(context,sizeof(context),"%u / %u",s_state.snapshot.total?s_state.selected_index+1:0,s_state.snapshot.total);status=context;
  }
  if(status){text(ctx,title,12,6,11,98,muted());text(ctx,status,18,6,27,98,foreground());}
  else text(ctx,title,20,6,22,98,foreground());
  char right[16];time_t now=time(NULL);struct tm *local=localtime(&now);
  strftime(right,sizeof(right),clock_is_24h_style()?"%H:%M":"%I:%M",local);
  if(!clock_is_24h_style()&&right[0]=='0')memmove(right,right+1,strlen(right));
  draw_text(ctx,right,4,108,22,CONTENT_W-114,muted(),GTextAlignmentRight);segment(ctx,5,28,CONTENT_W-5,28,stroke());
}
static bool control_available(const DbItem *item,unsigned index){const uint16_t bits[]={DB_MEDIA_PREVIOUS,DB_MEDIA_TOGGLE,DB_MEDIA_NEXT};return item&&index<3&&(item->flags&bits[index])&&db_item_actionable(item,utc_now());}
static void item_value(const DbItem *item,char *value,size_t size){
  if(item->flags&DB_LOCAL_WATCH){BatteryChargeState battery=battery_state_service_peek();snprintf(value,size,"%u%%",battery.charge_percent);return;}
  db_item_value(item,utc_now(),value,size);
}
static void activity_main(GContext *ctx,const DbItem *item){
  GColor ink=panel(ctx,item,GRect(4,29,CONTENT_W-8,73),false);
  if(!db_item_current(item,utc_now())){text(ctx,"Activity unavailable",20,10,73,CONTENT_W-20,ink);return;}
  if(item->flags&DB_IS_MEDIA){
    char title[193],identity[144];clean_text(title,sizeof(title),item->title);db_item_media_identity(item,identity,sizeof(identity));unsigned split=0;
    if(width_of(title,5)>CONTENT_W-20){for(unsigned i=0;title[i];i++)if(title[i]==' '){char saved=title[i];title[i]=0;if(width_of(title,5)<=CONTENT_W-20)split=i;title[i]=saved;}}
    if(split){char first[193];memcpy(first,title,split);first[split]=0;text(ctx,first,24,10,54,CONTENT_W-20,ink);text(ctx,title+split+1,24,10,77,CONTENT_W-20,ink);picture(ctx,item,10,80,20,ink);text(ctx,identity,20,37,100,CONTENT_W-47,ink);}
    else{text(ctx,title,24,10,59,CONTENT_W-20,ink);picture(ctx,item,10,65,32,ink);text(ctx,identity,20,50,91,CONTENT_W-60,ink);}
  }else{
    char value[64];item_value(item,value,sizeof(value));
    if(value[0])value_text(ctx,value,10,76,CONTENT_W-20,item->clock_mode?40:32,ink,GTextAlignmentLeft);
    else text(ctx,item->title[0]?item->title:item->name,28,10,69,CONTENT_W-20,ink);
    picture(ctx,item,10,79,20,ink);text(ctx,value[0]?(item->title[0]?item->title:item->name):item->subtitle,20,37,100,CONTENT_W-47,ink);
  }
}
static bool redundant_pin_label(const DbItem *item){
  if(item->kind==DB_WEATHER&&!strcmp(item->title,"Weather"))return true;
  if(item->kind==DB_PHONE&&(!strcmp(item->title,"Phone")||!strcmp(item->title,"Phone battery")))return true;
  return item->kind==DB_BATTERY&&(!strcmp(item->title,"Watch")||!strcmp(item->title,"Watch battery"));
}
static void pin_row(GContext *ctx,const DbItem *item,int y){
  GColor ink=panel(ctx,item,GRect(4,y,CONTENT_W-8,32),false);char value[64];item_value(item,value,sizeof(value));
  picture(ctx,item,9,y+4,24,ink);
  if(value[0]){
    if(redundant_pin_label(item))value_text(ctx,value,40,y+31,CONTENT_W-50,32,ink,GTextAlignmentLeft);
    else{unsigned index=clock_chars(value)?8:5;int value_width=width_of(value,index);if(value_width>CONTENT_W-89)value_width=CONTENT_W-89;
      text(ctx,item->title,20,40,y+27,CONTENT_W-53-value_width,ink);value_text(ctx,value,CONTENT_W-9-value_width,y+29,value_width,26,ink,GTextAlignmentRight);}
  }else text(ctx,item->title,24,40,y+29,CONTENT_W-50,ink);
}
static void notice(GContext *ctx,const DbItem *item){
  GColor ink=panel(ctx,item,GRect(4,108,CONTENT_W-8,43),false);
  if(!db_item_current(item,utc_now())){symbol(ctx,DB_NOTICE,10,111,20,ink);text(ctx,"Notifications",20,37,128,CONTENT_W-47,ink);text(ctx,"No preview",20,8,150,CONTENT_W-16,ink);return;}
  picture(ctx,item,10,111,20,ink);char heading[265];
  if(item->name[0]&&strcmp(item->name,item->title))snprintf(heading,sizeof(heading),"%s · %s",item->title,item->name);else snprintf(heading,sizeof(heading),"%s",item->title[0]?item->title:item->name);
  text(ctx,heading,20,37,128,CONTENT_W-47,ink);text(ctx,item->subtitle[0]?item->subtitle:"New notification",20,8,150,CONTENT_W-16,ink);
}
static void empty_message(GContext *ctx,const char *title,const char *detail,int y){symbol(ctx,DB_GENERIC,(CONTENT_W-28)/2,y,28,muted());centered(ctx,title,20,y+57,foreground());if(detail&&detail[0])centered(ctx,detail,20,y+84,muted());}
static void snapshot(GContext *ctx){
  const DbItem *activity=NULL,*notification=NULL;unsigned pins=0;
  for(unsigned i=0;i<s_state.snapshot.count;i++){const DbItem *item=&s_state.snapshot.items[i];if(item->role==DB_ROLE_ACTIVITY&&!activity)activity=item;else if(item->role==DB_ROLE_NOTICE&&!notification)notification=item;}
  if(activity)activity_main(ctx,activity);else centered(ctx,"Nothing active",24,77,muted());
  segment(ctx,8,105,CONTENT_W-8,105,stroke());
  if(notification)notice(ctx,notification);else{symbol(ctx,DB_NOTICE,10,117,22,muted());text(ctx,"No notifications",20,39,138,CONTENT_W-49,muted());}
  segment(ctx,8,154,CONTENT_W-8,154,stroke());
  for(unsigned i=0;i<s_state.snapshot.count;i++)if(s_state.snapshot.items[i].role==DB_ROLE_PIN&&pins<2)pin_row(ctx,&s_state.snapshot.items[i],158+35*(int)pins++);
  if(!pins)text(ctx,"Choose pins on phone",20,10,194,CONTENT_W-20,muted());
}
static void list_row(GContext *ctx,const DbItem *item,int y){
  GColor ink=panel(ctx,item,GRect(4,y,CONTENT_W-9,38),false);char value[64];item_value(item,value,sizeof(value));picture(ctx,item,9,y+6,26,ink);
  if(item->flags&DB_IS_MEDIA){char identity[144];db_item_media_identity(item,identity,sizeof(identity));text(ctx,item->title,20,42,y+18,CONTENT_W-53,ink);text(ctx,identity,20,42,y+37,CONTENT_W-53,ink);}
  else if(value[0]){text(ctx,item->title[0]?item->title:item->name,20,42,y+17,CONTENT_W-53,ink);value_text(ctx,value,42,y+39,CONTENT_W-53,24,ink,GTextAlignmentLeft);}
  else text(ctx,item->title[0]?item->title:item->name,24,42,y+29,CONTENT_W-53,ink);
}
static void list_view(GContext *ctx){
  if(!s_state.snapshot.count){empty_message(ctx,s_state.desired_mode==DB_ACTIVITIES?"Nothing active":"No pinned items",s_state.desired_mode==DB_PINNED?"Choose items on phone":"",66);return;}
  for(unsigned i=0;i<s_state.snapshot.count;i++)list_row(ctx,&s_state.snapshot.items[i],27+(int)i*40);
  if(s_state.snapshot.total>5){int thumb=200*5/s_state.snapshot.total;if(thumb<8)thumb=8;int top=27+(200-thumb)*s_state.snapshot.offset/(s_state.snapshot.total-5);fill(ctx,GRect(CONTENT_W-3,27,2,200),stroke(),0);fill(ctx,GRect(CONTENT_W-3,top,2,thumb),foreground(),0);}
}
static void playback_icon(GContext *ctx,unsigned index,bool paused,int x,int y,GColor color){
  graphics_context_set_fill_color(ctx,color);graphics_context_set_stroke_color(ctx,color);
  if(index==1&&!paused){fill(ctx,GRect(x+2,y+2,4,16),color,0);fill(ctx,GRect(x+11,y+2,4,16),color,0);return;}
  GPoint points[3];
  if(index==0){points[0]=GPoint(x+16,y+2);points[1]=GPoint(x+3,y+10);points[2]=GPoint(x+16,y+18);fill(ctx,GRect(x,y+2,2,16),color,0);}
  else{points[0]=GPoint(x+2,y+2);points[1]=GPoint(x+16,y+10);points[2]=GPoint(x+2,y+18);if(index==2)fill(ctx,GRect(x+18,y+2,2,16),color,0);}
  GPathInfo info={3,points};GPath *path=gpath_create(&info);if(path){gpath_draw_filled(ctx,path);gpath_destroy(path);}
}
static void media_view(GContext *ctx){
  const DbItem *item=db_selected(&s_state);
  if(!item||!db_item_current(item,utc_now())){empty_message(ctx,"Activity unavailable","Back returns to your list",66);return;}
  if(item->flags&DB_IS_MEDIA){
    char title[193];clean_text(title,sizeof(title),item->title);
    unsigned split=0;char first[193]="",second[193]="";
    if(width_of(title,5)>CONTENT_W-20){for(unsigned i=0;title[i];i++)if(title[i]==' '){char saved=title[i];title[i]=0;if(width_of(title,5)<=CONTENT_W-20)split=i;title[i]=saved;}}
    if(split){memcpy(first,title,split);first[split]=0;snprintf(second,sizeof(second),"%s",title+split+1);text(ctx,first,24,9,67,CONTENT_W-20,foreground());text(ctx,second,24,9,93,CONTENT_W-20,foreground());}
    else text(ctx,title,24,9,93,CONTENT_W-20,foreground());
    picture(ctx,item,9,105,40,accent());text(ctx,item->subtitle,20,58,122,CONTENT_W-68,foreground());text(ctx,item->value[0]?item->value:item->flags&DB_PAUSED?"Paused":"",20,58,146,CONTENT_W-68,muted());
    for(unsigned i=0;i<3;i++){
      bool available=control_available(item,i),selected=s_state.focus==i;GColor ink=selected?background():available?foreground():muted();int x=5+i*52;
      if(selected)fill(ctx,GRect(x,163,48,37),foreground(),5);else edge(ctx,GRect(x,163,48,37),stroke(),5);
      playback_icon(ctx,i,(item->flags&DB_PAUSED)!=0,x+14,171,ink);
    }
  }else{
    text(ctx,item->title,24,9,57,CONTENT_W-20,foreground());char value[64];item_value(item,value,sizeof(value));text(ctx,value[0]?value:item->subtitle,24,9,86,CONTENT_W-20,muted());
    unsigned count=0;for(unsigned i=0;i<3;i++)if(db_control_present(item,i))count++;
    int height=count==1?72:count==2?56:38,gap=count==3?5:8,top=count==1?116:102;unsigned row=0;
    for(unsigned i=0;i<3;i++)if(db_control_present(item,i)){
      bool available=control_available(item,i),selected=s_state.focus==i;int y=top+(int)row++*(height+gap);
      if(selected)fill(ctx,GRect(6,y,CONTENT_W-12,height),foreground(),4);else edge(ctx,GRect(6,y,CONTENT_W-12,height),stroke(),4);
      GColor ink=selected?(available?background():(s_state.snapshot.dark?GColorDarkGray:GColorLightGray)):(available?foreground():muted());
      text(ctx,item->controls[i][0]?item->controls[i]:"Action",24,14,y+height/2+12,CONTENT_W-28,ink);
    }
  }
}
static void check_icon(GContext *ctx,int x,int y,GColor ink){segment(ctx,x-7,y,x-2,y+6,ink);segment(ctx,x-2,y+6,x+8,y-6,ink);}
static void launch_icon(GContext *ctx,int x,int y,GColor ink){
  segment(ctx,x-8,y-8,x,y-8,ink);segment(ctx,x-8,y-8,x-8,y+8,ink);segment(ctx,x-8,y+8,x,y+8,ink);
  segment(ctx,x-2,y,x+9,y,ink);segment(ctx,x+4,y-5,x+9,y,ink);segment(ctx,x+9,y,x+4,y+5,ink);
}
static void action_icon(GContext *ctx,const DbItem *item,unsigned action,int x,int y,GColor ink){
  if(item->flags&DB_IS_MEDIA){playback_icon(ctx,action,(item->flags&DB_PAUSED)!=0,x-9,y-10,ink);return;}
  if(item->kind==DB_LIGHT){graphics_context_set_stroke_color(ctx,ink);graphics_context_set_stroke_width(ctx,2);graphics_draw_circle(ctx,GPoint(x,y+1),8);fill(ctx,GRect(x-3,y-12,6,10),foreground(),0);segment(ctx,x,y-11,x,y,ink);}
  else if(item->kind==DB_FIND)symbol(ctx,DB_FIND,x-11,y-11,22,ink);
  else check_icon(ctx,x,y,ink);
}
static void action_bar(GContext *ctx){
  GColor ink=background();int x=CONTENT_W+ACTION_BAR_WIDTH/2;fill(ctx,GRect(CONTENT_W,0,ACTION_BAR_WIDTH,SCREEN_H),foreground(),0);
  if(s_guide){check_icon(ctx,x,114,ink);return;}
  if(!s_command.confirmation){segment(ctx,x-6,42,x,36,ink);segment(ctx,x,36,x+6,42,ink);segment(ctx,x-6,187,x,193,ink);segment(ctx,x,193,x+6,187,ink);}
  if(s_state.loading||!s_state.ready)return;
  const DbItem *item=db_selected(&s_state);if(!s_has_connection||!db_item_capability_current(item,utc_now()))return;
  if(preview_item()){launch_icon(ctx,x,114,ink);return;}
  if(s_command.active&&s_command.result==DB_PENDING){for(int i=0;i<3;i++){graphics_context_set_fill_color(ctx,ink);graphics_fill_circle(ctx,GPoint(x-8+i*8,114),2);}return;}
  if(s_command.confirmation){
    if(s_confirm_accept){segment(ctx,x-6,42,x,36,ink);segment(ctx,x,36,x+6,42,ink);action_icon(ctx,item,s_command.action,x,114,ink);}
    else{check_icon(ctx,x,114,ink);segment(ctx,x-6,187,x,193,ink);segment(ctx,x,193,x+6,187,ink);}
    return;
  }
  if(s_command.active&&s_command.result==DB_SUCCESS){check_icon(ctx,x,114,ink);return;}
  if(s_state.desired_mode==DB_MEDIA){if(control_available(item,s_state.focus))action_icon(ctx,item,s_state.focus,x,114,ink);}
  else if(item->flags&DB_NOTIFICATION){if(item->flags&DB_APP)symbol(ctx,DB_NOTICE,x-11,103,22,ink);}
  else if(item->role==DB_ROLE_ACTIVITY&&(item->flags&DB_IS_MEDIA)){if(db_item_direct_action(item,utc_now())==1)action_icon(ctx,item,1,x,114,ink);}
  else if(db_item_actionable(item,utc_now())){
    if(item->role==DB_ROLE_ACTIVITY){for(int i=0;i<3;i++){graphics_context_set_fill_color(ctx,ink);graphics_fill_circle(ctx,GPoint(x-8+i*8,114),2);}}
    else if(item->kind==DB_LIGHT||item->kind==DB_FIND)action_icon(ctx,item,0,x,114,ink);
    else{segment(ctx,x+3,103,x-5,115,ink);segment(ctx,x-5,115,x+4,115,ink);segment(ctx,x+4,115,x-3,125,ink);}
  }
}
static void confirm_overlay(GContext *ctx){
  const DbItem *item=db_selected(&s_state);
  fill(ctx,GRect(4,35,CONTENT_W-8,188),background(),6);edge(ctx,GRect(4,35,CONTENT_W-8,188),foreground(),6);
  text(ctx,item&&item->action_label[0]?item->action_label:"Run action?",24,12,66,CONTENT_W-24,foreground());
  text(ctx,item?(item->title[0]?item->title:item->name):"Selected item",20,12,96,CONTENT_W-24,foreground());
  text(ctx,"Back cancels",18,12,123,CONTENT_W-24,muted());
  fill(ctx,GRect(10,140,CONTENT_W-20,33),s_confirm_accept?background():foreground(),4);
  text(ctx,"Cancel",20,17,166,CONTENT_W-34,s_confirm_accept?foreground():background());
  fill(ctx,GRect(10,179,CONTENT_W-20,33),s_confirm_accept?foreground():background(),4);
  text(ctx,"Run action",20,17,205,CONTENT_W-34,s_confirm_accept?background():foreground());
}
static void guide_view(GContext *ctx){
  header(ctx);
  const char *lines[]={"Up / Down: move","Hold Up: Activities","Hold Down: Pinned","Select: action","Hold Select: app","Back: return"};
  for(unsigned i=0;i<6;i++)text(ctx,lines[i],20,6,57+(int)i*26,CONTENT_W-12,foreground());
  fill(ctx,GRect(4,201,CONTENT_W-8,25),foreground(),4);text(ctx,"Select to start",20,10,222,CONTENT_W-20,background());
}
static void update(Layer *layer,GContext *ctx){
  (void)layer;fill(ctx,GRect(0,0,SCREEN_W,SCREEN_H),background(),0);
  if(s_guide){guide_view(ctx);action_bar(ctx);return;}
  header(ctx);
  if(s_state.loading||!s_state.ready)empty_message(ctx,s_has_connection?"Loading…":"Phone disconnected",s_has_connection?"Waiting for data":"Reconnect your phone",66);
  else if(s_state.snapshot.status>=DB_OFFLINE&&!s_state.snapshot.count)empty_message(ctx,status_text(),s_state.snapshot.status==DB_PERMISSION?"Open phone settings":"Back is available",66);
  else if(s_state.desired_mode==DB_OVERVIEW)snapshot(ctx);
  else if(s_state.desired_mode==DB_MEDIA)media_view(ctx);
  else list_view(ctx);
  if(s_command.confirmation)confirm_overlay(ctx);
  action_bar(ctx);
}
static bool read_uint(DictionaryIterator *dict,uint32_t key,uint32_t *value){
  Tuple *t=dict_find(dict,key);if(!t||(t->type!=TUPLE_UINT&&t->type!=TUPLE_INT))return false;
  if(t->length==1){if(t->type==TUPLE_INT&&t->value->int8<0)return false;*value=t->value->uint8;}
  else if(t->length==2){if(t->type==TUPLE_INT&&t->value->int16<0)return false;*value=t->value->uint16;}
  else if(t->length==4){if(t->type==TUPLE_INT&&t->value->int32<0)return false;*value=t->value->uint32;}
  else return false;
  return true;
}
static void view_failed(void *context){(void)context;s_view_timeout=NULL;if(!s_state.loading)return;stop_repeat();db_state_fail_view(&s_state,s_has_connection?DB_ERROR:DB_OFFLINE);update_ticks();repaint();}
static void clear_feedback(void *context){(void)context;s_action_timeout=NULL;memset(&s_command,0,sizeof(s_command));repaint();}
static void finish_feedback(void){
  if(s_action_timeout){app_timer_cancel(s_action_timeout);s_action_timeout=NULL;}
  if(s_command.result==DB_SUCCESS)s_action_timeout=app_timer_register(1000,clear_feedback,NULL);
}
static void acknowledge_feedback(void){
  if(s_command.active&&s_command.ended){if(s_action_timeout){app_timer_cancel(s_action_timeout);s_action_timeout=NULL;}memset(&s_command,0,sizeof(s_command));repaint();}
}
static void action_failed(void *context){(void)context;s_action_timeout=NULL;if(s_command.active){s_command.result=DB_FAILED;s_command.confirmation=false;s_command.ended=true;snprintf(s_command.text,sizeof(s_command.text),"No response");finish_feedback();repaint();}}
static void send_queued(void){
  if(s_sending||!s_queue_count)return;
  DictionaryIterator *dict;AppMessageResult error=app_message_outbox_begin(&dict);if(error!=APP_MSG_OK){s_queue_count=0;if(s_state.loading)view_failed(NULL);else action_failed(NULL);return;}
  Outbound item=s_queue[0];dict_write_uint8(dict,DB_KEY_OPERATION,item.op);dict_write_uint32(dict,DB_KEY_SESSION,s_state.session);dict_write_uint32(dict,DB_KEY_REQUEST,item.request);
  dict_write_uint8(dict,DB_KEY_MODE,item.mode);dict_write_uint16(dict,DB_KEY_OFFSET,item.offset);dict_write_uint16(dict,DB_KEY_INDEX,item.index);
  if(item.token){dict_write_uint32(dict,DB_KEY_TOKEN,item.token);dict_write_uint32(dict,DB_KEY_VERSION,item.version);}
  if(item.op==DB_OP_ACTION){dict_write_uint8(dict,DB_KEY_ACTION,item.action);dict_write_uint8(dict,DB_KEY_CONFIRM,item.confirm);}
  s_sending=true;
  if(app_message_outbox_send()!=APP_MSG_OK){s_sending=false;s_queue_count=0;if(s_state.loading)view_failed(NULL);else action_failed(NULL);}
}
static void queue_message(Outbound item){
  if(item.op==DB_OP_VIEW||item.op==DB_OP_HELLO){for(unsigned i=s_sending?1:0;i<s_queue_count;i++)if(s_queue[i].op==DB_OP_VIEW||s_queue[i].op==DB_OP_HELLO){s_queue[i]=item;send_queued();return;}}
  if(item.op==DB_OP_FOCUS){
    for(unsigned i=s_sending?1:0;i<s_queue_count;i++)if(s_queue[i].op==DB_OP_FOCUS&&s_queue[i].request==item.request){s_queue[i]=item;send_queued();return;}
    if(s_queue_count>=OUTBOX_CAPACITY)return;
  }
  if(s_queue_count>=OUTBOX_CAPACITY){if(s_state.loading)view_failed(NULL);else action_failed(NULL);return;}
  s_queue[s_queue_count++]=item;send_queued();
}
static void publish_focus(void){
  const DbItem *item=db_selected(&s_state);
  if(item&&s_state.snapshot.mode!=DB_MEDIA)queue_message((Outbound){.op=DB_OP_FOCUS,.mode=s_state.snapshot.mode,.request=s_state.view_request,.offset=s_state.snapshot.offset,.index=s_state.selected_index,.token=item->token,.version=item->version});
}
static void request_view(uint8_t mode,uint16_t offset,uint16_t index,uint32_t token,bool hello){
  if(!hello)s_state.selection_lost=false; //Deliberate navigation can choose a new row.
  uint32_t request=next_request();db_state_expect(&s_state,request,mode,index,token);
  if(s_view_timeout)app_timer_cancel(s_view_timeout);
  s_view_timeout=app_timer_register(VIEW_TIMEOUT_MS,view_failed,NULL);
  queue_message((Outbound){.op=hello?DB_OP_HELLO:DB_OP_VIEW,.mode=mode,.offset=offset,.index=index,.token=token,.request=request});update_ticks();repaint();
}
static bool visually_equal(const DbSnapshot *a,const DbSnapshot *b){
  if(a->mode!=b->mode||a->status!=b->status||a->count!=b->count||a->dark!=b->dark||a->total!=b->total||a->offset!=b->offset)return false;
  for(unsigned i=0;i<a->count;i++){
    const DbItem *x=&a->items[i],*y=&b->items[i];
    if(x->token!=y->token||x->flags!=y->flags||x->kind!=y->kind||x->role!=y->role||x->clock_mode!=y->clock_mode||x->anchor!=y->anchor||x->base_seconds!=y->base_seconds||
      strcmp(x->title,y->title)||strcmp(x->subtitle,y->subtitle)||strcmp(x->value,y->value)||strcmp(x->app_label,y->app_label)||strcmp(x->action_label,y->action_label)||strcmp(x->name,y->name)||memcmp(x->controls,y->controls,sizeof(x->controls))||
      x->width!=y->width||x->height!=y->height||x->palette_length!=y->palette_length||x->pixel_length!=y->pixel_length||memcmp(x->palette,y->palette,sizeof(x->palette))||memcmp(x->pixels,y->pixels,x->pixel_length))return false;
  }
  return true;
}
static void inbox(DictionaryIterator *dict,void *context){
  (void)context;uint32_t operation;
  if(read_uint(dict,DB_KEY_OPERATION,&operation)&&operation==DB_OP_READY){
#ifndef DASHBOARD_FIXTURE
    // READY can come from a freshly restarted phone JS runtime whose sequence
    // starts at one. A new native epoch prevents old replies or capabilities
    // from being mistaken for this replacement runtime's state.
    uint32_t session=s_state.session>=INT32_MAX?1:s_state.session+1;bool dark=s_state.snapshot.dark;
    stop_repeat();cancel_hold_preview();s_select_down=false;s_hold_intent=false;
    if(s_view_timeout){app_timer_cancel(s_view_timeout);s_view_timeout=NULL;}
    if(s_action_timeout){app_timer_cancel(s_action_timeout);s_action_timeout=NULL;}
    db_deadline_clear(&s_expiry);
    memset(&s_command,0,sizeof(s_command));s_press_token=s_press_version=0;s_press_mode=DB_OVERVIEW;
    // The SDK still owns an already-sent dictionary. Keep that queue slot until
    // its ACK/NACK arrives; only unsent messages from the old epoch are dropped.
    s_queue_count=s_sending&&s_queue_count?1:0;
    db_state_init(&s_state,session);s_state.connected=s_has_connection;s_state.snapshot.dark=dark;
    request_view(DB_OVERVIEW,0,0,0,true);
#endif
    return;
  }
  uint32_t session;if(read_uint(dict,DB_KEY_SESSION,&session)&&session!=s_state.session)return;
  Tuple *data=dict_find(dict,DB_KEY_DATA);
  if(data&&data->type==TUPLE_BYTE_ARRAY){
    DbSnapshot *incoming=malloc(sizeof(*incoming));if(!incoming){view_failed(NULL);return;}
    if(db_decode((const uint8_t *)data->value,data->length,incoming)){
      bool was_loading=s_state.loading,theme_changed=s_state.snapshot.dark!=incoming->dark,redraw=s_state.loading||!s_state.ready||!visually_equal(&s_state.snapshot,incoming);uint32_t selected=s_state.selected_token;uint16_t selected_index=s_state.selected_index;
      if(db_state_apply(&s_state,incoming)){
        if(theme_changed)window_set_background_color(s_window,background());
#ifndef DASHBOARD_FIXTURE
        // Save only the accepted preference, never snapshot content or bindings.
        // Unchanged frames do not write flash; a failed write can retry later.
        if(s_saved_dark!=s_state.snapshot.dark&&persist_write_bool(THEME_DARK_KEY,s_state.snapshot.dark)>=0)s_saved_dark=s_state.snapshot.dark;
#endif
        if(s_view_timeout){app_timer_cancel(s_view_timeout);s_view_timeout=NULL;}
        if(s_state.snapshot.mode==DB_MEDIA&&s_state.focus>2)s_state.focus=1;
        if(s_select_down&&!pressed_item())cancel_hold_preview();
        bool redacted=db_state_redact(&s_state,utc_now(),!s_has_connection);update_ticks();if(redraw||redacted||selected!=s_state.selected_token)repaint();
        if(was_loading||selected!=s_state.selected_token||selected_index!=s_state.selected_index)publish_focus();
      }
    }
    memset(incoming,0,sizeof(*incoming));free(incoming);
  }
  uint32_t result,request;
  if(read_uint(dict,DB_KEY_RESULT,&result)&&read_uint(dict,DB_KEY_SESSION,&session)&&session==s_state.session&&read_uint(dict,DB_KEY_REQUEST,&request)&&s_command.active&&!s_command.ended&&request==s_command.request&&result>=DB_PENDING&&result<=DB_CONFIRM){
    s_command.result=(uint8_t)result;s_command.confirmation=result==DB_CONFIRM;if(s_command.confirmation)s_confirm_accept=false;
    Tuple *label=dict_find(dict,DB_KEY_TEXT);s_command.text[0]=0;
    if(label&&label->type==TUPLE_CSTRING&&label->length&&label->length<=sizeof(s_command.text)){
      memcpy(s_command.text,(const void *)label->value,label->length);
      if(s_command.text[label->length-1])s_command.text[0]=0;
    }
    if(result!=DB_PENDING&&s_action_timeout){app_timer_cancel(s_action_timeout);s_action_timeout=NULL;}
    if(result!=DB_PENDING&&result!=DB_CONFIRM){s_command.ended=true;finish_feedback();}
    repaint();
  }
}
static void outbox_sent(DictionaryIterator *dict,void *context){(void)dict;(void)context;if(s_queue_count){s_queue_count--;memmove(s_queue,s_queue+1,s_queue_count*sizeof(*s_queue));}s_sending=false;send_queued();}
static void outbox_failed(DictionaryIterator *dict,AppMessageResult reason,void *context){
  (void)reason;(void)context;uint32_t session;
  if(dict&&read_uint(dict,DB_KEY_SESSION,&session)&&session!=s_state.session){
    if(s_queue_count){s_queue_count--;memmove(s_queue,s_queue+1,s_queue_count*sizeof(*s_queue));}
    s_sending=false;send_queued();return;
  }
  s_sending=false;s_queue_count=0;if(s_state.loading)view_failed(NULL);if(s_command.active&&s_command.result==DB_PENDING)action_failed(NULL);
}
static void inbox_dropped(AppMessageResult reason,void *context){(void)reason;(void)context;if(s_state.loading)view_failed(NULL);}
static void tick(struct tm *now,TimeUnits units){
  uint32_t timestamp=utc_now();
  // AppTimers are relative. Rebase after a wall-clock correction or a missed
  // tick, while leaving regular second/minute ticks allocation-free.
  if(!s_last_tick||timestamp-s_last_tick!=(s_tick_seconds==2?1u:60u))db_deadline_clear(&s_expiry);
  s_last_tick=timestamp;
  bool dirty=db_state_redact(&s_state,timestamp,!s_has_connection);unsigned minute=(unsigned)now->tm_hour*60+(unsigned)now->tm_min;
  if(minute!=s_last_minute){s_last_minute=minute;dirty=true;}
  // Paint the final00:00 once before update_ticks drops the second subscription.
  if(((units&SECOND_UNIT)||!units)&&s_tick_seconds==2)dirty=true;
  if(dirty)repaint();
  update_ticks();
}
static void expire_sources(void *context){
  (void)context;s_expiry.timer=NULL;s_expiry.at=0;
  if(db_state_redact(&s_state,utc_now(),!s_has_connection))repaint();
  update_ticks();
}
static void update_ticks(void){
  if(s_hold_preview&&!preview_item())cancel_hold_preview();
  uint8_t seconds=s_focused&&!s_guide&&db_state_running_clock(&s_state,utc_now())?1:0;
  if(s_tick_seconds!=seconds+1){s_tick_seconds=seconds+1;s_last_tick=0;tick_timer_service_unsubscribe();tick_timer_service_subscribe(seconds?SECOND_UNIT:MINUTE_UNIT,tick);}
  uint32_t now=utc_now(),next=db_state_next_expiry(&s_state,now);
  time_t seconds_now;uint16_t milliseconds;time_ms(&seconds_now,&milliseconds);
  db_deadline_update(&s_expiry,next,(uint64_t)seconds_now*1000u+milliseconds,expire_sources,NULL);
  if(s_command.confirmation){const DbItem *item=db_selected(&s_state);if(!db_item_actionable(item,now)||item->token!=s_command.token||item->version!=s_command.version){s_command.confirmation=false;s_command.result=DB_STALE;s_command.ended=true;s_command.text[0]=0;finish_feedback();repaint();}}
}
static void stop_repeat(void){s_repeat_held=false;if(s_repeat){app_timer_cancel(s_repeat);s_repeat=NULL;}}
static void move_selection(int delta){
  if(s_command.confirmation)return;
  uint16_t index=s_state.selected_index;uint8_t focus=s_state.focus;
  if(!db_state_move(&s_state,delta,&index))return;
  if(s_state.snapshot.mode==DB_MEDIA){if(focus!=s_state.focus)repaint();return;}
  if(index<s_state.snapshot.offset||index>=s_state.snapshot.offset+s_state.snapshot.count){
    uint16_t offset=index>=3?index-3:0;if(s_state.snapshot.total>DB_PAGE_ITEMS&&offset>s_state.snapshot.total-DB_PAGE_ITEMS)offset=s_state.snapshot.total-DB_PAGE_ITEMS;
    request_view(s_state.snapshot.mode,offset,index,0,false);
  }else{
    publish_focus();
    repaint();
  }
}
static void repeated(void *context){
  (void)context;s_repeat=NULL;if(!s_repeat_held||!s_focused)return;
  uint16_t before=s_state.selected_index;uint8_t focus=s_state.focus;move_selection(s_repeat_delta);
  if(!s_state.loading&&before==s_state.selected_index&&focus==s_state.focus){s_repeat_held=false;return;}
  if(s_repeat_held)s_repeat=app_timer_register(140,repeated,NULL);
}
static void direction_click(ClickRecognizerRef recognizer,void *context){
  (void)context;if(s_guide)return;
  if(s_command.confirmation){s_confirm_accept=click_recognizer_get_button_id(recognizer)==BUTTON_ID_DOWN;repaint();return;}
  acknowledge_feedback();cancel_hold_preview();move_selection(click_recognizer_get_button_id(recognizer)==BUTTON_ID_UP?-1:1);
}
static void direction_hold(ClickRecognizerRef recognizer,void *context){
  (void)context;if(s_guide||s_command.confirmation)return;acknowledge_feedback();cancel_hold_preview();int delta=click_recognizer_get_button_id(recognizer)==BUTTON_ID_UP?-1:1;
  if(s_state.desired_mode==DB_OVERVIEW){if(s_state.loading)return;db_state_remember(&s_state);request_view(delta<0?DB_ACTIVITIES:DB_PINNED,0,0,0,false);return;}
  stop_repeat();s_repeat_held=true;s_repeat_delta=delta;move_selection(delta);s_repeat=app_timer_register(140,repeated,NULL);
}
static void direction_release(ClickRecognizerRef recognizer,void *context){(void)recognizer;(void)context;stop_repeat();}
static const DbItem *pressed_item(void){const DbItem *item=db_selected(&s_state);return item&&item->token==s_press_token&&item->version==s_press_version&&s_state.desired_mode==s_press_mode?item:NULL;}
static void show_hold_preview(void *context){
  (void)context;s_hold_timer=NULL;const DbItem *item=pressed_item();
  if(s_select_down&&!s_guide&&!s_command.confirmation&&s_has_connection&&db_item_capability_current(item,utc_now())&&(item->flags&DB_APP)&&!(s_command.active&&s_command.result==DB_PENDING)){s_hold_preview=true;s_hold_intent=true;repaint();}
}
static void select_raw(ClickRecognizerRef recognizer,void *context){
  (void)recognizer;(void)context;cancel_hold_preview();s_hold_intent=false;s_select_down=true;
  if(s_guide){s_press_token=s_press_version=0;return;}
  acknowledge_feedback();const DbItem *item=db_selected(&s_state);s_press_token=item?item->token:0;s_press_version=item?item->version:0;s_press_mode=s_state.desired_mode;
  if(item&&(item->flags&DB_APP)&&!s_command.confirmation)s_hold_timer=app_timer_register(HOLD_PREVIEW_MS,show_hold_preview,NULL);
}
static void select_released(ClickRecognizerRef recognizer,void *context){(void)recognizer;(void)context;s_select_down=false;cancel_hold_preview();}
static void run_command(const DbItem *item,uint8_t operation,uint8_t action,bool confirmation){
  if(!s_has_connection||!db_item_capability_current(item,utc_now())||(operation==DB_OP_OPEN?!(item->flags&DB_APP):!db_item_actionable(item,utc_now())))return;
  if(s_command.active&&s_command.result==DB_PENDING)return;
  uint32_t request=confirmation?s_command.request:next_request();
  s_command=(Command){.request=request,.token=item->token,.version=item->version,.action=action,.active=true,.result=DB_PENDING};
  if(s_action_timeout)app_timer_cancel(s_action_timeout);
  s_action_timeout=app_timer_register(ACTION_TIMEOUT_MS,action_failed,NULL);
  queue_message((Outbound){.op=operation,.mode=s_state.desired_mode,.request=request,.token=item->token,.version=item->version,.action=action,.confirm=confirmation?1:0});repaint();
}
static void select_click(ClickRecognizerRef recognizer,void *context){
  (void)recognizer;(void)context;cancel_hold_preview();
  if(s_guide){s_guide=false;persist_write_bool(GUIDE_SEEN_KEY,true);s_press_token=s_press_version=0;s_hold_intent=false;update_ticks();repaint();return;}
  if(s_hold_intent){s_hold_intent=false;return;}
  if(s_command.confirmation){if(!s_confirm_accept){memset(&s_command,0,sizeof(s_command));repaint();return;}const DbItem *item=db_selected(&s_state);if(item&&item->token==s_command.token&&item->version==s_command.version)run_command(item,DB_OP_ACTION,s_command.action,true);else{s_command.confirmation=false;s_command.result=DB_STALE;repaint();}return;}
  const DbItem *item=pressed_item();if(!s_has_connection||!db_item_capability_current(item,utc_now()))return;
  if(s_state.desired_mode==DB_MEDIA){if(control_available(item,s_state.focus))run_command(item,DB_OP_ACTION,s_state.focus,false);}
  else if(item->flags&DB_NOTIFICATION){if(item->flags&DB_APP)run_command(item,DB_OP_OPEN,0,false);}
  else if(item->role==DB_ROLE_ACTIVITY&&(item->flags&DB_IS_MEDIA)){if(db_item_direct_action(item,utc_now())==1)run_command(item,DB_OP_ACTION,1,false);}
  else if(item->role==DB_ROLE_ACTIVITY&&db_item_actionable(item,utc_now())&&(item->flags&(DB_MEDIA_PREVIOUS|DB_MEDIA_TOGGLE|DB_MEDIA_NEXT))){
    db_state_remember(&s_state);s_state.focus=(item->flags&DB_IS_MEDIA)&&control_available(item,1)?1:control_available(item,0)?0:control_available(item,1)?1:2;
    request_view(DB_MEDIA,0,0,item->token,false);
  }else if(item->role==DB_ROLE_PIN&&db_item_actionable(item,utc_now()))run_command(item,DB_OP_ACTION,0,false);
}
static void select_hold(ClickRecognizerRef recognizer,void *context){(void)recognizer;(void)context;cancel_hold_preview();if(s_guide||s_command.confirmation)return;const DbItem *item=pressed_item();if(item&&(item->flags&DB_APP))run_command(item,DB_OP_OPEN,0,false);}
static void back_click(ClickRecognizerRef recognizer,void *context){
  (void)recognizer;(void)context;stop_repeat();cancel_hold_preview();acknowledge_feedback();
  if(s_command.confirmation){memset(&s_command,0,sizeof(s_command));repaint();return;}
  DbReturn previous;if(db_state_back(&s_state,&previous)){s_state.focus=previous.focus;request_view(previous.mode,previous.offset,previous.index,previous.token,false);}
  else{queue_message((Outbound){.op=DB_OP_CANCEL,.request=next_request()});window_stack_pop_all(false);}
}
static void configure_clicks(void *context){
  (void)context;
  window_single_click_subscribe(BUTTON_ID_UP,direction_click);window_long_click_subscribe(BUTTON_ID_UP,600,direction_hold,direction_release);
  window_single_click_subscribe(BUTTON_ID_DOWN,direction_click);window_long_click_subscribe(BUTTON_ID_DOWN,600,direction_hold,direction_release);
  window_single_click_subscribe(BUTTON_ID_SELECT,select_click);window_long_click_subscribe(BUTTON_ID_SELECT,600,select_hold,NULL);window_raw_click_subscribe(BUTTON_ID_SELECT,select_raw,select_released,NULL);
  window_single_click_subscribe(BUTTON_ID_BACK,back_click);
}
static void connection_changed(bool connected){
  s_has_connection=connected;s_state.connected=connected;stop_repeat();cancel_hold_preview();s_select_down=false;s_hold_intent=false;s_press_token=0;
  if(!connected){db_state_redact(&s_state,utc_now(),true);if(s_state.loading)view_failed(NULL);if(s_command.active&&s_command.result==DB_PENDING)action_failed(NULL);}
  else request_view(s_state.desired_mode,s_state.snapshot.offset,s_state.selected_index,s_state.selected_token,true);
  update_ticks();repaint();
}
static void focus_changed(bool focused){s_focused=focused;if(!focused){stop_repeat();cancel_hold_preview();s_select_down=false;s_hold_intent=false;s_press_token=0;}else{db_state_redact(&s_state,utc_now(),!s_has_connection);repaint();}update_ticks();}
static void battery_changed(BatteryChargeState value){(void)value;for(unsigned i=0;i<s_state.snapshot.count;i++)if(s_state.snapshot.items[i].flags&DB_LOCAL_WATCH){repaint();break;}}
static void init(void){
  time_t seconds;uint16_t milliseconds;time_ms(&seconds,&milliseconds);uint32_t session=((uint32_t)seconds^((uint32_t)milliseconds<<16)^0x44534831u)&INT32_MAX;if(!session)session=1;
  db_state_init(&s_state,session);
#ifndef DASHBOARD_FIXTURE
  s_guide=!persist_read_bool(GUIDE_SEEN_KEY);
  s_saved_dark=persist_read_bool(THEME_DARK_KEY);s_state.snapshot.dark=s_saved_dark;
#endif
  s_has_connection=connection_service_peek_pebble_app_connection();s_state.connected=s_has_connection;
  s_window=window_create();if(!s_window)return;s_canvas=layer_create(GRect(0,0,SCREEN_W,SCREEN_H));if(!s_canvas)return;
  window_set_background_color(s_window,background());
  layer_set_update_proc(s_canvas,update);layer_add_child(window_get_root_layer(s_window),s_canvas);window_set_click_config_provider(s_window,configure_clicks);
  app_message_register_inbox_received(inbox);app_message_register_inbox_dropped(inbox_dropped);app_message_register_outbox_sent(outbox_sent);app_message_register_outbox_failed(outbox_failed);
  if(app_message_open(9216,256)!=APP_MSG_OK){s_state.ready=true;s_state.snapshot.status=DB_ERROR;}
  connection_service_subscribe((ConnectionHandlers){.pebble_app_connection_handler=connection_changed});app_focus_service_subscribe(focus_changed);battery_state_service_subscribe(battery_changed);
  window_stack_push(s_window,false);update_ticks();request_view(DB_OVERVIEW,0,0,0,true);
#ifdef DASHBOARD_FIXTURE
#include "../../tests/native/fixture.h"
  DbSnapshot *fixture=malloc(sizeof(*fixture));
  if(fixture&&db_decode(DB_FIXTURE_DATA,DB_FIXTURE_LENGTH,fixture)){
    int64_t shift=(int64_t)utc_now()-fixture->now;
    for(unsigned i=0;i<fixture->count;i++){
      DbItem *item=&fixture->items[i];
      if(item->valid_until)item->valid_until=(uint32_t)((int64_t)item->valid_until+shift);
      if(item->anchor)item->anchor=(uint32_t)((int64_t)item->anchor+shift);
    }
    fixture->now=utc_now();
    s_state.session=fixture->session;db_state_expect(&s_state,fixture->request,fixture->mode,0,fixture->count?fixture->items[0].token:0);db_state_apply(&s_state,fixture);
    window_set_background_color(s_window,background());
    if(s_view_timeout){app_timer_cancel(s_view_timeout);s_view_timeout=NULL;}s_has_connection=true;update_ticks();repaint();
  }
  free(fixture);
#endif
}
static void deinit(void){
  stop_repeat();cancel_hold_preview();if(s_view_timeout)app_timer_cancel(s_view_timeout);if(s_action_timeout)app_timer_cancel(s_action_timeout);db_deadline_clear(&s_expiry);tick_timer_service_unsubscribe();battery_state_service_unsubscribe();connection_service_unsubscribe();app_focus_service_unsubscribe();app_message_deregister_callbacks();
  if(s_canvas)layer_destroy(s_canvas);
  if(s_window)window_destroy(s_window);
  for(unsigned i=0;i<FONT_COUNT;i++)if(s_fonts[i])fonts_unload_custom_font(s_fonts[i]);
  memset(&s_state,0,sizeof(s_state));memset(&s_command,0,sizeof(s_command));
}
int main(void){init();if(s_window&&s_canvas)app_event_loop();deinit();return 0;}
