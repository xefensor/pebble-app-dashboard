/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;
/******/
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

	__webpack_require__(1);
	module.exports = __webpack_require__(2);


/***/ }),
/* 1 */
/***/ (function(module, exports) {

	/**
	 * Copyright 2024 Google LLC
	 *
	 * Licensed under the Apache License, Version 2.0 (the "License");
	 * you may not use this file except in compliance with the License.
	 * You may obtain a copy of the License at
	 *
	 *     http://www.apache.org/licenses/LICENSE-2.0
	 *
	 * Unless required by applicable law or agreed to in writing, software
	 * distributed under the License is distributed on an "AS IS" BASIS,
	 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
	 * See the License for the specific language governing permissions and
	 * limitations under the License.
	 */
	
	(function(p) {
	  if (!p === undefined) {
	    console.error('Pebble object not found!?');
	    return;
	  }
	
	  // Aliases:
	  p.on = p.addEventListener;
	  p.off = p.removeEventListener;
	
	  // For Android (WebView-based) pkjs, print stacktrace for uncaught errors:
	  if (typeof window !== 'undefined' && window.addEventListener) {
	    window.addEventListener('error', function(event) {
	      if (event.error && event.error.stack) {
	        console.error('' + event.error + '\n' + event.error.stack);
	      }
	    });
	  }
	
	})(Pebble);


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var createRuntime=__webpack_require__(3);
	var settings=__webpack_require__(5);
	var runtime=createRuntime({pebble:Pebble,storage:localStorage});
	Pebble.addEventListener('ready',function(){runtime.ready();});
	Pebble.addEventListener('appmessage',function(event){runtime.message(event&&event.payload);});
	Pebble.addEventListener('showConfiguration',function(){
	  var page=__webpack_require__(20);
	  Promise.resolve(runtime.configuration()).then(function(value){
	    Pebble.openURL('data:text/html;charset=utf-8,'+encodeURIComponent(page(value.needsRepair?null:value.settings,value.catalogue)));
	  },function(){
	    var current=settings.load(localStorage);
	    Pebble.openURL('data:text/html;charset=utf-8,'+encodeURIComponent(page(current,{plugins:[],instances:[],activities:[],error:'Plugin discovery is unavailable. Saved choices are preserved.'})));
	  });
	});
	Pebble.addEventListener('webviewclosed',function(event){
	  if(!event||!event.response)return;
	  try{
	    var source=event.response;
	    var value=JSON.parse(source.charAt(0)==='{'?source:decodeURIComponent(source));
	    runtime.configure(value.settings||value);
	  }catch(ignored){/* Invalid or cancelled drafts never replace saved settings. */}
	});
	Pebble.addEventListener('configmessage',function(event){
	  if(!event||typeof event.respond!=='function')return;
	  var message=event.message||event.data||event.payload||event;
	  try{
	    if(typeof message==='string')message=JSON.parse(message);
	    if(message&&message.type==='catalogue'){
	      runtime.catalogue().then(function(value){event.respond({ok:true,catalogue:value,cached:false});},function(){event.respond({ok:false,message:'Could not read installed plugins. Retry discovery.'});});return;
	    }
	    if(message&&message.type==='save_settings'){
	      // Android PKJS reads a restored DOM snapshot, while the config plugin
	      // writes native preferences directly. Save through the live runtime so
	      // its DOM and native store agree before SDK teardown persists the DOM.
	      var saved=runtime.configure(message.settings);
	      event.respond({ok:true,settings:saved});return;
	    }
	    if(!message||message.type!=='reload_settings'){event.respond({ok:false});return;}
	    var current=settings.load(localStorage);
	    if(!current){event.respond({ok:false});return;}
	    runtime.reloadSettings();event.respond({ok:true});
	  }catch(ignored){event.respond({ok:false});}
	});


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var protocol = __webpack_require__(4);
	var settingsModel = __webpack_require__(5);
	var createSources = __webpack_require__(6);
	var createCommands = __webpack_require__(18);
	var createQueue = __webpack_require__(19);
	var metadata = __webpack_require__(7);
	var F = protocol.flag, M = protocol.mode, S = protocol.status, O = protocol.op;
	function positive(value) { return typeof value === 'number' && isFinite(value) && Math.floor(value) === value && value > 0 && value <= 2147483647; }
	function bounded(value, limit) { return typeof value === 'number' && isFinite(value) && Math.floor(value) === value && value >= 0 && value <= limit; }
	function copy(value) { return JSON.parse(JSON.stringify(value)); }
	
	module.exports = function createRuntime(options) {
	  options = options || {};
	  var pebble=options.pebble, now=options.now || Date.now, later=options.later || setTimeout, cancel=options.cancelLater || clearTimeout;
	  var prefs=settingsModel.load(options.storage), settingsError=!prefs;
	  if (!prefs) prefs=settingsModel.defaults(); // Rendering fallback only; never a repair write.
	  var session=0,sequence=0,nextToken=1,view=null,stopped=false,started=false,heartbeat=null,publishTimer=null,connected=true,bindingEpoch=0;
	  var identities=Object.create(null),bindings=Object.create(null),feedback=Object.create(null),lastFrameSignature='';
	  var queue=createQueue(function(message,success,failure){pebble.sendAppMessage(message,success,failure);});
	  var sources=(options.createSources || createSources)({pebble:pebble,storage:options.storage,now:now,later:later,cancelLater:cancel,
	    activitiesHost:options.activitiesHost,onChanged:function(){schedulePublish();}});
	  function result(request,value,text) {
	    if(!session)return;
	    var message={};message[protocol.keys.DB_SESSION]=session;message[protocol.keys.DB_REQUEST]=request;
	    message[protocol.keys.DB_RESULT]=value;message[protocol.keys.DB_TEXT]=protocol.text(text || '',64);
	    queue.send(message);
	  }
	  var commands=createCommands({pebble:pebble,now:now,later:later,cancelLater:cancel,lookup:function(token){
	    // Rebuild against the current authoritative catalogue immediately before
	    // dispatch. A retracted or revised source cannot retain an executable token.
	    materialize();return bindings[token] || null;
	  },sendResult:result,onPending:function(token,pending,failed){feedback[token]={pending:pending,failed:failed};schedulePublish();},
	    onRefresh:function(paths,binding){sources.refreshPaths(paths,binding);}});
	  function message(kind, values) {
	    var out={};out[protocol.keys.DB_OPERATION]=kind;
	    Object.keys(values || {}).forEach(function(name){out[protocol.keys[name]]=values[name];});return out;
	  }
	  function sourceSignature(entry) {
	    // Transport leases and command progress are not source revisions. Excluding
	    // them preserves the identity of a still-current item while time advances.
	    var stable=copy(entry);delete stable.validUntil;delete stable.token;delete stable.version;
	    stable.flags &= ~(F.PENDING|F.FAILED);return JSON.stringify([bindingEpoch,stable]);
	  }
	  function display(raw) {
	    var entry=copy(raw), signature=sourceSignature(raw), identity=identities[raw._identity];
	    if (!identity) {
	      if (nextToken > 2147483647) throw new Error('TOKEN_EXHAUSTED');
	      identity=identities[raw._identity]={token:nextToken++,version:1,signature:signature};
	    } else if(identity.signature!==signature) {
	      identity.version=identity.version===2147483647?1:identity.version+1;identity.signature=signature;
	    }
	    entry.token=identity.token;entry.version=identity.version;
	    var finite=raw._sourceValidUntil, sourceBased=!!raw._provider || !!raw._path;
	    // null-TTL SDK sources are authoritative for the live subscription. The
	    // watch gets a separate short transport lease; it never changes source age.
	    entry.validUntil=sourceBased?Math.min(finite || Infinity,Math.floor(now()/1000)+60):raw.validUntil || 0;
	    if (!isFinite(entry.validUntil)) entry.validUntil=Math.floor(now()/1000)+60;
	    if (raw._sourceValidUntil && raw._sourceValidUntil*1000<=now()) return null;
	    var status=feedback[entry.token];if(status){if(status.pending)entry.flags|=F.PENDING;if(status.failed)entry.flags|=F.FAILED;}
	    var keys=['title','subtitle','value','appLabel','actionLabel','name'];
	    keys.forEach(function(key,index){entry[key]=key==='value'&&protocol.utf8(entry[key]||'').length>48?'Too long':protocol.text(entry[key] || '',protocol.limits[index]);});
	    entry.controls=(entry.controls || []).slice(0,3).map(function(label){return protocol.text(label || '',32);});
	    while(entry.controls.length<3)entry.controls.push('');
	    bindings[entry.token]={version:entry.version,valid:raw._connected!==false,expiresAt:finite || 0,actions:raw._commands || [],openApp:raw._openApp || null,path:raw._path || null};
	    return entry;
	  }
	  function materialize() {
	    var data=settingsError?{activities:[],notification:null,pins:[],loading:false,error:'SETTINGS_UNREADABLE',connected:true,available:true}:sources.snapshot();bindings=Object.create(null);
	    var live=Object.create(null);
	    function adapt(entry){live[entry._identity]=true;return display(entry);}
	    var output={activities:data.activities.map(adapt).filter(Boolean),notification:data.notification?adapt(data.notification):null,
	      pins:data.pins.map(adapt).filter(Boolean),loading:data.loading,error:data.error,connected:data.connected,available:data.available};
	    // Keep recent absent identities only until the bounded receipt table fills.
	    // Tokens are not reused within a native session.
	    if(Object.keys(identities).length>512)Object.keys(identities).forEach(function(key){if(!live[key])delete identities[key];});
	    return output;
	  }
	  function overview(data){
	    return data.activities.slice(0,1).concat(data.notification?[data.notification]:[],data.pins.slice(0,2));
	  }
	  function snapshot() {
	    var data=materialize(),items=[],total=0,offset=0,mode=view.mode;
	    if(mode===M.OVERVIEW){items=overview(data);total=items.length;}
	    else if(mode===M.MEDIA){
	      var selected=data.activities.filter(function(entry){return entry.token===view.token;})[0];
	      if(selected && selected.flags & F.ACTION){items=[selected];total=1;}
	    }else{
	      var list=mode===M.ACTIVITIES?data.activities:data.pins;total=list.length;
	      offset=Math.min(view.offset,Math.max(0,total-5));
	      // A data reorder retains selection by exact token. Native's requested
	      // absolute index is used only when it is intentionally browsing a page.
	      if(view.token && view.preserve){
	        var index=list.map(function(entry){return entry.token;}).indexOf(view.token);
	        if(index>=0){
	          if(index<offset)offset=index;
	          else if(index>=offset+5)offset=index-4;
	          offset=Math.min(offset,Math.max(0,total-5));
	        }
	      }
	      view.offset=offset;
	      items=list.slice(offset,offset+5);
	    }
	    var status=!data.connected?S.OFFLINE:!data.available?S.ERROR:data.loading?S.LOADING:data.error?items.length?S.PARTIAL:data.error==='PERMISSION_DENIED'?S.PERMISSION:S.ERROR:S.READY;
	    if(settingsError)status=items.length?S.PARTIAL:S.ERROR;
	    if(mode===M.MEDIA&&!items.length)status=S.ERROR;
	    sequence=sequence===2147483647?1:sequence+1;
	    return {session:session,request:view.request,sequence:sequence,now:Math.max(1,Math.floor(now()/1000)),mode:mode,status:status,dark:prefs.dark,
	      total:total,offset:offset,activitiesTotal:data.activities.length,pinsTotal:data.pins.length,items:items};
	  }
	  function publish(force) {
	    if(stopped||!session||!view)return;
	    var frame;
	    try { frame=snapshot(); }
	    catch(error){result(view.request,protocol.result.FAILED,'Data unavailable');return;}
	    var signature=JSON.stringify([frame.request,frame.mode,frame.status,frame.dark,frame.total,frame.offset,frame.activitiesTotal,frame.pinsTotal,frame.items]);
	    if(!force&&signature===lastFrameSignature)return;
	    lastFrameSignature=signature;
	    var payload={};
	    try { payload[protocol.keys.DB_DATA]=protocol.encode(frame); }
	    catch(error){result(view.request,protocol.result.FAILED,'Data unavailable');return;}
	    queue.send(payload,null,function(reason){if(reason!=='SUPERSEDED')lastFrameSignature='';},'snapshot');
	  }
	  function schedulePublish(){
	    if(stopped||!session||publishTimer!==null)return;
	    publishTimer=later(function(){publishTimer=null;publish(false);},0);
	  }
	  function armHeartbeat(){
	    if(heartbeat!==null)cancel(heartbeat);
	    if(!session||stopped)return;
	    heartbeat=later(function(){heartbeat=null;syncSettings();publish(false);armHeartbeat();},30000);
	  }
	  function startSources(){if(stopped||settingsError)return;started=true;sources.start(prefs);}
	  function syncSettings(){
	    var saved=settingsModel.load(options.storage);
	    if(!saved){settingsError=true;if(started){sources.stop();started=false;}return;}
	    var wasError=settingsError;
	    settingsError=false;
	    if(wasError||JSON.stringify(saved)!==JSON.stringify(prefs)){
	      prefs=saved;lastFrameSignature='';if(started||session)startSources();
	    }
	  }
	  function receive(payload){
	    if(stopped)return;
	    var kind=protocol.get(payload,'DB_OPERATION'),incoming=protocol.get(payload,'DB_SESSION'),request=protocol.get(payload,'DB_REQUEST');
	    if(kind===O.HELLO){
	      if(!positive(incoming)||!positive(request))return;
	      if(incoming!==session){
	        queue.clear();commands.start(incoming);session=incoming;view=null;sequence=0;identities=Object.create(null);bindings=Object.create(null);feedback=Object.create(null);
	        nextToken=options.tokenSeed || Math.floor(Math.random()*1073741823)+1;lastFrameSignature='';bindingEpoch=0;connected=true;
	        if(started)sources.stop();sources.connectionChanged(true);startSources();
	      }
	      if(view&&view.request>request&&incoming===session)return;
	      if(view&&request>view.request){
	        // A new HELLO in this native session is its reconnect handshake.
	        // Replace potentially dead SDK handles once, and invalidate previous
	        // confirmations even when the freshly read value is identical.
	        bindingEpoch++;connected=true;sources.connectionChanged(false);sources.connectionChanged(true);
	      }
	      var helloMode=protocol.get(payload,'DB_MODE'),helloOffset=protocol.get(payload,'DB_OFFSET'),helloIndex=protocol.get(payload,'DB_INDEX'),helloToken=protocol.get(payload,'DB_TOKEN');
	      view={mode:bounded(helloMode,3)?helloMode:view?view.mode:M.OVERVIEW,
	        offset:bounded(helloOffset,65535)?helloOffset:view?view.offset:0,index:bounded(helloIndex,65535)?helloIndex:view?view.index:0,
	        request:request,token:bounded(helloToken,2147483647)?helloToken:view?view.token:0,preserve:true};armHeartbeat();publish(true);return;
	    }
	    if(!positive(session)||incoming!==session)return;
	    if(kind===O.CANCEL){
	      commands.stop();session=0;view=null;queue.clear();sources.stop();started=false;
	      if(heartbeat!==null)cancel(heartbeat);heartbeat=null;return;
	    }
	    if(!positive(request))return;
	    if(kind===O.FOCUS){
	      if(!view||request!==view.request||protocol.get(payload,'DB_MODE')!==view.mode)return;
	      var focusedToken=protocol.get(payload,'DB_TOKEN'),focusedVersion=protocol.get(payload,'DB_VERSION'),focusedIndex=protocol.get(payload,'DB_INDEX');
	      if(!positive(focusedToken)||!positive(focusedVersion)||!bounded(focusedIndex,65535))return;
	      var current=materialize(),list=view.mode===M.ACTIVITIES?current.activities:view.mode===M.PINNED?current.pins:
	        view.mode===M.MEDIA?current.activities.filter(function(entry){return entry.token===view.token;}):overview(current);
	      var actual=list.map(function(entry){return entry.token;}).indexOf(focusedToken);
	      if(actual<0||focusedIndex>=list.length||focusedVersion>list[actual].version)return;
	      view.token=focusedToken;view.index=actual;view.preserve=true;return;
	    }
	    if(kind===O.VIEW){
	      syncSettings();
	      var mode=protocol.get(payload,'DB_MODE'),offset=protocol.get(payload,'DB_OFFSET'),index=protocol.get(payload,'DB_INDEX'),token=protocol.get(payload,'DB_TOKEN');
	      if(!bounded(mode,3)||!bounded(offset===undefined?0:offset,65535)||!bounded(index===undefined?0:index,65535)||token!==undefined&&!bounded(token,2147483647))return;
	      if(view&&request<view.request)return;
	      view={mode:mode,offset:offset || 0,index:index || 0,request:request,token:token || 0,preserve:false};publish(true);view.preserve=true;return;
	    }
	    if(kind===O.ACTION||kind===O.OPEN){
	      var action=protocol.get(payload,'DB_ACTION'),confirmation=protocol.get(payload,'DB_CONFIRM');
	      if(kind===O.OPEN&&action===undefined)action=0;
	      if(confirmation===undefined)confirmation=0;
	      commands.execute({session:session,request:request,token:protocol.get(payload,'DB_TOKEN'),version:protocol.get(payload,'DB_VERSION'),
	        action:action,confirm:confirmation},kind===O.OPEN);
	    }
	  }
	  return {
	    ready:function(){
	      if(stopped)return;
	      queue.send(message(O.READY));
	    },message:receive,
	    configure:function(value){
	      var normalized=settingsModel.normalize(value);prefs=settingsModel.save(options.storage,normalized);settingsError=false;
	      if(started||session)startSources();lastFrameSignature='';schedulePublish();return copy(prefs);
	    },
	    configuration:function(){
	      syncSettings();schedulePublish();
	      return metadata.discover(pebble,options.storage).then(function(catalogue){return {settings:copy(prefs),catalogue:catalogue,needsRepair:settingsError};});
	    },
	    catalogue:function(){return metadata.discover(pebble,options.storage);},
	    reloadSettings:function(){syncSettings();schedulePublish();return copy(prefs);},
	    connectionChanged:function(value){if(stopped||!!value===connected)return;connected=!!value;if(connected)bindingEpoch++;sources.connectionChanged(connected);schedulePublish();},
	    stop:function(){
	      stopped=true;commands.stop();sources.stop();started=false;queue.clear();session=0;view=null;bindings=Object.create(null);identities=Object.create(null);
	      [heartbeat,publishTimer].forEach(function(timer){if(timer!==null)cancel(timer);});heartbeat=publishTimer=null;
	    }
	  };
	};


/***/ }),
/* 4 */
/***/ (function(module, exports) {

	'use strict';
	
	// Dashboard owns this bounded viewport protocol. It does not change ACT3.
	var keys={DB_OPERATION:4000,DB_SESSION:4001,DB_REQUEST:4002,DB_MODE:4003,DB_OFFSET:4004,
	  DB_TOKEN:4005,DB_VERSION:4006,DB_ACTION:4007,DB_DATA:4008,DB_RESULT:4009,
	  DB_TEXT:4010,DB_CONFIRM:4011,DB_INDEX:4012};
	var op={HELLO:1,VIEW:2,ACTION:3,OPEN:4,CANCEL:5,READY:6,FOCUS:7};
	var mode={OVERVIEW:0,ACTIVITIES:1,PINNED:2,MEDIA:3,DETAIL:3};
	var status={LOADING:0,READY:1,PARTIAL:2,OFFLINE:3,PERMISSION:4,ERROR:5};
	var result={PENDING:1,SUCCESS:2,FAILED:3,STALE:4,PERMISSION:5,CANCELLED:6,CONFIRM:7};
	var flag={ACTION:1,APP:2,MEDIA:4,PRIVATE:8,UNAVAILABLE:16,PAUSED:32,PENDING:64,
	  FAILED:128,COUNTDOWN:256,ELAPSED:512,NOTIFICATION:1024,CONFIRM:2048,LOCAL_WATCH:4096,
	  MEDIA_PREVIOUS:8192,MEDIA_TOGGLE:16384,MEDIA_NEXT:32768};
	var kind={generic:0,timer:1,media:2,notification:3,weather:4,phone:5,light:6,find:7,
	  workout:8,navigation:9,calendar:10,battery:11,scene:12};
	var fields=['title','subtitle','value','appLabel','actionLabel','name'];
	var limits=[192,128,48,32,32,64];
	function integer(value,min,max){return typeof value==='number'&&isFinite(value)&&Math.floor(value)===value&&value>=min&&value<=max;}
	function uint(value,max){if(!integer(value,0,max===undefined?4294967295:max))throw Error('Invalid protocol integer');return value;}
	function utf8(value){
	  var out=[],text=String(value===undefined||value===null?'':value);
	  for(var i=0;i<text.length;i++){
	    var c=text.charCodeAt(i);
	    if(c>=0xd800&&c<=0xdbff){var low=text.charCodeAt(i+1);if(low>=0xdc00&&low<=0xdfff){c=65536+((c-0xd800)<<10)+(low-0xdc00);i++;}else c=65533;}
	    else if(c>=0xdc00&&c<=0xdfff)c=65533;
	    if(c===0)c=65533;
	    if(c<128)out.push(c);else if(c<2048)out.push(192|(c>>6),128|(c&63));
	    else if(c<65536)out.push(224|(c>>12),128|((c>>6)&63),128|(c&63));
	    else out.push(240|(c>>18),128|((c>>12)&63),128|((c>>6)&63),128|(c&63));
	  }
	  return out;
	}
	function text(value,max){
	  var s=String(value===undefined||value===null?'':value),out='',used=0;
	  for(var i=0;i<s.length;i++){
	    var point=s.charAt(i),code=s.charCodeAt(i);
	    if(code>=0xd800&&code<=0xdbff&&s.charCodeAt(i+1)>=0xdc00&&s.charCodeAt(i+1)<=0xdfff)point+=s.charAt(++i);
	    var bytes=utf8(point);if(used+bytes.length>max)break;out+=point;used+=bytes.length;
	  }
	  return out;
	}
	function u16(out,value){uint(value,65535);out.push(value&255,(value>>>8)&255);}
	function u32(out,value){uint(value);out.push(value&255,(value>>>8)&255,(value>>>16)&255,(value>>>24)&255);}
	function picture(image){
	  if(!image)return null;
	  var w=image.width,h=image.height,p=image.palette,b=image.pixels;
	  if(!integer(w,1,40)||!integer(h,1,40)||!Array.isArray(p)||!integer(p.length,1,16)||!Array.isArray(b)||b.length!==Math.ceil(w/2)*h)return null;
	  if(p.some(function(v){return !integer(v,0,255);})||b.some(function(v){return !integer(v,0,255);}))return null;
	  for(var y=0;y<h;y++)for(var x=0;x<w;x++){
	    var pixel=b[y*Math.ceil(w/2)+(x>>1)],index=x%2?pixel&15:pixel>>4;
	    if(index>=p.length)return null;
	  }
	  return {width:w,height:h,palette:p,pixels:b};
	}
	function encode(snapshot){
	  if(!snapshot||!integer(snapshot.session,1,2147483647)||!integer(snapshot.request,1,2147483647)||
	      !integer(snapshot.sequence,1,2147483647)||!integer(snapshot.mode,0,3)||!integer(snapshot.status,0,5)||
	      !Array.isArray(snapshot.items))throw Error('Invalid Dashboard snapshot');
	  var items=snapshot.items,maximum=snapshot.mode===mode.OVERVIEW?7:snapshot.mode===mode.MEDIA?1:5;
	  if(items.length>maximum)throw Error('Too many viewport items');
	  var total=uint(snapshot.total,65535),offset=uint(snapshot.offset||0,65535);
	  if(offset>total||items.length>total-offset)throw Error('Invalid viewport range');
	  var out=[68,83,72,49],imageBudget=2048,seen={},roles=[0,0,0];
	  u32(out,snapshot.session);u32(out,snapshot.request);u32(out,snapshot.sequence);u32(out,snapshot.now);
	  out.push(snapshot.mode,snapshot.status,items.length,snapshot.dark?1:0);
	  u16(out,total);u16(out,offset);u16(out,snapshot.activitiesTotal||0);u16(out,snapshot.pinsTotal||0);
	  items.forEach(function(item){
	    if(!item||!integer(item.token,1,2147483647)||!integer(item.version,1,2147483647)||seen[item.token])throw Error('Invalid item identity');
	    seen[item.token]=true;
	    var strings=fields.map(function(field,index){
	      var bytes=utf8(item[field]);if(bytes.length>limits[index])throw Error('Oversized '+field);return bytes;
	    });
	    var role=uint(item.role||0,2),flags=uint(item.flags||0,65535),clock=uint(item.clockMode||0,2);
	    roles[role]++;
	    if((snapshot.mode===mode.PINNED&&role!==2)||((snapshot.mode===mode.ACTIVITIES||snapshot.mode===mode.MEDIA)&&role!==0))throw Error('Invalid item role');
	    if(snapshot.mode===mode.MEDIA&&!(flags&flag.ACTION))throw Error('Detail without controls');
	    var staticPin=role===2&&((flags&(flag.ACTION|flag.APP|flag.LOCAL_WATCH))||(!(flags&flag.PRIVATE)&&!strings[2].length&&!clock));
	    var notificationLauncher=role===1&&item.kind===kind.notification&&
	      (flags&~(flag.PENDING|flag.FAILED))===(flag.NOTIFICATION|flag.APP)&&!clock&&!item.anchor&&!item.baseSeconds&&
	      item.title==='Notifications'&&item.name==='Notifications'&&item.appLabel==='Notifications'&&
	      (item.subtitle==='No notifications'||item.subtitle==='Open notifications')&&!strings[2].length&&!strings[4].length&&!item.image&&
	      (!item.controls||(Array.isArray(item.controls)&&item.controls.length===3&&item.controls.every(function(label){return label==='';})));
	    if(!item.validUntil&&!staticPin&&!notificationLauncher)throw Error('Unleased source value');
	    if(clock===1&&!(flags&flag.COUNTDOWN)||clock===2&&!(flags&flag.ELAPSED)||!clock&&(item.anchor||item.baseSeconds))throw Error('Invalid clock flags');
	    var controls=[];
	    if(item.controls){
	      if(!Array.isArray(item.controls)||item.controls.length!==3)throw Error('Invalid controls');
	      item.controls.forEach(function(label){var b=utf8(label);if(b.length>32)throw Error('Oversized control label');controls.push(b.length);Array.prototype.push.apply(controls,b);});
	    }
	    var image=picture(item.image),cost=image?image.palette.length+image.pixels.length:0;
	    if(cost>imageBudget)image=null;else imageBudget-=cost;
	    u32(out,item.token);u32(out,item.version);u32(out,item.validUntil||0);u16(out,item.flags||0);
	    out.push(uint(item.kind||0,12),uint(item.clockMode||0,2));u32(out,item.anchor||0);u32(out,item.baseSeconds||0);
	    strings.forEach(function(bytes){u16(out,bytes.length);});
	    out.push(image?image.width:0,image?image.height:0,image?image.palette.length:0,uint(item.role||0,2));
	    u16(out,image?image.pixels.length:0);u16(out,controls.length);
	    strings.forEach(function(bytes){Array.prototype.push.apply(out,bytes);});
	    Array.prototype.push.apply(out,controls);
	    if(image){Array.prototype.push.apply(out,image.palette);Array.prototype.push.apply(out,image.pixels);}
	  });
	  if(snapshot.mode===mode.OVERVIEW&&(roles[0]>2||roles[1]>1||roles[2]>4))throw Error('Invalid overview roles');
	  if(out.length>8192)throw Error('Dashboard frame exceeds inbox limit');
	  return out;
	}
	function get(dict,name){if(!dict)return undefined;return dict[name]===undefined?dict[keys[name]]:dict[name];}
	module.exports={keys:keys,op:op,mode:mode,status:status,result:result,flag:flag,kind:kind,
	  encode:encode,get:get,utf8:utf8,text:text,picture:picture,limits:limits,MAX_FRAME:8192};


/***/ }),
/* 5 */
/***/ (function(module, exports) {

	'use strict';
	
	function createModel() {
	var KEY = 'dashboard.settings.v1';
	var ICONS = ['generic','timer','media','notification','weather','phone','light','find','workout','navigation','calendar','battery','scene'];
	var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
	function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
	function bytes(value) { return encodeURIComponent(value).replace(/%[0-9a-f]{2}|./gi, 'x').length; }
	function invalid(message) { throw new Error(message || 'Invalid Dashboard settings.'); }
	function known(value, names) {
	  if (!object(value) || Object.keys(value).some(function(name) { return names.indexOf(name) < 0; })) invalid('Unknown settings field.');
	}
	function string(value, length, label) {
	  if (typeof value !== 'string' || !value.length || /[\u0000-\u001f\u007f]/.test(value) || bytes(value) > length) invalid('Invalid ' + label + '.');
	  return value;
	}
	function uuid(value) {
	  if (typeof value !== 'string' || !UUID.test(value) || /^0{8}-0{4}-0{4}-0{4}-0{12}$/.test(value)) invalid('Invalid plugin or watchapp UUID.');
	  return value.toLowerCase();
	}
	function identifier(value, label) {
	  value = string(value, 64, label);
	  if (!/^[a-zA-Z0-9_.:/-]+$/.test(value)) invalid('Invalid ' + label + '.');
	  return value;
	}
	function boolean(value, fallback, label) {
	  if (value === undefined) return fallback;
	  if (typeof value !== 'boolean') invalid('Invalid ' + label + '.');
	  return value;
	}
	function json(value, depth) {
	  if (depth > 6) invalid('Action arguments are too deeply nested.');
	  if (value === null || typeof value === 'boolean' || typeof value === 'string') {
	    if (typeof value === 'string' && /[\u0000]/.test(value)) invalid('Invalid action argument text.');
	    return value;
	  }
	  if (typeof value === 'number' && isFinite(value)) return value;
	  if (Array.isArray(value)) {
	    if (value.length > 64) invalid('Too many action argument values.');
	    return value.map(function(entry) { return json(entry, depth + 1); });
	  }
	  if (!object(value)) invalid('Action arguments must contain JSON values.');
	  var result = {};
	  Object.keys(value).forEach(function(name) {
	    if (name === '__proto__' || name === 'prototype' || name === 'constructor' || bytes(name) > 64) invalid('Invalid action argument name.');
	    result[name] = json(value[name], depth + 1);
	  });
	  return result;
	}
	function reading(value) {
	  known(value, ['plugin','category','item','property','instanceId','index']);
	  var out = {category:identifier(value.category, 'source category'), item:identifier(value.item, 'source item'), property:identifier(value.property, 'reading property')};
	  if (value.plugin !== undefined) out.plugin = uuid(value.plugin);
	  if (value.instanceId !== undefined) out.instanceId = string(value.instanceId, 128, 'source instance');
	  if (value.index !== undefined) {
	    if (typeof value.index !== 'number' || value.index % 1 || value.index < 0 || value.index > 4095) invalid('Invalid source index.');
	    out.index = value.index;
	  }
	  return out;
	}
	function action(value) {
	  known(value, ['plugin','action','args','label','confirm','toggleProperty']);
	  var out = {plugin:uuid(value.plugin), action:identifier(value.action, 'action name'), label:string(value.label, 32, 'action label')};
	  if (value.args !== undefined) {
	    if (!object(value.args)) invalid('Action arguments must be an object.');
	    out.args = json(value.args, 0);
	    if (bytes(JSON.stringify(out.args)) > 2048) invalid('Action arguments exceed 2048 bytes.');
	  }
	  if (value.confirm !== undefined) out.confirm = boolean(value.confirm, false, 'action confirmation');
	  if (value.toggleProperty !== undefined) out.toggleProperty = identifier(value.toggleProperty, 'Boolean toggle property');
	  return out;
	}
	function pin(value) {
	  known(value, ['id','label','icon','builtin','reading','action','openApp']);
	  var out = {id:string(value.id, 64, 'pin ID'), label:string(value.label, 32, 'pin name')};
	  if (value.icon !== undefined) {
	    if (ICONS.indexOf(value.icon) < 0) invalid('Unknown pin icon.');
	    out.icon = value.icon;
	  }
	  if (value.builtin !== undefined) {
	    if (value.builtin !== 'find-phone') invalid('Unknown built-in pin.');
	    out.builtin = value.builtin;
	  }
	  if (value.reading !== undefined) out.reading = reading(value.reading);
	  if (value.action !== undefined) out.action = action(value.action);
	  if (out.builtin && out.action) invalid('Choose either the built-in action or a custom action.');
	  if (value.openApp !== undefined) {
	    known(value.openApp, ['watchAppUuid','label']);
	    out.openApp = {watchAppUuid:uuid(value.openApp.watchAppUuid), label:string(value.openApp.label, 32, 'app label')};
	  }
	  return out;
	}
	function strings(value, label) {
	  if (value === undefined) return [];
	  if (!Array.isArray(value) || value.length > 128) invalid('Too many ' + label + '.');
	  var seen = Object.create(null);
	  return value.map(function(entry) {
	    entry = string(entry, 192, label);
	    if (seen[entry]) invalid('Duplicate ' + label + '.');
	    seen[entry] = true; return entry;
	  });
	}
	function defaults() {
	  return {version:1, dark:false, notificationPreview:false, showNotifications:true,
	    activityOrder:[], disabledActivities:[], pins:[
	      {id:'weather', label:'Weather', icon:'weather', reading:{category:'weather', item:'location', property:'temperature', index:0}},
	      {id:'phone', label:'Phone', icon:'phone', reading:{category:'phone', item:'phone_state', property:'battery_level', index:0}},
	      {id:'watch-battery', label:'Watch', icon:'battery', reading:{category:'watch-local', item:'battery', property:'level'}},
	      {id:'find-phone', label:'Find phone', icon:'find', builtin:'find-phone'}
	    ]};
	}
	function normalize(value) {
	  known(value, ['version','dark','notificationPreview','showNotifications','activityOrder','disabledActivities','pins']);
	  if (value.version !== 1 || !Array.isArray(value.pins) || value.pins.length > 64) invalid('Invalid Dashboard settings version or pin count.');
	  var seen = Object.create(null), out = {version:1,
	    dark:boolean(value.dark, false, 'watch theme'),
	    notificationPreview:boolean(value.notificationPreview, false, 'notification preview'),
	    showNotifications:boolean(value.showNotifications, true, 'notification visibility'),
	    activityOrder:strings(value.activityOrder, 'activity priority entries'),
	    disabledActivities:strings(value.disabledActivities, 'hidden activity entries'),
	    pins:value.pins.map(function(entry) {
	      var item = pin(entry); if (seen[item.id]) invalid('Duplicate pin ID.'); seen[item.id] = true; return item;
	    })};
	  if (bytes(JSON.stringify(out)) > 32768) invalid('Dashboard settings exceed 32 KiB.');
	  return out;
	}
	function load(storage) {
	  try {
	    var encoded = storage.getItem(KEY);
	    return encoded === null || encoded === undefined ? defaults() : normalize(JSON.parse(encoded));
	  } catch (error) { return null; }
	}
	function save(storage, value) {
	  var out = normalize(value), encoded = JSON.stringify(out);
	  storage.setItem(KEY, encoded);
	  if (storage.getItem(KEY) !== encoded) invalid('Settings could not be confirmed.');
	  return out;
	}
	return {key:KEY, icons:ICONS, defaults:defaults, normalize:normalize, load:load, save:save};
	}
	module.exports = createModel();
	module.exports.browserFactory = createModel;


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// Current source data stays in RAM. No activity, track, notification, source
	// instance, action argument or artwork is written by this module.
	var MUSIC = '00000000-0000-0000-0001-000000000003';
	var FIND = '00000000-0000-0000-0001-000000000008';
	var NOTIFICATIONS = '00000000-0000-0000-0001-000000000005';
	var NOTIFICATIONS_APP = 'b2cae818-10f8-46df-ad2b-98ad2254a3c1';
	var MUSIC_APP = '1f03293d-47af-4f28-b960-f2b02a6dd757';
	var F = {ACTION:1,APP:2,MEDIA:4,PRIVATE:8,UNAVAILABLE:16,PAUSED:32,PENDING:64,FAILED:128,COUNTDOWN:256,ELAPSED:512,
	  NOTIFICATION:1024,CONFIRM:2048,LOCAL_WATCH:4096,MEDIA_PREVIOUS:8192,MEDIA_TOGGLE:16384,MEDIA_NEXT:32768};
	var K = {generic:0,timer:1,media:2,notification:3,weather:4,phone:5,light:6,find:7,workout:8,navigation:9,calendar:10,battery:11,scene:12};
	var protocol = __webpack_require__(4);
	var metadata = __webpack_require__(7);
	function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
	function uuid(value) { return typeof value === 'string' && /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(value) && !/^0{8}-0{4}-0{4}-0{4}-0{12}$/.test(value); }
	function clean(value, limit) { return typeof value === 'string' ? protocol.text(value.replace(/[\u0000-\u001f\u007f-\u009f]/g, ' ').trim(), limit || 192) : ''; }
	function text(property) {
	  if (!object(property)) return '';
	  if (property.longText && typeof property.longText.text === 'string') return clean(property.longText.text);
	  if (property.shortText && typeof property.shortText.text === 'string') return clean(property.shortText.text);
	  if (property.numericValue && typeof property.numericValue.value === 'number' && isFinite(property.numericValue.value)) {
	    var value = property.numericValue, unit = clean(value.unit,192);
	    return String(Math.round(value.value * 100) / 100) + (unit ? (/^(%|°|°C|°F)$/.test(unit) ? '' : ' ') + unit : '');
	  }
	  if (property.boolean && typeof property.boolean.value === 'boolean') return property.boolean.value ? 'On' : 'Off';
	  if (property.timestamp && typeof property.timestamp.value === 'number' && isFinite(property.timestamp.value)) {
	    var date = new Date(property.timestamp.value * 1000);
	    return ('0' + date.getHours()).slice(-2) + ':' + ('0' + date.getMinutes()).slice(-2);
	  }
	  return '';
	}
	function boolean(property) { return property && property.boolean && typeof property.boolean.value === 'boolean' ? property.boolean.value : null; }
	function essentialValue(value) { value=clean(value,192);return protocol.utf8(value).length<=48?value:'Too long'; }
	function clone(value) { return JSON.parse(JSON.stringify(value)); }
	function image(property) {
	  var picture = property && (property.image || property.icon);
	  if (!picture) return null;
	  try { return __webpack_require__(8).wire.image(picture); } catch (error) { return null; }
	}
	function emptyItem(identity, title, kind, role) {
	  return {_identity:identity, title:clean(title), subtitle:'',value:'',name:clean(title,64),appLabel:'',actionLabel:'',controls:[],
	    flags:0,kind:kind || 0,role:role || 0,clockMode:0,anchor:0,baseSeconds:0,validUntil:0,_commands:[],_openApp:null,_sourceValidUntil:null};
	}
	function declarations(plugin) { return plugin && Array.isArray(plugin.actions) ? plugin.actions.filter(object) : []; }
	function declares(plugin, category, item) {
	  return plugin && Array.isArray(plugin.sources) && plugin.sources.some(function (source) { return object(source) && source.category === category && Array.isArray(source.items) && source.items.indexOf(item) >= 0; });
	}
	function command(plugin, name, args, label, confirmation) {
	  if (!plugin || !uuid(plugin.uuid)) return null;
	  var declaration = declarations(plugin).filter(function (entry) { return entry.name === name; })[0];
	  if (!declaration || !object(args || {})) return null;
	  var parameters = declaration.parameters || {}, required = Array.isArray(parameters.required) ? parameters.required : [];
	  if (!required.every(function (key) { return Object.prototype.hasOwnProperty.call(args || {}, key); })) return null;
	  var copy = clone(args || {}), fields = parameters.properties || {};
	  if (!Object.keys(copy).every(function (key) {
	    var type = fields[key] && fields[key].type;
	    if (!type) return true;
	    if (type === 'integer') return typeof copy[key] === 'number' && Math.floor(copy[key]) === copy[key];
	    return type === 'array' ? Array.isArray(copy[key]) : type === 'object' ? object(copy[key]) : typeof copy[key] === type;
	  })) return null;
	  return {plugin:plugin.uuid,action:name,args:copy,label:clean(label || declaration.description || name,32),
	    confirm:confirmation === true || declaration.destructive === true || declaration.requiresConfirmation === true};
	}
	function finalizeActions(entry) {
	  var bits = [F.MEDIA_PREVIOUS,F.MEDIA_TOGGLE,F.MEDIA_NEXT];
	  entry.controls = [0,1,2].map(function (index) {
	    var action = entry._commands[index];
	    if (action) { entry.flags |= bits[index] | F.ACTION; if (action.confirm) entry.flags |= F.CONFIRM; }
	    return action ? action.label : '';
	  });
	  if (entry._commands[0]) entry.actionLabel = entry._commands[0].label;
	  if (entry._openApp) { entry.flags |= F.APP; entry.appLabel = clean(entry._openApp.label || entry.name,32); }
	  return entry;
	}
	function fromActivity(card, plugins, seconds) {
	  var main = card.main || {}, media = card.presentation === undefined ? card.kind === 'music' || card.kind === 'media' : card.presentation === 2;
	  var support = card.support && (!seconds || card.support.validUntil > seconds) ? card.support : null;
	  var chosen=!media&&card.compactItem===1&&support?support:main;
	  var identity = 'activity:' + card.provider + ':' + card.id;
	  var entry = emptyItem(identity, media ? main.text : card.name || card.providerName || card.caption || 'Activity', media ? K.media : K[card.kind] || K.generic, 0);
	  entry._provider = card.provider;
	  entry._sourceValidUntil = Math.min.apply(null,[card.validUntil,main.validUntil,chosen.validUntil].filter(function(value){return typeof value==='number'&&value>0;}));
	  entry._sourceRevision = card.revision;
	  entry.validUntil = entry._sourceValidUntil; entry.name = clean(card.name || card.providerName || card.caption || 'Activity',64);
	  entry._activityId = card.id;
	  entry._activityState = card.state;
	  if (media) {
	    entry.flags |= F.MEDIA; entry.subtitle = clean(support && support.text || card.caption || '',128);
	    entry.value = card.playback === 'paused' ? 'Paused' : card.playback === 'playing' ? 'Playing' : '';
	  } else {
	    if (chosen.type === 'text') entry.title = clean(chosen.text);
	    else if (chosen.type === 'value') entry.value = essentialValue(chosen.text);
	    else if (chosen.type === 'clock') {
	      entry.clockMode = chosen.mode === 'elapsed' ? 2 : 1;
	      entry.flags |= entry.clockMode === 1 ? F.COUNTDOWN : F.ELAPSED;
	      entry.baseSeconds = chosen.baseSeconds || 0;
	      entry.anchor = chosen.running ? entry.clockMode === 1 ? chosen.anchorAt + chosen.baseSeconds : chosen.anchorAt : 0;
	    }
	    if (chosen!==main&&chosen.type!=='text'&&main.type==='text')entry.title=clean(main.text);
	    var other=chosen===main?support:main;
	    entry.subtitle=clean(other&&other.type==='text'?other.text:!card.support&&card.qualifier||'',128);
	    if(entry.subtitle===entry.title)entry.subtitle='';
	  }
	  if (card.private) entry.flags |= F.PRIVATE;
	  if (card.state === 'paused' || card.playback === 'paused') entry.flags |= F.PAUSED;
	  if (card.image) entry.image = clone(card.image);
	  if (card.openApp && uuid(card.openApp.watchAppUuid)) entry._openApp = {watchAppUuid:card.openApp.watchAppUuid,label:entry.name};
	  var provider = plugins.filter(function (plugin) { return plugin.uuid === card.provider; })[0];
	  var actions = Array.isArray(card.actions) ? card.actions : [];
	  if (card.unconfirmed) actions=[];
	  actions.forEach(function (action, index) {
	    if(!object(action))return;
	    var slot = media ? action.semantic === 'previous' ? 0 : action.semantic === 'next' ? 2 :
	      (card.playback === 'paused' && ['play','resume'].indexOf(action.semantic) >= 0 || card.playback !== 'paused' && action.semantic === 'pause') ? 1 : -1 : index;
	    if (slot >= 0 && slot <= 2) entry._commands[slot] = command(provider,action.action,action.args,action.label,false);
	  });
	  return finalizeActions(entry);
	}
	function orderActivities(all,settings) {
	  function stage(entry){return entry._activityState==='completed'||entry._activityState==='cancelled'?2:entry.flags&F.PAUSED?1:0;}
	  var groups=Object.create(null),records=all.map(function(entry,index){
	    var key=entry._identity==='builtin:music'?'builtin:music':entry._provider;
	    var rank=settings.activityOrder.indexOf(entry._identity);if(rank<0)rank=settings.activityOrder.indexOf(key);
	    if(rank<0)rank=settings.activityOrder.length;
	    var record={entry:entry,index:index,rank:rank},group=rank+'|'+key;
	    (groups[group]||(groups[group]=[])).push(index);return record;
	  });
	  Object.keys(groups).forEach(function(key){
	    var positions=groups[key],ranked=positions.map(function(index){return records[index];});
	    ranked.sort(function(a,b){return stage(a.entry)-stage(b.entry)||a.index-b.index;});
	    // Reorder countdowns only in their own lifecycle slots. This retains other
	    // content/provider positions and avoids a non-transitive mixed comparator.
	    [0,1,2].forEach(function(lifecycle){
	      var slots=[];ranked.forEach(function(record,index){if(stage(record.entry)===lifecycle&&record.entry.clockMode===1)slots.push(index);});
	      var clocks=slots.map(function(index){return ranked[index];}).sort(function(a,b){
	        var x=a.entry,y=b.entry;if(!!x.anchor!==!!y.anchor)return x.anchor?-1:1;
	        return (x.anchor||x.baseSeconds)-(y.anchor||y.baseSeconds)||a.index-b.index;
	      });
	      slots.forEach(function(index,n){ranked[index]=clocks[n];});
	    });
	    var ordered=ranked.map(function(record){return record.entry;});
	    positions.forEach(function(index,n){records[index].entry=ordered[n];});
	  });
	  return records.sort(function(a,b){return a.rank-b.rank||a.index-b.index;}).map(function(record){return record.entry;});
	}
	
	module.exports = function createSources(options) {
	  var pebble = options.pebble, now = options.now || Date.now, later = options.later || setTimeout, cancel = options.cancelLater || clearTimeout;
	  var changed = options.onChanged || function () {}, settings = null, groups = Object.create(null), plugins = [], activities = null;
	  var stopped = true, connected = true, generation = 0, discoveryTimer = null, expiryTimer = null, expiryAt = 0, settleTimer = null, startedAt = 0, error = '', discovery = null;
	  function notify() { if (!stopped) { scheduleExpiry(); changed(); } }
	  function stopGroup(group) {
	    group.generation++;group.updates++;
	    if (group.read && group.read.timer !== null) cancel(group.read.timer);
	    group.read=null;
	    if (group.handle && typeof group.handle.unsubscribe === 'function') { try { group.handle.unsubscribe(); } catch (ignored) {} }
	    group.handle=null;group.envelope=null;
	  }
	  function stop() {
	    stopped=true;generation++;
	    [discoveryTimer,expiryTimer,settleTimer].forEach(function (timer) { if (timer !== null) cancel(timer); });discoveryTimer=expiryTimer=settleTimer=null;expiryAt=0;
	    Object.keys(groups).forEach(function (key) { stopGroup(groups[key]); }); groups=Object.create(null);plugins=[];
	    if (activities) activities.stop();activities=null;discovery=null;
	  }
	  function live(group) { return group && group.envelope && !group.error && (!group.expiresAt || group.expiresAt * 1000 > now()); }
	  function receive(group, envelope, run) {
	    if (stopped || !connected || run !== group.generation) return;
	    group.updates++;
	    var valid = envelope && uuid(envelope.pluginUuid) && (!group.plugin || group.plugin === envelope.pluginUuid) &&
	      Array.isArray(envelope.instances) && envelope.instances.length <= 256;
	    var expiry = envelope && envelope.validUntilMs;
	    if (expiry !== undefined && expiry !== null && (typeof expiry !== 'number' || !isFinite(expiry) || expiry <= now())) valid=false;
	    if (!valid) { group.envelope=null;group.error='INVALID_SOURCE';group.ready=true;notify();return; }
	    group.envelope=envelope;group.expiresAt=expiry === undefined || expiry === null ? null : Math.floor(expiry / 1000);group.error='';group.ready=true;notify();
	  }
	  function bind(category, item, plugin, properties, size) {
	    var key=(plugin || '*')+'|'+category+'/'+item;
	    if (groups[key]) return groups[key];
	    var group=groups[key]={key:key,category:category,item:item,plugin:plugin || null,properties:properties,iconPixelSize:size,
	      envelope:null,expiresAt:null,error:'',ready:false,handle:null,generation:1,updates:0,read:null};
	    // Reading Find My Phone starts ringing in the official plugin. It is an
	    // explicit command-only default, never an automatic read or settings probe.
	    if (category === 'phone' && item === 'find_my_phone') { group.error='ACTION_ONLY';group.ready=true;return group; }
	    if (typeof pebble.subscribeToSource !== 'function') { group.error='PLUGINS_UNAVAILABLE';group.ready=true;return group; }
	    var run=group.generation;
	    var request={category:category,item:item,onData:function (envelope) { receive(group,envelope,run); },onError:function (failure) {
	      if (stopped || !connected || run !== group.generation) return;group.updates++;group.envelope=null;group.error=failure && failure.code || 'SOURCE_UNAVAILABLE';group.ready=true;notify();
	    }};
	    if (plugin) request.plugin=plugin;if (properties) request.properties=properties;if (size) request.iconPixelSize=size;
	    try {
	      var handle=pebble.subscribeToSource(request);
	      if (!stopped && run === group.generation) group.handle=handle;
	      else if (handle && typeof handle.unsubscribe === 'function') handle.unsubscribe();
	    } catch (failure) { group.error=failure && failure.code || 'SOURCE_UNAVAILABLE';group.ready=true; }
	    return group;
	  }
	  function enumerate() {
	    var run=generation;
	    if (stopped || !connected) return Promise.resolve([]);
	    if (discovery) return discovery;
	    try { discovery=Promise.resolve(typeof pebble.enumeratePlugins === 'function' ? pebble.enumeratePlugins() : []); }
	    catch (failure) { discovery=Promise.reject(failure); }
	    discovery=discovery.then(function (value) {
	      if (stopped || !connected || run !== generation) return [];
	      if (!Array.isArray(value)) { plugins=[];error='INVALID_CATALOGUE';notify();return []; }
	      plugins=value.filter(function (plugin) { return plugin && uuid(plugin.uuid); }).slice(0,128);metadata.save(options.storage,metadata.fromPlugins(plugins));error='';notify();return plugins;
	    },function (failure) { if (!stopped && connected && run === generation) { plugins=[];error=failure && failure.code || 'PLUGINS_UNAVAILABLE';notify(); }return []; }).then(function (value) {
	      if (!stopped && connected && run === generation) {
	        discovery=null;if (discoveryTimer !== null) cancel(discoveryTimer);
	        discoveryTimer=later(function () { discoveryTimer=null;enumerate(); },60000);
	      }
	      return value;
	    });
	    return discovery;
	  }
	  function scheduleExpiry() {
	    var ends=Object.keys(groups).map(function (key) { return live(groups[key]) && groups[key].expiresAt; }).filter(Boolean);
	    var next=ends.length?Math.min.apply(null,ends):0;
	    if(expiryTimer!==null&&next===expiryAt)return;
	    if(expiryTimer!==null){cancel(expiryTimer);expiryTimer=null;}
	    expiryAt=0;
	    if (ends.length) expiryTimer=later(function () {
	      expiryTimer=null;expiryAt=0;Object.keys(groups).forEach(function (key) { var group=groups[key];if (group.expiresAt && group.expiresAt*1000<=now()) { group.updates++;group.envelope=null;group.error='SOURCE_EXPIRED'; } });notify();
	    },Math.min(2147483647,Math.max(1,(expiryAt=next)*1000-now())));
	  }
	  function findGroup(reading) { return groups[(reading.plugin || '*')+'|'+reading.category+'/'+reading.item]; }
	  function selectInstance(group, reading) {
	    if (!live(group)) return null;
	    var instances=group.envelope.instances;
	    return reading.instanceId !== undefined ? instances.filter(function (instance) { return instance && instance.instanceId === reading.instanceId; })[0] || null : instances[reading.index || 0] || null;
	  }
	  function pinItem(pin) {
	    var entry=emptyItem('pin:'+pin.id,pin.label,K[pin.icon] || K.generic,2), reading=pin.reading, group=reading && findGroup(reading), instance=group && selectInstance(group,reading), props=instance && instance.properties;
	    if (reading && reading.category === 'watch-local') { entry.kind=K.battery;entry.flags|=F.LOCAL_WATCH;entry._local=true; }
	    else if (reading) {
	      if (['weather','phone','watch'].indexOf(reading.category)<0) entry.flags|=F.PRIVATE;
	      if (reading.category==='music'||reading.category==='notifications') entry.flags|=F.PRIVATE;
	      entry._sourceValidUntil=live(group)?group.expiresAt:null;
	      entry._sourceReady=!!instance;entry._provider=live(group)?group.envelope.pluginUuid:null;
	      entry._path=reading.category+'/'+reading.item;entry._groupKey=group&&group.key;
	      entry.value=props?essentialValue(text(props[reading.property])):'';
	      entry.subtitle=props?text(props.name):'';
	      if (!entry.value) { entry.flags|=F.UNAVAILABLE;entry.value='—';entry.subtitle=!connected?'Offline':group&&group.error==='PERMISSION_DENIED'?'Allow access':'No data'; }
	      entry._sourceSignature=props?JSON.stringify([instance.instanceId,entry.value,pin.action&&pin.action.toggleProperty?boolean(props[pin.action.toggleProperty]):null]):'';
	      if (props) entry.image=image(props[reading.property]);
	      if (reading.category === 'weather') entry.kind=K.weather;
	      if (reading.category === 'phone') entry.kind=K.phone;
	    }
	    if (pin.openApp && uuid(pin.openApp.watchAppUuid)) entry._openApp=clone(pin.openApp);
	    var action=pin.action;
	    if (pin.builtin === 'find-phone') {
	      var builtin=plugins.filter(function (plugin) { return plugin.uuid === FIND; })[0];
	      entry.kind=K.find;entry._commands[0]=command(builtin,'ring',{},'Ring',false);
	    } else if (action) {
	      var provider=plugins.filter(function (plugin) { return plugin.uuid === action.plugin; })[0], args=clone(action.args || {}), valid=true;
	      if (action.toggleProperty) {
	        var on=props && boolean(props[action.toggleProperty]);
	        var declaration=provider&&declarations(provider).filter(function(candidate){return candidate.name===action.action;})[0];
	        var onSchema=declaration&&declaration.parameters&&declaration.parameters.properties&&declaration.parameters.properties.on;
	        if (on === null || !instance || group.envelope.pluginUuid !== action.plugin || !onSchema || onSchema.type!=='boolean' ||
	            Object.prototype.hasOwnProperty.call(args,'item')&&args.item!==reading.item ||
	            Object.prototype.hasOwnProperty.call(args,'instanceId')&&args.instanceId!==instance.instanceId) valid=false;
	        else { args.on=!on;args.instanceId=instance.instanceId;args.item=reading.item; }
	      }
	      if (valid) entry._commands[0]=command(provider,action.action,args,action.label,action.confirm);
	    }
	    if (entry._commands[0]) { entry.flags|=F.ACTION;if(entry._commands[0].confirm)entry.flags|=F.CONFIRM;entry.actionLabel=entry._commands[0].label; }
	    if (entry._openApp) { entry.flags|=F.APP;entry.appLabel=clean(entry._openApp.label||entry.name,32); }
	    return entry;
	  }
	  function mediaItem() {
	    var group=groups['*|music/track'], instance=group && selectInstance(group,{index:0}), props=instance && instance.properties;
	    if (!props) return null;
	    var title=text(props.title);if (!title || title === '?') return null;
	    var provider=plugins.filter(function (plugin) { return plugin.uuid === group.envelope.pluginUuid && declares(plugin,'music','track'); })[0];
	    var playing=boolean(props.playing),entry=emptyItem('builtin:music',title,K.media,0);
	    entry._provider=group.envelope.pluginUuid;entry._sourceValidUntil=group.expiresAt;entry._sourceSignature=JSON.stringify([title,text(props.artist),playing]);
	    entry.flags=F.MEDIA|F.PRIVATE|(playing===false?F.PAUSED:0);entry.subtitle=text(props.artist);if(entry.subtitle==='?')entry.subtitle='';
	    entry.name='Music';entry.value=playing===true?'Playing':playing===false?'Paused':'';entry.image=image(props.artwork);entry._path='music/track';entry._groupKey=group.key;
	    if (group.envelope.pluginUuid===MUSIC)entry._openApp={watchAppUuid:MUSIC_APP,label:'Music'};
	    if (provider && provider.uuid === MUSIC) {
	      entry._commands[0]=command(provider,'previous_track',{},'Previous',false);
	      if (playing !== null) entry._commands[1]=command(provider,'set_playing',{on:!playing},playing?'Pause':'Play',false);
	      entry._commands[2]=command(provider,'next_track',{},'Next',false);
	    }
	    return finalizeActions(entry);
	  }
	  function notificationLauncher(empty) {
	    var entry=emptyItem('builtin:notifications','Notifications',K.notification,1);
	    entry.flags=F.NOTIFICATION|F.APP;entry.subtitle=empty?'No notifications':'Open notifications';
	    entry.appLabel='Notifications';entry._openApp={watchAppUuid:NOTIFICATIONS_APP,label:'Notifications'};
	    entry._connected=connected;delete entry._sourceValidUntil;
	    return entry;
	  }
	  function notificationItem() {
	    if(!settings.showNotifications)return notificationLauncher(false);
	    var group=groups[NOTIFICATIONS+'|notifications/notification'];if (!live(group)) return notificationLauncher(false);
	    var instance=group.envelope.instances[0],props=instance && instance.properties;
	    if (!props || typeof instance.instanceId !== 'string') return notificationLauncher(group.envelope.instances.length===0);
	    var title=text(props.name), app=text(props.app);if (!title && !app) return notificationLauncher(false);
	    var entry=emptyItem('builtin:notifications',title||app,K.notification,1);
	    entry.flags=F.PRIVATE|F.NOTIFICATION|F.APP;entry._provider=group.envelope.pluginUuid;entry._instanceId=instance.instanceId;entry._sourceValidUntil=group.expiresAt;
	    entry.name=app||'Notifications';entry.subtitle=settings.notificationPreview?text(props.body):'';
	    entry._sourceSignature=JSON.stringify([title,app,entry.subtitle]);entry.appLabel='Notifications';entry.image=image(props.app_icon);
	    entry._openApp={watchAppUuid:NOTIFICATIONS_APP,label:'Notifications'};entry._connected=connected;return entry;
	  }
	  function snapshot() {
	    if (!settings) return {activities:[],notification:null,pins:[],loading:false,error:'SOURCE_UNAVAILABLE',connected:connected,available:typeof pebble.subscribeToSource==='function'};
	    var cards=activities?activities.catalogue():[], all=cards.map(function (card) { return fromActivity(card,plugins,Math.floor(now()/1000)); }), media=mediaItem(), notice=notificationItem();
	    if (media) all.push(media);
	    all=all.filter(function (entry) {
	      var key=entry._identity==='builtin:music'?'builtin:music':entry._provider;
	      return settings.disabledActivities.indexOf(key)<0 && settings.disabledActivities.indexOf(entry._identity)<0;
	    });
	    all=orderActivities(all,settings);
	    if (notice && notice._instanceId && all.some(function (entry) { return entry._provider===notice._provider && entry._activityId===notice._instanceId; })) notice=notificationLauncher(false);
	    var activityStatus=activities?activities.status():{complete:true,available:false,error:'PLUGINS_UNAVAILABLE'};
	    var errors=Object.keys(groups).map(function(key){return groups[key].error;}).filter(function(value){return value&&value!=='ACTION_ONLY';});
	    var waiting=!activityStatus.complete || Object.keys(groups).some(function (key) { return !groups[key].ready; });
	    return {activities:all.slice(0,256),notification:notice,pins:settings.pins.map(pinItem),
	      loading:waiting&&now()-startedAt<8000,
	      error:error || activityStatus.error || errors[0] || (waiting&&now()-startedAt>=8000?'SOURCE_TIMEOUT':''),connected:connected,available:typeof pebble.subscribeToSource==='function'};
	  }
	  function start(next) {
	    stop();stopped=false;settings=next;error='';generation++;startedAt=now();
	    if (!connected) { notify();return; }
	    settleTimer=later(function(){settleTimer=null;notify();},8000);
	    var host=options.activitiesHost || __webpack_require__(8);
	    activities=host.createActivities({pebble:pebble,nativeFormat:3,now:now,later:later,cancelLater:cancel,
	      send:function (payload,success) { if(success)success(); },getSettings:function () { return {enabled:true,disabledProviders:settings.disabledActivities.filter(uuid)}; },onChanged:notify});
	    activities.refresh(true,2);
	    if(settings.disabledActivities.indexOf('builtin:music')<0)
	      bind('music','track',null,['title','artist','playing','artwork'],{w:40,h:40});
	    if (settings.showNotifications) bind('notifications','notification',NOTIFICATIONS,['name','app','package','app_icon'].concat(settings.notificationPreview?['body']:[]),{w:24,h:24});
	    settings.pins.forEach(function (pin) { if (pin.reading && pin.reading.category !== 'watch-local') bind(pin.reading.category,pin.reading.item,pin.reading.plugin,null,{w:16,h:16}); });
	    enumerate();notify();
	  }
	  function refreshGroup(group) {
	    if (group.read) { group.read.again=true;return; }
	    var flight={generation:group.generation,updates:group.updates,again:false,timer:null};
	    group.read=flight;
	    function complete(envelope, received) {
	      if (group.read !== flight) return;
	      group.read=null;if (flight.timer !== null) cancel(flight.timer);
	      if (stopped || !connected || group.generation !== flight.generation) return;
	      // A subscription update/error/expiry is newer than a read already in
	      // flight. That read must never resurrect an older value or permission.
	      if (received && group.updates === flight.updates) receive(group,envelope,flight.generation);
	      if (flight.again) refreshGroup(group);
	    }
	    var request={category:group.category,item:group.item};if(group.plugin)request.plugin=group.plugin;if(group.properties)request.properties=group.properties;if(group.iconPixelSize)request.iconPixelSize=group.iconPixelSize;
	    flight.timer=later(function(){complete(null,false);},8000);
	    try { Promise.resolve(pebble.readSource(request)).then(function(envelope){complete(envelope,true);},function(){complete(null,false);}); }
	    catch(ignored) { complete(null,false); }
	  }
	  function refreshPaths(paths, binding) {
	    if (stopped || !connected || typeof pebble.readSource !== 'function') return;
	    var wanted=Array.isArray(paths)?paths:binding && binding.path?[binding.path]:[];
	    Object.keys(groups).forEach(function (key) {
	      var group=groups[key];if (wanted.indexOf(group.category+'/'+group.item)<0 || group.error==='ACTION_ONLY')return;
	      refreshGroup(group);
	    });
	  }
	  return {start:start,stop:stop,snapshot:snapshot,refreshPaths:refreshPaths,
	    connectionChanged:function(value){
	      value=!!value;if(value===connected)return;connected=value;
	      if(stopped)return;
	      if(!connected){
	        generation++;
	        [discoveryTimer,expiryTimer,settleTimer].forEach(function(timer){if(timer!==null)cancel(timer);});
	        discoveryTimer=expiryTimer=settleTimer=null;expiryAt=0;discovery=null;
	        Object.keys(groups).forEach(function(key){stopGroup(groups[key]);groups[key].ready=true;});
	        if(activities)activities.connectionChanged(false);notify();
	      }else if(settings)start(settings);
	    },
	    configuration:function(){return metadata.discover(pebble);}
	  };
	};
	module.exports.text=text;module.exports.boolean=boolean;module.exports.command=command;module.exports.fromActivity=fromActivity;module.exports.essentialValue=essentialValue;
	module.exports.constants={MUSIC:MUSIC,FIND:FIND,NOTIFICATIONS:NOTIFICATIONS,MUSIC_APP:MUSIC_APP,NOTIFICATIONS_APP:NOTIFICATIONS_APP,flag:F,kind:K};


/***/ }),
/* 7 */
/***/ (function(module, exports) {

	'use strict';
	
	// Installed plugin declarations are public metadata. Never cache a source
	// envelope, live instance, activity/card, observation or invocation arguments.
	// This module is also bundled into plugin.js, whose SDK cannot enumerate peers.
	var KEY='dashboard.catalogue.v1',MAX_BYTES=262144;
	function object(value){return !!value&&typeof value==='object'&&!Array.isArray(value);}
	function uuid(value){return typeof value==='string'&&/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(value)&&value!=='00000000-0000-0000-0000-000000000000';}
	function text(value,limit){return typeof value==='string'?value.replace(/[\u0000-\u001f\u007f-\u009f]/g,' ').trim().slice(0,limit):'';}
	function bytes(value){var size=0;for(var i=0;i<value.length;i++){var c=value.charCodeAt(i);if(c<128)size++;else if(c<2048)size+=2;else if(c>=55296&&c<=56319&&i+1<value.length&&value.charCodeAt(i+1)>=56320&&value.charCodeAt(i+1)<=57343){size+=4;i++;}else size+=3;}return size;}
	function key(value,limit){return typeof value==='string'&&value.length>0&&value.length<=limit&&!/[\u0000-\u001f\u007f-\u009f]/.test(value)&&['__proto__','prototype','constructor'].indexOf(value)<0;}
	function names(value,limit,count){return Array.isArray(value)?value.filter(function(v){return key(v,limit);}).slice(0,count):[];}
	function spend(budget,value){budget.nodes++;budget.bytes+=typeof value==='string'?bytes(value):16;if(budget.nodes>1024||budget.bytes>16384)throw Error('Schema metadata is too large.');}
	function schema(input,depth,budget){
	  if(!object(input)||depth>6)throw Error('Schema metadata is too deep.');
	  spend(budget,64);
	  var out={};
	  ['type','title','description'].forEach(function(name){if(typeof input[name]==='string'){out[name]=text(input[name],name==='description'?384:128);spend(budget,out[name]);}});
	  ['minimum','maximum','minLength','maxLength','minItems','maxItems'].forEach(function(name){if(typeof input[name]==='number'&&isFinite(input[name]))out[name]=input[name];});
	  if(typeof input.additionalProperties==='boolean')out.additionalProperties=input.additionalProperties;
	  if(Array.isArray(input.required)){
	    if(input.required.length>128||input.required.some(function(name){return !key(name,64);}))throw Error('Schema requirements are too large.');
	    out.required=input.required.slice();out.required.forEach(function(name){spend(budget,name);});
	  }
	  if(Array.isArray(input.enum)){
	    if(input.enum.length>64||input.enum.some(function(v){return !(v===null||typeof v==='boolean'||typeof v==='number'&&isFinite(v)||typeof v==='string'&&v.length<=256);}))throw Error('Schema choices are too large.');
	    out.enum=input.enum.slice();out.enum.forEach(function(v){spend(budget,v);});
	  }
	  if(object(input.properties)){
	    var fields=Object.keys(input.properties);if(fields.length>128||fields.some(function(name){return !key(name,64);}))throw Error('Schema fields are too large.');
	    out.properties={};fields.forEach(function(name){spend(budget,name);out.properties[name]=schema(input.properties[name],depth+1,budget);});
	  }
	  if(object(input.items))out.items=schema(input.items,depth+1,budget);
	  return out;
	}
	function source(input){
	  if(!object(input)||!key(input.category,64))return null;
	  var out={category:input.category,items:names(input.items,64,64),properties:{}};
	  if(!out.items.length)return null;
	  if(object(input.properties))Object.keys(input.properties).filter(function(name){return key(name,64);}).slice(0,128).forEach(function(name){out.properties[name]=names(input.properties[name],64,16);});
	  if(typeof input.supportsMultiple==='boolean')out.supportsMultiple=input.supportsMultiple;
	  return out;
	}
	function action(input){
	  if(!object(input)||!key(input.name,64))return null;
	  var out={name:input.name};
	  if(typeof input.description==='string')out.description=text(input.description,384);
	  if(object(input.parameters)){try{out.parameters=schema(input.parameters,0,{nodes:0,bytes:0});}catch(ignored){return null;}if(bytes(JSON.stringify(out.parameters))>16384)return null;}
	  if(Array.isArray(input.targets))out.targets=names(input.targets,192,64);
	  if(typeof input.destructive==='boolean')out.destructive=input.destructive;
	  if(typeof input.requiresConfirmation==='boolean')out.requiresConfirmation=input.requiresConfirmation;
	  return out;
	}
	function activitySource(value){
	  // Matches pebble-activities 0.4.4 consumer.sourceItem(plugin, 3), without
	  // starting that consumer or requiring npm modules in the config-only bundle.
	  return value.category==='activity'&&Array.isArray(value.properties.schema_version)&&value.properties.schema_version.indexOf('numericValue')>=0&&
	    value.items.some(function(item){return ['summary','live','card','session'].indexOf(item)>=0;});
	}
	function fromPlugins(input){
	  if(!Array.isArray(input))throw Error('Plugin catalogue is invalid.');
	  var seen=Object.create(null),plugins=[];
	  input.slice(0,128).forEach(function(value){
	    if(!object(value)||!uuid(value.uuid)||seen[value.uuid.toLowerCase()])return;
	    seen[value.uuid.toLowerCase()]=true;
	    plugins.push({uuid:value.uuid,name:text(value.name||value.displayName,96)||value.uuid,
	      sources:(Array.isArray(value.sources)?value.sources:[]).slice(0,64).map(source).filter(Boolean),
	      actions:(Array.isArray(value.actions)?value.actions:[]).slice(0,64).map(action).filter(Boolean)});
	  });
	  return {plugins:plugins,instances:[],activities:plugins.filter(function(plugin){return plugin.sources.some(activitySource);}).map(function(plugin){return {key:plugin.uuid,name:plugin.name};}).concat([{key:'builtin:music',name:'Music'}])};
	}
	function save(storage,catalogue){
	  if(!storage||typeof storage.setItem!=='function')return false;
	  var clean=fromPlugins(catalogue.plugins),value=JSON.stringify({version:1,plugins:clean.plugins});
	  // Large declarations keep a bounded provider list, without caching truncated
	  // action schemas that could misrepresent their required arguments.
	  if(bytes(value)>MAX_BYTES){
	    clean.plugins=clean.plugins.map(function(plugin){return {uuid:plugin.uuid,name:plugin.name,actions:[],sources:plugin.sources.filter(activitySource).slice(0,1).map(function(declaration){return {category:'activity',items:declaration.items.filter(function(item){return ['summary','live','card','session'].indexOf(item)>=0;}).slice(0,4),properties:{schema_version:['numericValue']}};})};});
	    value=JSON.stringify({version:1,plugins:clean.plugins});
	  }
	  if(bytes(value)>MAX_BYTES)return false;
	  try{if(typeof storage.getItem==='function'&&storage.getItem(KEY)===value)return true;storage.setItem(KEY,value);return true;}catch(ignored){return false;}
	}
	function load(storage){
	  try{
	    var value=storage&&storage.getItem(KEY);if(typeof value!=='string'||bytes(value)>MAX_BYTES)return null;
	    var decoded=JSON.parse(value);if(!object(decoded)||decoded.version!==1||!Array.isArray(decoded.plugins)||decoded.plugins.length>128)return null;
	    return fromPlugins(decoded.plugins);
	  }catch(ignored){return null;}
	}
	function discover(pebble,storage){
	  if(!pebble||typeof pebble.enumeratePlugins!=='function')return Promise.reject(Error('Installed plugin discovery is unavailable in this phone runtime.'));
	  try{return Promise.resolve(pebble.enumeratePlugins()).then(function(plugins){var catalogue=fromPlugins(plugins);save(storage,catalogue);return catalogue;});}
	  catch(error){return Promise.reject(error);}
	}
	module.exports={fromPlugins:fromPlugins,discover:discover,load:load,save:save,key:KEY,limit:MAX_BYTES};


/***/ }),
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// Read-only hosts do not need the native-owner publisher/storage bridge.
	// Keep the complete historical API in index.js for existing consumers.
	module.exports={
	  activity:__webpack_require__(9),
	  summary:__webpack_require__(12),
	  summaryView:__webpack_require__(13),
	  wire:__webpack_require__(10),
	  view:__webpack_require__(11),
	  selection:__webpack_require__(14),
	  createActivities:__webpack_require__(15),
	  createContext:__webpack_require__(16)
	};


/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// Public notification-style activities. The ACT2 card is an internal transport
	// adapter; plugins never arrange slots, mandatory labels, meters or layouts.
	var wire=__webpack_require__(10),view=__webpack_require__(11),MAX=wire.MAX_EPOCH;
	var LIMITS={text:192,label:64,appName:32,descriptor:512};
	var SOURCE_PROPERTIES={schema_version:['numericValue'],kind:['shortText'],state:['shortText'],revision:['numericValue'],
	  app_name:['longText'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],
	  unconfirmed:['boolean'],show_terminal:['boolean'],content:['longText'],detail:['longText'],artwork:['image','icon']};
	var FIELDS=['provider','id','kind','state','revision','appName','observedAt','validUntil','private','unconfirmed','showTerminal','content','detail','image'];
	var DATUM_FIELDS=['label','observedAt','validUntil','estimated'];
	function own(value,key){return Object.prototype.hasOwnProperty.call(value,key);}
	function known(value,keys){return wire.object(value)&&Object.keys(value).every(function(key){return keys.indexOf(key)>=0;});}
	function bool(value){return value===undefined||typeof value==='boolean';}
	function finite(value){return typeof value==='number'&&isFinite(value);}
	function string(value,limit){return typeof value==='string'&&value.length<=limit&&wire.utf8(value).length<=limit?wire.text(value,limit):null;}
	function datum(input,card){
	  if(typeof input==='string'){input={text:input};}
	  if(!wire.object(input)){return null;}
	  var keys=DATUM_FIELDS.concat(own(input,'text')?['text']:own(input,'value')?['value','unit']:['clock','deadline','seconds','since']);
	  if(!known(input,keys)||!bool(input.estimated)){return null;}
	  var out={},label=input.label===undefined?'':string(input.label,LIMITS.label);
	  if(label===null){return null;}if(label){out.label=label;}
	  if(input.observedAt!==undefined){out.observedAt=input.observedAt;}
	  if(input.validUntil!==undefined){out.validUntil=input.validUntil;}
	  if(input.estimated!==undefined){out.estimated=input.estimated;}
	  var observed=input.observedAt===undefined?card.observedAt:input.observedAt;
	  var expiry=input.validUntil===undefined?card.validUntil:input.validUntil;
	  if(!wire.integer(observed,1,card.observedAt)||!wire.integer(expiry,observed,card.validUntil)){return null;}
	  if(own(input,'text')){
	    out.text=string(input.text,LIMITS.text);if(!out.text){return null;}
	  }else if(own(input,'value')){
	    if(finite(input.value)){out.value=input.value;}
	    else if(typeof input.value==='string'&&input.unit===undefined){out.value=string(input.value,LIMITS.text);if(!out.value){return null;}}
	    else{return null;}
	    if(input.unit!==undefined){out.unit=string(input.unit,16);if(out.unit===null){return null;}}
	    if(wire.utf8(typeof out.value==='string'?out.value:view.numericText(out.value,out.unit)).length>LIMITS.text){return null;}
	  }else{
	    out.clock=input.clock;
	    if(out.clock==='countdown'){
	      if(input.since!==undefined||own(input,'deadline')===own(input,'seconds')){return null;}
	      if(own(input,'deadline')){if(!wire.integer(input.deadline,1,MAX)){return null;}out.deadline=input.deadline;}
	      else{if(!wire.integer(input.seconds,0,MAX)){return null;}out.seconds=input.seconds;}
	    }else if(out.clock==='elapsed'){
	      if(input.deadline!==undefined||input.since===undefined&&input.seconds===undefined){return null;}
	      if(input.since!==undefined){if(!wire.integer(input.since,1,observed)){return null;}out.since=input.since;}
	      if(input.seconds!==undefined){if(!wire.integer(input.seconds,0,MAX)){return null;}out.seconds=input.seconds;}
	    }else{return null;}
	  }
	  return wire.utf8(JSON.stringify(out)).length<=LIMITS.descriptor?out:null;
	}
	function normalize(input,provider){
	  if(!known(input,FIELDS)||!wire.uuid(provider||input.provider)||!wire.identity(input.id,64)||
	      !wire.integer(input.revision,1,MAX)||!wire.integer(input.observedAt,1,MAX)||
	      !wire.integer(input.validUntil,input.observedAt,MAX)||!bool(input.private)||!bool(input.unconfirmed)||!bool(input.showTerminal)){return null;}
	  var kind=input.kind===undefined?'activity':wire.identity(input.kind,24),state=input.state===undefined?'active':input.state;
	  if(!kind||!own(wire.STATES,state)){return null;}kind=kind.toLowerCase();
	  var app=input.appName===undefined?'':string(input.appName,LIMITS.appName);if(app===null){return null;}
	  var result={provider:provider||input.provider,id:input.id,kind:kind,state:state,revision:input.revision,
	    observedAt:input.observedAt,validUntil:input.validUntil,private:input.private!==false||kind==='music'||kind==='notification'||kind==='notifications',
	    unconfirmed:input.unconfirmed===true,showTerminal:input.showTerminal===true,appName:app};
	  if(result.private&&result.unconfirmed){return null;}
	  result.content=datum(input.content,result);if(!result.content){return null;}
	  result.detail=input.detail===undefined||input.detail===null?null:datum(input.detail,result);
	  if(input.detail!==undefined&&input.detail!==null&&!result.detail){return null;}
	  if(input.image!==undefined&&input.image!==null){result.image=wire.image(input.image);if(!result.image){return null;}}
	  return result;
	}
	function compiledDatum(input,card){
	  var label=input.label||card.appName||'Activity';
	  var observed=input.observedAt===undefined?card.observedAt:input.observedAt;
	  var out={label:label,observedAt:observed,validUntil:input.validUntil===undefined?card.validUntil:input.validUntil,
	    estimated:input.estimated===true,retain:!card.private};
	  if(input.text!==undefined){out.type='text';out.text=input.text;}
	  else if(input.value!==undefined){out.type='value';if(typeof input.value==='string'){out.text=input.value;}else{out.value=input.value;out.unit=input.unit||'';}}
	  else{
	    out.type='clock';out.mode=input.clock==='countdown'?'deadline':'elapsed';
	    out.running=input.deadline!==undefined||input.since!==undefined;
	    out.anchorAt=out.running?(input.since===undefined?observed:input.since):0;
	    out.baseSeconds=input.deadline===undefined?input.seconds||0:Math.max(0,input.deadline-observed);
	  }
	  return out;
	}
	function toView(input,provider){
	  var record=normalize(input,provider);if(!record){return null;}
	  var projection={provider:record.provider,id:record.id,kind:record.kind,state:record.state,revision:record.revision,
	    observedAt:record.observedAt,validUntil:record.validUntil,private:record.private,unconfirmed:record.unconfirmed,
	    showTerminal:record.showTerminal,caption:record.appName||'Activity',main:compiledDatum(record.content,record),
	    support:record.detail?compiledDatum(record.detail,record):null,image:record.image};
	  var card=view.normalize(projection);
	  // A bounded native host can omit optional detail, never an essential value,
	  // unit or clock. This does not modify the authoritative source/fingerprint.
	  if(!card&&projection.support){projection.support=null;card=view.normalize(projection);}
	  if(card){card.sourceFormat=3;if(record.appName){card.providerName=record.appName;}}
	  return card;
	}
	function scalar(p,name,shape,field){return p&&p[name]&&p[name][shape]?p[name][shape][field||'value']:undefined;}
	function parseDescriptor(p,name,optional){
	  if(!p||p[name]===undefined){return optional?null:undefined;}
	  var raw=scalar(p,name,'longText','text');
	  if(typeof raw!=='string'||raw.length>LIMITS.descriptor||wire.utf8(raw).length>LIMITS.descriptor){return undefined;}
	  try{var value=JSON.parse(raw);return wire.object(value)||typeof value==='string'?value:undefined;}catch(ignored){return undefined;}
	}
	function sourceCard(instance,provider){
	  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==3){return null;}
	  var malformed=Object.keys(SOURCE_PROPERTIES).some(function(name){
	    if(p[name]===undefined||name==='artwork'){return false;}
	    var shape=SOURCE_PROPERTIES[name][0],field=shape==='shortText'||shape==='longText'?'text':'value';
	    return !wire.object(p[name])||!wire.object(p[name][shape])||scalar(p,name,shape,field)===undefined;
	  });
	  if(malformed||p.artwork!==undefined&&(!wire.object(p.artwork)||!p.artwork.image&&!p.artwork.icon)){return null;}
	  var content=parseDescriptor(p,'content',false),detail=parseDescriptor(p,'detail',true);
	  if(content===undefined||detail===undefined){return null;}
	  return normalize({provider:provider,id:instance.instanceId,kind:scalar(p,'kind','shortText','text'),state:scalar(p,'state','shortText','text'),
	    revision:scalar(p,'revision','numericValue'),appName:scalar(p,'app_name','longText','text'),observedAt:scalar(p,'observed_at','timestamp'),
	    validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),unconfirmed:scalar(p,'unconfirmed','boolean'),
	    showTerminal:scalar(p,'show_terminal','boolean'),content:content,detail:detail,image:p.artwork&&(p.artwork.image||p.artwork.icon)},provider);
	}
	function toSourceInstance(input,request){
	  var record=normalize(input);if(!record){return null;}
	  var p={schema_version:{numericValue:{value:3}},kind:{shortText:{text:record.kind}},state:{shortText:{text:record.state}},
	    revision:{numericValue:{value:record.revision}},app_name:{longText:{text:record.appName}},observed_at:{timestamp:{value:record.observedAt}},
	    valid_until:{timestamp:{value:record.validUntil}},private:{boolean:{value:record.private}},unconfirmed:{boolean:{value:record.unconfirmed}},
	    show_terminal:{boolean:{value:record.showTerminal}},content:{longText:{text:JSON.stringify(record.content)}}};
	  if(record.detail){p.detail={longText:{text:JSON.stringify(record.detail)}};}
	  if(record.image&&request&&request.iconPixelSize){
	    var internal=view.toSourceInstance(toView(record),request);if(!internal){return null;}p.artwork=internal.properties.artwork;
	  }
	  return {instanceId:record.id,properties:p};
	}
	function fromLegacy(input,options){
	  options=options||{};var record=wire.normalize(input);if(!record){return null;}
	  var content;
	  if(record.clock==='deadline'){content={clock:'countdown'};content[record.state==='active'?'deadline':'seconds']=record.state==='active'?record.deadline:record.duration;}
	  else if(record.clock==='elapsed'){content={clock:'elapsed',seconds:record.duration};if(record.state==='active'){content.since=record.clockAt;}}
	  else if(record.kind==='timer'&&(record.state==='completed'||record.state==='cancelled')){content=record.state==='completed'?'Finished':'Cancelled';}
	  else{content=record.value===undefined?record.main:{value:record.value,unit:record.unit};}
	  return normalize({provider:record.provider,id:record.id,kind:record.kind,state:record.state,revision:record.revision,
	    appName:options.appName||'',observedAt:record.observedAt,validUntil:record.validUntil,private:record.private,
	    unconfirmed:record.unconfirmed,showTerminal:input.showTerminal===true,content:content,image:record.image});
	}
	function helper(value,options){var result={};Object.keys(options||{}).forEach(function(k){result[k]=options[k];});Object.keys(value).forEach(function(k){result[k]=value[k];});return result;}
	function value(number,unit,options){var out={value:number};if(unit!==undefined){out.unit=unit;}return helper(out,options);}
	function countdown(options){return helper({clock:'countdown'},options);}
	function elapsed(options){return helper({clock:'elapsed'},options);}
	function createProvider(options){
	  options=options||{};if(!wire.uuid(options.pluginUuid)||typeof options.getActivities!=='function'){throw new Error('INVALID_PROVIDER');}
	  var now=options.now||Date.now;
	  function source(request){
	    var input=options.getActivities(),instances=[];if(!Array.isArray(input)||input.length>wire.LIMITS.instances){throw new Error('INVALID_ACTIVITIES');}
	    var time=now(),ids=Object.create(null);
	    input.forEach(function(raw){
	      var copy={};if(!wire.object(raw)){throw new Error('INVALID_ACTIVITY');}Object.keys(raw).forEach(function(k){copy[k]=raw[k];});
	      if(copy.appName===undefined){copy.appName=options.appName;}
	      var record=normalize(copy,options.pluginUuid);if(!record||ids[record.id]){throw new Error('INVALID_ACTIVITY');}ids[record.id]=true;
	      if(record.validUntil*1000>time){var instance=toSourceInstance(record,request);if(!instance){throw new Error('INVALID_ACTIVITY');}instances.push(instance);}
	    });
	    return {validUntilMs:Math.min(MAX*1000,Math.floor(time+30000)),instances:instances};
	  }
	  function handleSource(request,respond){
	    if(!request||request.category!=='activity'||request.item!=='live'){if(respond&&typeof respond.error==='function'){respond.error('INVALID_REQUEST','Unsupported source');}return;}
	    try{respond.data(source(request));}catch(ignored){if(respond&&typeof respond.error==='function'){respond.error('INVALID_DATA','Invalid activity snapshot');}}
	  }
	  return {source:source,handleSource:handleSource};
	}
	module.exports={VERSION:3,CATEGORY:'activity',ITEM:'live',LIMITS:LIMITS,SOURCE_PROPERTIES:SOURCE_PROPERTIES,PROPERTIES:Object.keys(SOURCE_PROPERTIES),
	  normalize:normalize,toView:toView,sourceCard:sourceCard,toSourceInstance:toSourceInstance,fromLegacy:fromLegacy,
	  value:value,countdown:countdown,elapsed:elapsed,createProvider:createProvider};


/***/ }),
/* 10 */
/***/ (function(module, exports) {

	'use strict';
	
	var MAX = 4294967295;
	var STATES = {active:1, paused:2, completed:3, cancelled:4};
	var CLOCKS = {none:0, deadline:1, elapsed:2};
	var LIMITS = {providers:32, instances:16, cards:2, main:192, footer:128, id:64, kind:24, unit:16, image:40, packet:2672};
	function object(v) { return !!v && typeof v === 'object' && !Array.isArray(v); }
	function integer(v, min, max) { return typeof v === 'number' && isFinite(v) && Math.floor(v) === v && v >= min && v <= max; }
	function uuid(v) { return typeof v === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/.test(v); }
	function utf8(value) {
	  var out=[];
	  for (var i=0; i<value.length; i++) {
	    var c=value.charCodeAt(i);
	    if (c>=0xd800 && c<=0xdbff && i+1<value.length) {
	      var next=value.charCodeAt(i+1);
	      if (next>=0xdc00 && next<=0xdfff) { c=0x10000+((c-0xd800)<<10)+(next-0xdc00); i++; }
	      else { c=0xfffd; }
	    } else if (c>=0xd800 && c<=0xdfff) { c=0xfffd; }
	    if (c<128) { out.push(c); }
	    else if (c<2048) { out.push(192|(c>>6),128|(c&63)); }
	    else if (c<65536) { out.push(224|(c>>12),128|((c>>6)&63),128|(c&63)); }
	    else { out.push(240|(c>>18),128|((c>>12)&63),128|((c>>6)&63),128|(c&63)); }
	  }
	  return out;
	}
	function text(value, limit) {
	  if (typeof value !== 'string') { return ''; }
	  value=value.slice(0,4096).replace(/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g,' ').replace(/\s+/g,' ').trim();
	  if (utf8(value).length<=limit) { return value; }
	  var out='';
	  for (var i=0; i<value.length; i++) {
	    var c=value.charAt(i), code=value.charCodeAt(i);
	    if (code>=0xd800 && code<=0xdbff && i+1<value.length) { c+=value.charAt(++i); }
	    if (utf8(out+c).length>limit-3) { break; }
	    out+=c;
	  }
	  return out+'\u2026';
	}
	function identity(v, limit) { return typeof v === 'string' && v.length>0 && !/[\x00-\x1f\x7f-\x9f]/.test(v) && utf8(v).length<=limit ? v : null; }
	function bytes(v, max) {
	  if (Array.isArray(v)) { return v.length<=max && v.every(function(n){return integer(n,0,255);}) ? v.slice() : null; }
	  if (typeof v !== 'string' || v.length>Math.ceil(max/3)*4 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(v)) { return null; }
	  var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/', out=[];
	  for (var i=0;i<v.length;i+=4) {
	    var a=alphabet.indexOf(v[i]), b=alphabet.indexOf(v[i+1]), c=v[i+2]==='='?0:alphabet.indexOf(v[i+2]), d=v[i+3]==='='?0:alphabet.indexOf(v[i+3]);
	    if (v[i+2]==='=' && (b&15) || v[i+3]==='=' && v[i+2]!=='=' && (c&3)) { return null; }
	    out.push((a<<2)|(b>>4));
	    if(v[i+2]!=='=') {out.push(((b&15)<<4)|(c>>2));}
	    if(v[i+3]!=='=') {out.push(((c&3)<<6)|d);}
	  }
	  return out.length<=max ? out : null;
	}
	function image(v) {
	  if (!object(v) || !integer(v.width,1,40) || !integer(v.height,1,40)) { return null; }
	  var palette=bytes(v.palette,16), pixels=bytes(v.pixels,800), stride=Math.ceil(v.width/2);
	  if (!palette || !palette.length || !pixels || pixels.length!==stride*v.height) { return null; }
	  for (var y=0;y<v.height;y++) {
	    for (var x=0;x<v.width;x++) { var pair=pixels[y*stride+(x>>1)], n=x&1 ? pair&15 : pair>>4; if(n>=palette.length) {return null;} }
	    if(v.width&1) { pixels[y*stride+stride-1]&=240; }
	  }
	  while(palette.length<16) {palette.push(0);}
	  return {width:v.width,height:v.height,palette:palette,pixels:pixels};
	}
	function normalize(v, provider) {
	  if (!object(v) || !uuid(provider || v.provider)) { return null; }
	  var id=identity(v.id,LIMITS.id), kind=identity(typeof v.kind==='string'?v.kind.toLowerCase():v.kind,LIMITS.kind);
	  var state=v.state==='running'?'active':v.state==='finished'?'completed':v.state;
	  if(!id || !kind || !STATES[state] || !Object.prototype.hasOwnProperty.call(CLOCKS,v.clock) ||
	      !integer(v.revision,1,MAX) || !integer(v.observedAt,1,MAX) || !integer(v.validUntil,v.observedAt,MAX)) { return null; }
	  var result={provider:provider || v.provider,id:id,kind:kind,state:state,clock:v.clock,revision:v.revision,
	    observedAt:v.observedAt,validUntil:v.validUntil,deadline:v.deadline===undefined?0:v.deadline,
	    duration:v.duration===undefined?0:v.duration,clockAt:v.clockAt===undefined?0:v.clockAt,
	    main:text(v.main,LIMITS.main),footer:text(v.footer===undefined?v.name:v.footer,LIMITS.footer),unit:text(v.unit,LIMITS.unit),private:v.private!==false||kind==='music'||kind==='notification'||kind==='notifications',unconfirmed:v.unconfirmed===true};
	  if(result.private && result.unconfirmed) {return null;}
	  if(!integer(result.deadline,0,MAX) || !integer(result.duration,0,MAX) || !integer(result.clockAt,0,MAX)) { return null; }
	  if(state==='completed' || state==='cancelled') { result.clock='none';result.deadline=result.duration=result.clockAt=0; }
	  if(result.clock==='none' && (result.deadline || result.duration || result.clockAt)) {return null;}
	  if(result.clock==='deadline') {
	    if(state==='active' && (!result.deadline || result.duration || result.clockAt)) {return null;}
	    if(state==='paused' && (result.deadline || result.clockAt)) {return null;}
	  }
	  if(result.clock==='elapsed' && (result.deadline || state==='active' && !result.clockAt || state==='paused' && result.clockAt)) {return null;}
	  if(result.clock==='none' && (state==='active'||state==='paused') && !result.main && (v.value===undefined||v.value===null)) {return null;}
	  if(v.value!==undefined && v.value!==null) { if(typeof v.value!=='number'||!isFinite(v.value)) {return null;} result.value=v.value; }
	  if(v.image!==undefined && v.image!==null) {result.image=image(v.image);if(!result.image) {return null;}}
	  return result;
	}
	function put16(out, at, v) {out[at]=v&255;out[at+1]=(v>>>8)&255;}
	function put32(out, at, v) {for(var i=0;i<4;i++){out[at+i]=Math.floor(v/Math.pow(256,i))&255;}}
	function crc16(out) {var crc=65535;for(var i=0;i<out.length;i++){if(i===8||i===9){continue;}crc^=out[i]<<8;for(var n=0;n<8;n++){crc=((crc<<1)^(crc&32768?0x1021:0))&65535;}}return crc;}
	function encode(cards, options) {
	  options=options||{};
	  if(!Array.isArray(cards)||cards.length>2||!integer(options.session,2,MAX)||!integer(options.revision,1,MAX)||!integer(options.sentAt,1,MAX)) {throw new Error('INVALID_SNAPSHOT');}
	  var out=[65,67,84,49,1,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0];
	  put32(out,12,options.session);put32(out,16,options.revision);put32(out,20,options.sentAt);
	  cards.forEach(function(raw){
	    var card=normalize(raw);
	    if(!card){throw new Error('INVALID_ACTIVITY');}
	    var strings=[card.provider,card.id,card.kind,card.main,card.footer,card.unit].map(utf8), record=[];
	    for(var i=0;i<48;i++){record.push(0);}
	    record[0]=STATES[card.state];record[1]=CLOCKS[card.clock];record[2]=(card.private?1:0)|(card.image?2:0)|(card.value===undefined?0:4)|(card.unconfirmed?8:0);
	    put32(record,4,card.revision);put32(record,8,card.observedAt);put32(record,12,card.validUntil);put32(record,16,card.deadline);put32(record,20,card.duration);put32(record,24,card.clockAt);
	    if(card.value!==undefined){var b=new ArrayBuffer(8),view=new DataView(b);view.setFloat64(0,card.value,true);for(i=0;i<8;i++){record[28+i]=view.getUint8(i);}}
	    strings.forEach(function(value,i){record[36+i]=value.length;});
	    if(card.image){record[42]=card.image.width;record[43]=card.image.height;put16(record,44,card.image.pixels.length);}
	    out=out.concat(record);strings.forEach(function(value){out=out.concat(value);});
	    if(card.image){out=out.concat(card.image.palette,card.image.pixels);}
	  });
	  if(out.length>LIMITS.packet){throw new Error('SNAPSHOT_TOO_LARGE');}
	  put16(out,6,out.length);put16(out,8,crc16(out));return out;
	}
	function clockValue(card, now) {
	  if(card.clock==='deadline'){return card.state==='paused'?card.duration:Math.max(0,card.deadline-Math.max(now,card.observedAt));}
	  if(card.clock==='elapsed'){return Math.min(MAX,card.duration+(card.state==='active'?Math.max(0,now-card.clockAt):0));}
	  return null;
	}
	function formatClock(seconds) {seconds=Math.max(0,Math.floor(seconds));var hours=Math.floor(seconds/3600),minutes=Math.floor(seconds/60)%60,s=seconds%60;return hours?hours+':'+('0'+minutes).slice(-2)+':'+('0'+s).slice(-2):('0'+minutes).slice(-2)+':'+('0'+s).slice(-2);}
	module.exports={VERSION:1,CATEGORY:'activity',ITEM:'session',LIMITS:LIMITS,STATES:STATES,CLOCKS:CLOCKS,MAX_EPOCH:MAX,object:object,integer:integer,uuid:uuid,utf8:utf8,text:text,identity:identity,image:image,normalize:normalize,encode:encode,crc16:crc16,clockValue:clockValue,formatClock:formatClock};


/***/ }),
/* 11 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// ACT2 is a bounded native view. Authoritative source revisions are checked by
	// the consumer before projection; the frame sequence orders view changes.
	var wire=__webpack_require__(10);
	var MAX=wire.MAX_EPOCH;
	var TYPES={text:1,value:2,clock:3};
	var METERS={progress:1,level:2};
	var LIMITS={cards:2,packet:2672,pool:320,label:64,text:192,caption:128};
	var COMMON=['schema_version','kind','state','revision','name','caption','observed_at','valid_until','private','unconfirmed','show_terminal','artwork'];
	var SOURCE_PROPERTIES={schema_version:['numericValue'],kind:['shortText'],state:['shortText'],revision:['numericValue'],
	  name:['longText'],caption:['longText'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],unconfirmed:['boolean'],show_terminal:['boolean'],artwork:['image','icon'],
	  meter_kind:['shortText'],meter_source:['shortText'],meter_min:['numericValue'],meter_max:['numericValue']};
	['main','support'].forEach(function(prefix){
	  Object.keys({type:1,label:1,text:1,value:1,observed_at:1,valid_until:1,retain:1,estimated:1,clock:1,base:1,anchor:1,running:1}).forEach(function(suffix){
	    SOURCE_PROPERTIES[prefix+'_'+suffix]=[suffix==='value'||suffix==='base'?'numericValue':suffix==='observed_at'||suffix==='valid_until'||suffix==='anchor'?'timestamp':suffix==='retain'||suffix==='estimated'||suffix==='running'?'boolean':suffix==='type'||suffix==='clock'?'shortText':'longText'];
	  });
	});
	var PROPERTIES=Object.keys(SOURCE_PROPERTIES);
	function bool(value){return value===undefined||typeof value==='boolean';}
	function finite(value){return typeof value==='number'&&isFinite(value);}
	function clean(value,limit){return wire.text(value,limit);}
	function numericText(value,unit){return String(value)+(unit?(/^(%|°|°C|°F)$/.test(unit)?'':' ')+unit:'');}
	function scalar(properties,name,shape,field){return properties&&properties[name]&&properties[name][shape]?properties[name][shape][field||'value']:undefined;}
	function string(properties,name){var value=scalar(properties,name,'longText','text');return value===undefined?scalar(properties,name,'shortText','text'):value;}
	function datum(input,card,summaryProfile){
	  if(!wire.object(input)||!Object.prototype.hasOwnProperty.call(TYPES,input.type)||!bool(input.retain)||!bool(input.estimated)||!bool(input.running)){return null;}
	  var result={type:input.type,label:clean(input.label,LIMITS.label),text:'',
	    observedAt:input.observedAt===undefined?card.observedAt:input.observedAt,
	    validUntil:input.validUntil===undefined?card.validUntil:input.validUntil,
	    retain:input.retain===true,estimated:input.estimated===true};
	  if((!summaryProfile&&!result.label)||!wire.integer(result.observedAt,1,card.observedAt)||!wire.integer(result.validUntil,result.observedAt,card.validUntil)){return null;}
	  if(input.type==='clock'){
	    result.mode=input.mode;result.running=input.running===true;
	    result.baseSeconds=input.baseSeconds===undefined?0:input.baseSeconds;
	    result.anchorAt=input.anchorAt===undefined?0:input.anchorAt;
	    if((result.mode!=='deadline'&&result.mode!=='elapsed')||!wire.integer(result.baseSeconds,0,MAX)||
	        !wire.integer(result.anchorAt,0,result.observedAt)||(result.running?!result.anchorAt:result.anchorAt!==0)){return null;}
	    if(input.text){return null;}
	  } else {
	    if(input.running===true||input.mode!==undefined||input.baseSeconds!==undefined&&input.baseSeconds!==0||input.anchorAt!==undefined&&input.anchorAt!==0){return null;}
	    if(input.type==='value'&&input.value!==undefined){
	      if(!finite(input.value)||input.unit!==undefined&&(typeof input.unit!=='string'||wire.utf8(input.unit).length>16)){return null;}
	      result.value=input.value;result.unit=clean(input.unit,16);
	      result.text=numericText(result.value,result.unit);
	      if(input.text!==undefined&&input.text!==''&&clean(input.text,LIMITS.text)!==result.text){return null;}
	    } else {result.text=clean(input.text,LIMITS.text);}
	    if(!result.text||wire.utf8(result.text).length>LIMITS.text){return null;}
	  }
	  return result;
	}
	function poolFor(card){
	  var bytes=[],known=Object.create(null);
	  function add(value){
	    value=value||'';
	    if(Object.prototype.hasOwnProperty.call(known,value)){return known[value];}
	    var encoded=wire.utf8(value),reference={offset:bytes.length,length:encoded.length};
	    known[value]=reference;bytes=bytes.concat(encoded,[0]);return reference;
	  }
	  var refs={caption:add(card.caption),main:{label:add(card.main.label),text:add(card.main.text)}};
	  if(card.support){refs.support={label:add(card.support.label),text:add(card.support.text)};}
	  return {bytes:bytes,refs:refs};
	}
	function normalize(input,provider,summaryProfile){
	  if(!wire.object(input)||!wire.uuid(provider||input.provider)||!wire.identity(input.id,64)||!wire.identity(input.kind,24)||
	      !wire.integer(input.revision,1,MAX)||!wire.integer(input.observedAt,1,MAX)||!wire.integer(input.validUntil,input.observedAt,MAX)||
	      !Object.prototype.hasOwnProperty.call(wire.STATES,input.state)||!bool(input.private)||!bool(input.unconfirmed)||!bool(input.showTerminal)){return null;}
	  var kind=input.kind.toLowerCase(),card={provider:provider||input.provider,id:input.id,kind:kind,revision:input.revision,state:input.state,
	    observedAt:input.observedAt,validUntil:input.validUntil,private:input.private!==false||kind==='music'||kind==='notification'||kind==='notifications',
	    unconfirmed:input.unconfirmed===true,showTerminal:input.showTerminal===true,caption:clean(input.caption===undefined?input.name:input.caption,LIMITS.caption)};
	  if(card.private&&card.unconfirmed){return null;}
	  card.main=datum(input.main,card,summaryProfile);if(!card.main){return null;}
	  card.support=input.support===undefined||input.support===null?null:datum(input.support,card,summaryProfile);
	  if(input.support!==undefined&&input.support!==null&&!card.support){return null;}
	  card.meter=null;
	  if(input.meter!==undefined&&input.meter!==null){
	    var m=input.meter,target=card[m.source];
	    if(!wire.object(m)||!Object.prototype.hasOwnProperty.call(METERS,m.kind)||(m.source!=='main'&&m.source!=='support')||!target||target.type!=='value'){return null;}
	    var fraction;
	    if(m.min!==undefined||m.max!==undefined){
	      if(!finite(m.min)||!finite(m.max)||m.max<=m.min||!finite(target.value)||target.value<m.min||target.value>m.max){return null;}
	      fraction=(target.value-m.min)/(m.max-m.min);
	    } else {fraction=m.fraction;}
	    if(!finite(fraction)||fraction<0||fraction>1){return null;}
	    card.meter={kind:m.kind,source:m.source,fraction:fraction};
	    if(m.min!==undefined){card.meter.min=m.min;card.meter.max=m.max;}
	  }
	  if(input.image!==undefined&&input.image!==null){card.image=wire.image(input.image);if(!card.image){return null;}}
	  if(!summaryProfile&&poolFor(card).bytes.length>LIMITS.pool){return null;}
	  return card;
	}
	function fromLegacy(input,options){
	  options=options||{};
	  var legacy=wire.normalize(input);if(!legacy||!bool(input.showTerminal)||
	      options.timerPresentation!==undefined&&options.timerPresentation!=='detailed'&&options.timerPresentation!=='compact'){return null;}
	  var compactTimer=legacy.kind==='timer'&&options.timerPresentation==='compact';
	  var main,terminal=legacy.state==='completed'||legacy.state==='cancelled';
	  if(legacy.clock!=='none'){
	    main={type:'clock',label:legacy.clock==='deadline'?'Left':'Elapsed',mode:legacy.clock,running:legacy.state==='active',
	      baseSeconds:legacy.clock==='deadline'&&legacy.state==='active'?Math.max(0,legacy.deadline-legacy.observedAt):legacy.duration,
	      anchorAt:legacy.state==='active'?(legacy.clock==='deadline'?legacy.observedAt:legacy.clockAt):0,retain:!legacy.private};
	  } else {
	    main={type:legacy.value===undefined?'text':'value',label:terminal?'State':legacy.value===undefined?'Text':'Value',
	      text:legacy.main|| (legacy.value===undefined?(terminal?legacy.state:''):numericText(legacy.value,legacy.unit))};
	  }
	  var card={provider:legacy.provider,id:legacy.id,kind:legacy.kind,revision:legacy.revision,state:legacy.state,
	    observedAt:legacy.observedAt,validUntil:legacy.validUntil,private:legacy.private,unconfirmed:legacy.unconfirmed,
	    caption:legacy.footer,main:main,image:legacy.image};
	  if(!compactTimer&&legacy.kind==='timer'&&legacy.clock==='deadline'&&wire.integer(input.totalDuration,0,MAX)){
	    card.support={type:'clock',label:'Elapsed',mode:'elapsed',running:legacy.state==='active',
	      baseSeconds:Math.max(0,input.totalDuration-main.baseSeconds),anchorAt:legacy.state==='active'?legacy.observedAt:0,retain:!legacy.private};
	  }
	  if(options.terminalResults&&input.showTerminal!==false&&legacy.kind==='timer'&&legacy.state==='completed'){
	    card.showTerminal=true;card.main={type:'text',label:'State',text:'Finished',retain:!legacy.private};
	    if(!compactTimer&&wire.integer(input.totalDuration,0,MAX)){card.support={type:'clock',label:'Elapsed',mode:'elapsed',running:false,baseSeconds:input.totalDuration,anchorAt:0,retain:!legacy.private};}
	  }
	  if(compactTimer&&legacy.clock==='deadline'&&card.caption){
	    // One explicit identity caption fits both fields, so a host can deduplicate
	    // by exact equality without guessing which clock labels are expendable.
	    card.caption=clean(card.caption,LIMITS.label);card.main.label=card.caption;
	  }
	  // Legacy sources had separate maximum main/caption buffers. Fit the optional
	  // caption into the shared pool; never trim a structured clock or value unit.
	  var result=normalize(card);
	  for(var limit=LIMITS.caption-1;!result&&limit>=0;limit--){card.caption=clean(legacy.footer,limit);result=normalize(card);}
	  return result;
	}
	function put16(bytes,offset,value){bytes[offset]=value&255;bytes[offset+1]=(value>>>8)&255;}
	function put32(bytes,offset,value){for(var i=0;i<4;i++){bytes[offset+i]=Math.floor(value/Math.pow(256,i))&255;}}
	function writeDatum(header,offset,item,refs){
	  if(!item){return;}
	  header[offset]=TYPES[item.type];header[offset+1]=(item.type==='clock'&&item.mode==='elapsed'?1:0)|(item.running?2:0)|(item.retain?4:0)|(item.estimated?8:0);
	  put32(header,offset+4,item.observedAt);put32(header,offset+8,item.validUntil);
	  put32(header,offset+12,item.baseSeconds||0);put32(header,offset+16,item.anchorAt||0);
	  put16(header,offset+20,refs.text.offset);put16(header,offset+22,refs.text.length);
	  put16(header,offset+24,refs.label.offset);put16(header,offset+26,refs.label.length);
	}
	function encode(cards,options){
	  options=options||{};var seq=options.sequence===undefined?options.revision:options.sequence;
	  if(!Array.isArray(cards)||cards.length>2||!wire.integer(options.session,2,MAX)||!wire.integer(seq,1,MAX)||!wire.integer(options.sentAt,1,MAX)){throw new Error('INVALID_SNAPSHOT');}
	  var out=[65,67,84,50,2,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],seen=Object.create(null);
	  put32(out,12,options.session);put32(out,16,seq);put32(out,20,options.sentAt);
	  cards.forEach(function(raw){
	    var card=normalize(raw);if(!card||seen[card.provider+'|'+card.id]){throw new Error('INVALID_ACTIVITY');}seen[card.provider+'|'+card.id]=true;
	    var pool=poolFor(card),id=wire.utf8(card.id),header=[];
	    for(var i=0;i<88;i++){header.push(0);}
	    header[2]=wire.STATES[card.state];header[3]=(card.private?1:0)|(card.unconfirmed?2:0)|(card.showTerminal?4:0)|(card.image?8:0);
	    put32(header,4,card.revision);put32(header,8,card.observedAt);put32(header,12,card.validUntil);
	    header[16]=id.length;header[17]=card.image?card.image.width:0;header[18]=card.image?card.image.height:0;
	    header[19]=card.meter?METERS[card.meter.kind]:0;put16(header,20,card.image?card.image.pixels.length:0);put16(header,22,pool.bytes.length);
	    put16(header,24,pool.refs.caption.offset);put16(header,26,pool.refs.caption.length);
	    put16(header,28,card.meter?Math.round(card.meter.fraction*65535):0);header[30]=card.meter&&card.meter.source==='support'?1:0;
	    writeDatum(header,32,card.main,pool.refs.main);writeDatum(header,60,card.support,pool.refs.support);
	    var record=header.concat(wire.utf8(card.provider),id,pool.bytes);
	    if(card.image){record=record.concat(card.image.palette,card.image.pixels);}
	    put16(record,0,record.length);out=out.concat(record);
	  });
	  if(out.length>LIMITS.packet){throw new Error('SNAPSHOT_TOO_LARGE');}
	  put16(out,6,out.length);put16(out,8,wire.crc16(out));return out;
	}
	function readDatum(properties,prefix){
	  var type=string(properties,prefix+'_type');if(type===undefined){return null;}
	  var number=properties[prefix+'_value']&&properties[prefix+'_value'].numericValue;
	  var body=string(properties,prefix+'_text');
	  if(number&&(type!=='value'||body!==undefined&&body!=='')){return false;}
	  return {type:type,label:string(properties,prefix+'_label'),text:body,
	    value:number&&number.value,unit:number&&number.unit,observedAt:scalar(properties,prefix+'_observed_at','timestamp'),
	    validUntil:scalar(properties,prefix+'_valid_until','timestamp'),retain:scalar(properties,prefix+'_retain','boolean'),estimated:scalar(properties,prefix+'_estimated','boolean'),
	    mode:string(properties,prefix+'_clock'),running:scalar(properties,prefix+'_running','boolean'),
	    baseSeconds:scalar(properties,prefix+'_base','numericValue'),anchorAt:scalar(properties,prefix+'_anchor','timestamp')};
	}
	function sourceCard(instance,provider){
	  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==2){return null;}
	  var main=readDatum(p,'main'),support=readDatum(p,'support');if(!main||support===false){return null;}
	  var meterKind=string(p,'meter_kind'),meter=meterKind&&meterKind!=='none'?{kind:meterKind,source:string(p,'meter_source'),min:scalar(p,'meter_min','numericValue'),max:scalar(p,'meter_max','numericValue')}:null;
	  return normalize({provider:provider,id:instance.instanceId,kind:string(p,'kind'),revision:scalar(p,'revision','numericValue'),state:string(p,'state'),
	    observedAt:scalar(p,'observed_at','timestamp'),validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),
	    unconfirmed:scalar(p,'unconfirmed','boolean'),showTerminal:scalar(p,'show_terminal','boolean'),caption:string(p,'caption')===undefined?string(p,'name'):string(p,'caption'),
	    main:main,support:support,meter:meter,image:p.artwork&&(p.artwork.image||p.artwork.icon)});
	}
	function base64(bytes){var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return out;}
	function toSourceInstance(input,request){
	  var card=normalize(input);if(!card){return null;}
	  var p={schema_version:{numericValue:{value:2}},revision:{numericValue:{value:card.revision}},kind:{shortText:{text:card.kind}},state:{shortText:{text:card.state}},
	    name:{longText:{text:card.caption}},caption:{longText:{text:card.caption}},observed_at:{timestamp:{value:card.observedAt}},valid_until:{timestamp:{value:card.validUntil}},
	    private:{boolean:{value:card.private}},unconfirmed:{boolean:{value:card.unconfirmed}},show_terminal:{boolean:{value:card.showTerminal}}};
	  ['main','support'].forEach(function(prefix){var d=card[prefix];if(!d){return;}
	    p[prefix+'_type']={shortText:{text:d.type}};p[prefix+'_label']={longText:{text:d.label}};
	    p[prefix+'_observed_at']={timestamp:{value:d.observedAt}};p[prefix+'_valid_until']={timestamp:{value:d.validUntil}};
	    p[prefix+'_retain']={boolean:{value:d.retain}};p[prefix+'_estimated']={boolean:{value:d.estimated}};
	    if(d.type==='clock'){p[prefix+'_clock']={shortText:{text:d.mode}};p[prefix+'_base']={numericValue:{value:d.baseSeconds,unit:'s'}};p[prefix+'_anchor']={timestamp:{value:d.anchorAt}};p[prefix+'_running']={boolean:{value:d.running}};}
	    else if(d.type==='value'&&finite(d.value)){p[prefix+'_value']={numericValue:{value:d.value,unit:d.unit}};}
	    else{p[prefix+'_text']={longText:{text:d.text}};}
	  });
	  if(card.meter){if(!finite(card.meter.min)||!finite(card.meter.max)){return null;}p.meter_kind={shortText:{text:card.meter.kind}};p.meter_source={shortText:{text:card.meter.source}};p.meter_min={numericValue:{value:card.meter.min}};p.meter_max={numericValue:{value:card.meter.max}};}
	  if(card.image&&request&&request.iconPixelSize){p.artwork={image:{width:card.image.width,height:card.image.height,palette:base64(card.image.palette),pixels:base64(card.image.pixels)}};}
	  return {instanceId:card.id,properties:p};
	}
	module.exports={VERSION:2,CATEGORY:'activity',ITEM:'card',TYPES:TYPES,METERS:METERS,LIMITS:LIMITS,PROPERTIES:PROPERTIES,SOURCE_PROPERTIES:SOURCE_PROPERTIES,
	  normalize:normalize,createCard:normalize,encode:encode,fromLegacy:fromLegacy,sourceCard:sourceCard,toSourceInstance:toSourceInstance,poolFor:poolFor,numericText:numericText};


/***/ }),
/* 12 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// Schema 4 is semantic source content. Layout and source observation are never
	// supplied by fresh-read authors; imported owners use the separate snapshot path.
	var wire=__webpack_require__(10),MAX=wire.MAX_EPOCH;
	var ICONS=['activity','timer','stopwatch','media','message','call','navigation','workout','recording','download','delivery'];
	var DIRECTIONS=['turn-left','turn-right','straight','u-turn'];
	var STATES=['active','paused','completed','cancelled'];
	var PLAYBACK=['playing','paused','buffering','stopped','unknown'];
	var META_KEY='pebble.activities.summary.metadata.v1';
	var LIMITS={records:16,descriptor:1024,text:192,label:32,name:64,value:64,unit:16,actions:1536,entity:256,openApp:96};
	var SOURCE_PROPERTIES={schema_version:['numericValue'],publisher_incarnation:['longText'],publisher_mode:['shortText'],snapshot_sequence:['numericValue'],activity_count:['numericValue'],
	  revision:['numericValue'],observed_at:['timestamp'],valid_until:['timestamp'],private:['boolean'],unconfirmed:['boolean'],content:['longText'],
	  app_name:['longText'],icon:['image','icon'],artwork:['image','icon'],entity_ref:['longText'],actions:['longText'],open_app:['longText']};
	var SHARED=['id','type','name','icon','visibleUntil','entityRef','actions','openApp'];
	function own(v,k){return Object.prototype.hasOwnProperty.call(v,k);}
	function known(v,keys){return wire.object(v)&&Object.keys(v).every(function(k){return keys.indexOf(k)>=0;});}
	function finite(v){return typeof v==='number'&&isFinite(v);}
	function text(v,max){
	  if(typeof v!=='string'||/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/.test(v)){return null;}
	  var t=v.trim();
	  if(!t||wire.utf8(t).length>max||/[\ud800-\udfff]/.test(t.replace(/[\ud800-\udbff][\udc00-\udfff]/g,''))){return null;}
	  return t;
	}
	function bounded(v,max){try{return wire.utf8(JSON.stringify(v)).length<=max;}catch(ignored){return false;}}
	function jsonValue(v,depth){
	  if(v===null||typeof v==='string'||typeof v==='boolean'){return true;}
	  if(typeof v==='number'){return finite(v);}
	  if(depth<=0||typeof v!=='object'){return false;}
	  if(Array.isArray(v)){return v.every(function(x){return jsonValue(x,depth-1);});}
	  if(!wire.object(v)||Object.getPrototypeOf(v)!==Object.prototype&&Object.getPrototypeOf(v)!==null){return false;}
	  return Object.keys(v).every(function(k){return jsonValue(v[k],depth-1);});
	}
	function extension(input,name){
	  if(name==='openApp'){
	    return known(input,['watchAppUuid'])&&wire.uuid(input.watchAppUuid)&&!/^0{8}-0{4}-0{4}-0{4}-0{12}$/.test(input.watchAppUuid)?{watchAppUuid:input.watchAppUuid}:null;
	  }
	  if(name==='entityRef'){
	    if(!known(input,['category','item','instanceId'])){return null;}
	    var out={};
	    if(!['category','item','instanceId'].every(function(k){out[k]=text(input[k],64);return !!out[k];})){return null;}
	    return bounded(out,LIMITS.entity)?out:null;
	  }
	  if(!Array.isArray(input)||input.length>3){return null;}
	  var ids=Object.create(null),result=[];
	  for(var i=0;i<input.length;i++){
	    var a=input[i];if(!known(a,['id','label','action','args','semantic'])){return null;}
	    var action={id:text(a.id,32),label:text(a.label,32),action:text(a.action,64),args:a.args===undefined?{}:a.args};
	    if(!action.id||!action.label||!action.action||ids[action.id]||!wire.object(action.args)||!jsonValue(action.args,4)||!bounded(action.args,256)){return null;}
	    ids[action.id]=true;
	    if(a.semantic!==undefined){if(['play','pause','resume','stop','next','previous','cancel','acknowledge'].indexOf(a.semantic)<0){return null;}action.semantic=a.semantic;}
	    result.push(action);
	  }
	  return bounded(result,LIMITS.actions)?result:null;
	}
	function datum(input,observedAt){
	  if(!wire.object(input)){return null;}
	  var d={type:input.type},keys=['type','label'];
	  if(input.type==='text'){
	    keys.push('text');d.text=text(input.text,LIMITS.text);if(!d.text){return null;}
	  }else if(input.type==='value'){
	    keys=keys.concat(['value','unit','range','symbol']);
	    d.value=finite(input.value)?input.value:text(input.value,LIMITS.value);if(d.value===null){return null;}
	    if(input.unit!==undefined){d.unit=text(input.unit,LIMITS.unit);if(!d.unit){return null;}}
	    if(input.range!==undefined){
	      var r=input.range,min=r&&r.min===undefined?0:r&&r.min;
	      if(!known(r,['min','max'])||!finite(d.value)||!finite(min)||!finite(r.max)||r.max<=min||d.value<min||d.value>r.max){return null;}
	      d.range={min:min,max:r.max};
	    }
	    if(input.symbol!==undefined){if(DIRECTIONS.indexOf(input.symbol)<0){return null;}d.symbol=input.symbol;}
	  }else if(input.type==='clock'){
	    keys=keys.concat(['mode','deadline','since','seconds']);d.mode=input.mode;
	    if(d.mode==='countdown'){
	      if(input.since!==undefined||own(input,'deadline')===own(input,'seconds')){return null;}
	      if(own(input,'deadline')){if(!wire.integer(input.deadline,1,MAX)){return null;}d.deadline=input.deadline;}
	      else{if(!wire.integer(input.seconds,0,MAX)){return null;}d.seconds=input.seconds;}
	    }else if(d.mode==='elapsed'){
	      if(input.deadline!==undefined||input.since===undefined&&input.seconds===undefined){return null;}
	      if(input.since!==undefined){if(!wire.integer(input.since,1,observedAt||MAX)){return null;}d.since=input.since;}
	      if(input.seconds!==undefined){if(!wire.integer(input.seconds,0,MAX)){return null;}d.seconds=input.seconds;}
	    }else{return null;}
	  }else{return null;}
	  if(!known(input,keys)){return null;}
	  if(input.label!==undefined){d.label=text(input.label,LIMITS.label);if(!d.label){return null;}}
	  return d;
	}
	function descriptor(record){
	  var out={};Object.keys(record).forEach(function(k){
	    if(k==='artwork'||k==='entityRef'||k==='actions'||k==='openApp'||k==='icon'&&typeof record.icon!=='string'){return;}out[k]=record[k];
	  });return out;
	}
	function normalize(input,observedAt){
	  var keys=SHARED.concat(input&&input.type==='media'?['title','artist','artwork','itemId','playback']:['headline','detail','summary','state','result']);
	  if(!known(input,keys)||!text(input.id,64)||input.id[0]==='@'||input.id!==input.id.trim()){return null;}
	  var out={id:input.id,type:input.type};
	  if(input.name!==undefined){out.name=text(input.name,LIMITS.name);if(!out.name){return null;}}
	  if(input.icon!==undefined){
	    out.icon=typeof input.icon==='string'?(ICONS.indexOf(input.icon)>=0?input.icon:null):wire.image(input.icon);if(!out.icon){return null;}
	  }
	  if(input.visibleUntil!==undefined){if(!wire.integer(input.visibleUntil,1,MAX)){return null;}out.visibleUntil=input.visibleUntil;}
	  ['entityRef','actions','openApp'].forEach(function(k){if(input[k]!==undefined){out[k]=extension(input[k],k);}});
	  if(['entityRef','actions','openApp'].some(function(k){return own(out,k)&&out[k]===null;})){return null;}
	  if(input.type==='standard'){
	    out.headline=datum(input.headline,observedAt);if(!out.headline){return null;}
	    if(input.detail!==undefined){out.detail=datum(input.detail,observedAt);if(!out.detail){return null;}}
	    out.summary=input.summary===undefined?'headline':input.summary;
	    out.state=input.state===undefined?'active':input.state;out.result=input.result===undefined?false:input.result;
	    if(['headline','detail'].indexOf(out.summary)<0||out.summary==='detail'&&!out.detail||STATES.indexOf(out.state)<0||typeof out.result!=='boolean'||out.result&&out.state!=='completed'&&out.state!=='cancelled'){return null;}
	  }else if(input.type==='media'){
	    out.title=text(input.title,LIMITS.text);if(!out.title){return null;}
	    if(input.artist!==undefined){out.artist=text(input.artist,LIMITS.text);if(!out.artist){return null;}}
	    if(input.itemId!==undefined){out.itemId=text(input.itemId,64);if(!out.itemId){return null;}}
	    out.playback=input.playback===undefined?'unknown':input.playback;if(PLAYBACK.indexOf(out.playback)<0){return null;}
	    if(input.artwork!==undefined){out.artwork=wire.image(input.artwork);if(!out.artwork){return null;}}
	  }else{return null;}
	  return bounded(descriptor(out),LIMITS.descriptor)?out:null;
	}
	function sourceRecord(input,provider){
	  if(!wire.object(input)||!wire.uuid(provider||input.provider)||!wire.integer(input.revision,1,MAX)||
	    !wire.integer(input.observedAt,1,MAX)||!wire.integer(input.validUntil,input.observedAt,MAX)||
	    input.private!==undefined&&typeof input.private!=='boolean'||input.unconfirmed!==undefined&&typeof input.unconfirmed!=='boolean'){return null;}
	  var record=normalize(input.record,input.observedAt);if(!record){return null;}
	  var out={provider:provider||input.provider,record:record,id:record.id,type:record.type,revision:input.revision,observedAt:input.observedAt,
	    validUntil:Math.min(input.validUntil,record.visibleUntil===undefined?MAX:record.visibleUntil),private:record.type==='media'||input.private!==false,
	    unconfirmed:input.unconfirmed===true,displayName:text(input.displayName,64)||''};
	  if(out.validUntil<out.observedAt||out.private&&out.unconfirmed){return null;}
	  return out;
	}
	function scalar(p,k,shape,field){return p&&p[k]&&p[k][shape]?p[k][shape][field||'value']:undefined;}
	function parseJson(p,key,limit){var raw=scalar(p,key,'longText','text');if(typeof raw!=='string'||wire.utf8(raw).length>limit){return null;}try{return JSON.parse(raw);}catch(ignored){return null;}}
	function sourceCard(instance,provider){
	  var p=instance&&instance.properties;if(!wire.object(p)||scalar(p,'schema_version','numericValue')!==4){return null;}
	  if(!wire.integer(scalar(p,'revision','numericValue'),1,MAX)||!wire.integer(scalar(p,'observed_at','timestamp'),1,MAX)||
	      !wire.integer(scalar(p,'valid_until','timestamp'),1,MAX)||typeof scalar(p,'private','boolean')!=='boolean'||typeof scalar(p,'unconfirmed','boolean')!=='boolean'){return null;}
	  if(p.icon!==undefined&&(!wire.object(p.icon)||!p.icon.image&&!p.icon.icon)||p.artwork!==undefined&&(!wire.object(p.artwork)||!p.artwork.image&&!p.artwork.icon)){return null;}
	  var record=parseJson(p,'content',LIMITS.descriptor);if(!wire.object(record)||instance.instanceId!==record.id){return null;}
	  delete record.entityRef;delete record.actions;delete record.openApp;delete record.artwork;
	  if(record.icon&&typeof record.icon!=='string'){delete record.icon;}
	  if(p.icon!==undefined){record.icon=p.icon.image||p.icon.icon;}
	  if(p.artwork!==undefined){record.artwork=p.artwork.image||p.artwork.icon;}
	  // Malformed optional capabilities are discarded independently of content.
	  [['entity_ref','entityRef',LIMITS.entity],['actions','actions',LIMITS.actions],['open_app','openApp',LIMITS.openApp]].forEach(function(pair){
	    if(p[pair[0]]!==undefined){var value=extension(parseJson(p,pair[0],pair[2]),pair[1]);if(value!==null){record[pair[1]]=value;}}
	  });
	  return sourceRecord({record:record,revision:scalar(p,'revision','numericValue'),observedAt:scalar(p,'observed_at','timestamp'),
	    validUntil:scalar(p,'valid_until','timestamp'),private:scalar(p,'private','boolean'),unconfirmed:scalar(p,'unconfirmed','boolean'),
	    displayName:scalar(p,'app_name','longText','text')},provider);
	}
	function header(envelope){
	  if(!envelope||!Array.isArray(envelope.instances)||envelope.instances.length>17){return null;}
	  var found=envelope.instances.filter(function(i){return i&&i.instanceId==='@snapshot';});
	  if(found.length!==1){return null;}var p=found[0].properties;
	  var h={mode:scalar(p,'publisher_mode','shortText','text'),incarnation:scalar(p,'publisher_incarnation','longText','text'),sequence:scalar(p,'snapshot_sequence','numericValue'),count:scalar(p,'activity_count','numericValue')};
	  return scalar(p,'schema_version','numericValue')===4&&['fresh','snapshot'].indexOf(h.mode)>=0&&typeof h.incarnation==='string'&&text(h.incarnation,64)===h.incarnation&&wire.integer(h.sequence,1,MAX)&&wire.integer(h.count,0,16)&&h.count===envelope.instances.length-1?h:null;
	}
	function base64(bytes){var alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/',out='';for(var i=0;i<bytes.length;i+=3){var a=bytes[i],b=i+1<bytes.length?bytes[i+1]:0,c=i+2<bytes.length?bytes[i+2]:0;out+=alphabet[a>>2]+alphabet[((a&3)<<4)|(b>>4)]+(i+1<bytes.length?alphabet[((b&15)<<2)|(c>>6)]:'=')+(i+2<bytes.length?alphabet[c&63]:'=');}return out;}
	function imageProperty(image){return {image:{width:image.width,height:image.height,palette:base64(image.palette),pixels:base64(image.pixels)}};}
	function toSourceInstance(input,request){
	  var value=sourceRecord(input);if(!value){return null;}var r=value.record;
	  var p={schema_version:{numericValue:{value:4}},revision:{numericValue:{value:value.revision}},observed_at:{timestamp:{value:value.observedAt}},valid_until:{timestamp:{value:value.validUntil}},
	    private:{boolean:{value:value.private}},unconfirmed:{boolean:{value:value.unconfirmed}},content:{longText:{text:JSON.stringify(descriptor(r))}}};
	  if(value.displayName){p.app_name={longText:{text:value.displayName}};}
	  if(request&&request.iconPixelSize){if(r.icon&&typeof r.icon!=='string'){p.icon=imageProperty(r.icon);}if(r.artwork){p.artwork=imageProperty(r.artwork);}}
	  [['entityRef','entity_ref'],['actions','actions'],['openApp','open_app']].forEach(function(pair){if(r[pair[0]]!==undefined){p[pair[1]]={longText:{text:JSON.stringify(r[pair[0]])}};}});
	  return {instanceId:r.id,properties:p};
	}
	function provider(options,snapshot){
	  options=options||{};
	  if(!wire.uuid(options.pluginUuid)||!options.storage||typeof options.storage.getItem!=='function'||typeof options.storage.setItem!=='function'||typeof options[snapshot?'readSnapshot':'readCurrent']!=='function'){throw new Error('INVALID_PROVIDER');}
	  var refresh=options.refreshSeconds===undefined?30:options.refreshSeconds,validity=options.validitySeconds===undefined?90:options.validitySeconds;
	  if(!wire.integer(refresh,1,MAX)||!wire.integer(validity,refresh+1,MAX)){throw new Error('INVALID_VALIDITY');}
	  var now=options.now||Date.now,key=options.metadataKey||META_KEY;
	  function reserve(){
	    var meta;
	    try{meta=JSON.parse(options.storage.getItem(key));}catch(ignored){}
	    if(!known(meta,['version','incarnation','sequence'])||meta.version!==1||typeof meta.incarnation!=='string'||text(meta.incarnation,64)!==meta.incarnation||!wire.integer(meta.sequence,0,MAX)){
	      meta={version:1,incarnation:String(now())+'-'+String(Math.random()).slice(2),sequence:0};
	    }
	    if(meta.sequence===MAX){throw new Error('SEQUENCE_EXHAUSTED');}meta.sequence++;
	    var encoded=JSON.stringify(meta);options.storage.setItem(key,encoded);if(options.storage.getItem(key)!==encoded){throw new Error('STORAGE_UNAVAILABLE');}
	    return meta;
	  }
	  function source(request){
	    return Promise.resolve().then(function(){
	    var meta=reserve();
	    return Promise.resolve(options[snapshot?'readSnapshot':'readCurrent'](request||{})).then(function(raw){
	      var records=Array.isArray(raw)?raw:raw&&raw.records,time=now(),observed=Math.max(1,Math.floor(time/1000)),seen=Object.create(null),instances=[];
	      if(!Array.isArray(records)||records.length>16){throw new Error('INVALID_SNAPSHOT');}
	      records.forEach(function(input){
	        var entry;
	        if(snapshot){entry=typeof options.adapt==='function'?options.adapt(input):input;}
	        else{entry={record:input,revision:meta.sequence,observedAt:observed,validUntil:Math.min(MAX,observed+validity),private:true,unconfirmed:false};}
	        if(!entry){throw new Error('INVALID_SNAPSHOT');}
	        var copy={};Object.keys(entry).forEach(function(k){copy[k]=entry[k];});copy.displayName=options.displayName||copy.displayName;
	        if(copy.record&&copy.record.icon===undefined&&options.icon!==undefined){copy.record=helper({icon:options.icon},copy.record);}
	        var validated=normalize(copy.record,copy.observedAt);
	        if(!validated||seen[validated.id]){throw new Error('INVALID_SNAPSHOT');}seen[validated.id]=true;
	        copy.record=validated;
	        if(validated.visibleUntil!==undefined&&validated.visibleUntil<=observed){return;}
	        var result=sourceRecord(copy,options.pluginUuid);if(!result){throw new Error('INVALID_SNAPSHOT');}
	        if(result.record.type==='standard'&&(result.record.state==='completed'||result.record.state==='cancelled')&&!result.record.result){return;}
	        if(result.validUntil>observed){var instance=toSourceInstance(result,request);if(!instance){throw new Error('INVALID_SNAPSHOT');}instances.push(instance);}
	      });
	      var count=instances.length;
	      instances.unshift({instanceId:'@snapshot',properties:{schema_version:{numericValue:{value:4}},publisher_incarnation:{longText:{text:meta.incarnation}},publisher_mode:{shortText:{text:snapshot?'snapshot':'fresh'}},snapshot_sequence:{numericValue:{value:meta.sequence}},activity_count:{numericValue:{value:count}}}});
	      var expiry=Math.min(MAX*1000,time+(snapshot?refresh:validity)*1000);
	      if(raw&&!Array.isArray(raw)&&raw.validUntilMs!==undefined){if(!wire.integer(raw.validUntilMs,1,MAX*1000)){throw new Error('INVALID_SNAPSHOT');}expiry=Math.min(expiry,raw.validUntilMs);}
	      return {validUntilMs:expiry,instances:instances};
	    });
	    });
	  }
	  function handleSource(request,respond){
	    if(!request||request.category!=='activity'||request.item!=='summary'){if(respond&&respond.error){respond.error('INVALID_REQUEST','Unsupported source');}return Promise.resolve();}
	    return Promise.resolve().then(function(){return source(request);}).then(function(result){respond.data(result);},function(error){respond.error(error&&/^(STORAGE_UNAVAILABLE|SEQUENCE_EXHAUSTED)$/.test(error.message)?error.message:'INVALID_DATA','Activity source unavailable');});
	  }
	  return {source:source,handleSource:handleSource,sourceDeclaration:{category:'activity',items:['summary'],properties:SOURCE_PROPERTIES,supportsMultiple:true,suggestedRefreshIntervalSec:refresh}};
	}
	function helper(base,options){var result={};Object.keys(options||{}).forEach(function(k){result[k]=options[k];});Object.keys(base).forEach(function(k){result[k]=base[k];});return result;}
	function timerSnapshot(raw){
	  var original=wire.normalize(raw);if(!original||original.kind!=='timer'){return null;}
	  var headline;
	  if(original.state==='active'&&original.clock==='deadline'){headline={type:'clock',mode:'countdown',deadline:original.deadline};}
	  else if(original.state==='paused'&&original.clock==='deadline'){headline={type:'clock',mode:'countdown',seconds:original.duration};}
	  else{headline={type:'text',text:original.state==='completed'?'Finished':'Cancelled'};}
	  var record={id:original.id,type:'standard',icon:'timer',headline:headline,state:original.state,result:raw.showTerminal===true,
	    openApp:{watchAppUuid:'50e9ef12-a5ab-4369-a3b5-3447bfba5151'}};
	  var name=text(original.footer,64);if(name){record.name=name;}
	  var validUntil=original.validUntil;
	  if(original.state==='paused'){validUntil=Math.min(validUntil,original.observedAt+300);}
	  if(original.state==='active'&&original.deadline){validUntil=Math.min(validUntil,original.deadline+60);}
	  return {record:record,revision:original.revision,observedAt:original.observedAt,validUntil:validUntil,private:original.private,unconfirmed:true};
	}
	function toView(input,provider){return __webpack_require__(13).fromSummary(input,provider);}
	module.exports={VERSION:4,CATEGORY:'activity',ITEM:'summary',LIMITS:LIMITS,ICONS:ICONS,DIRECTIONS:DIRECTIONS,METADATA_KEY:META_KEY,
	  SOURCE_PROPERTIES:SOURCE_PROPERTIES,PROPERTIES:Object.keys(SOURCE_PROPERTIES),normalize:normalize,datum:datum,sourceRecord:sourceRecord,sourceCard:sourceCard,header:header,
	  descriptor:descriptor,toSourceInstance:toSourceInstance,toView:toView,extension:extension,
	  standard:function(id,options){return helper({id:id,type:'standard'},options);},media:function(id,options){return helper({id:id,type:'media'},options);},
	  text:function(value,options){return helper({type:'text',text:value},options);},
	  value:function(value,unit,options){var out={type:'value',value:value};if(unit!==undefined&&unit!==''){out.unit=unit;}return helper(out,options);},
	  countdown:function(options){return helper({type:'clock',mode:'countdown'},options);},elapsed:function(options){return helper({type:'clock',mode:'elapsed'},options);},
	  defineProvider:function(options){return provider(options,false);},defineSnapshotProvider:function(options){return provider(options,true);},adapters:{timerSnapshot:timerSnapshot}};


/***/ }),
/* 13 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	// ACT3 is the bounded two-role projection. It preserves ACT2's datum layout
	// while adding explicit media, summary and semantic-symbol metadata.
	var wire=__webpack_require__(10),view=__webpack_require__(11),summary=__webpack_require__(12),MAX=wire.MAX_EPOCH;
	var PRESENTATIONS={text:1,media:2,clock:3,value:4,ranged:5};
	var LIMITS={cards:2,packet:2672,pool:304,header:104};
	function own(v,k){return Object.prototype.hasOwnProperty.call(v,k);}
	function clone(v){return JSON.parse(JSON.stringify(v));}
	function put16(b,o,v){b[o]=v&255;b[o+1]=(v>>>8)&255;}
	function put32(b,o,v){for(var i=0;i<4;i++){b[o+i]=Math.floor(v/Math.pow(256,i))&255;}}
	function numericText(value,unit){return String(value)+(unit?(/^(%|°|°C|°F)$/.test(unit)?'':' ')+unit:'');}
	function token(value){
	  var bytes=wire.utf8(value||''),a=2166136261,b=2246822519;
	  bytes.forEach(function(x){a=(a^x)>>>0;a=(a*16777619)>>>0;b=(b^x)>>>0;b=(b*65599)>>>0;});
	  var out=[];put32(out,0,a);put32(out,4,b);return out;
	}
	function poolFor(card){
	  var bytes=[],known=Object.create(null);
	  function add(value){value=value||'';if(own(known,value)){return known[value];}var data=wire.utf8(value),ref={offset:bytes.length,length:data.length};known[value]=ref;bytes=bytes.concat(data,[0]);return ref;}
	  var refs={caption:add(card.caption),main:{label:add(card.main.label),text:add(card.main.text)},qualifier:add(card.qualifier)};
	  if(card.support){refs.support={label:add(card.support.label),text:add(card.support.text)};}
	  return {bytes:bytes,refs:refs};
	}
	function normalize(input){
	  var card=view.normalize(input,undefined,true);if(!card){return null;}
	  card.main.label=wire.text(card.main.label,32);if(card.support){card.support.label=wire.text(card.support.label,32);}
	  card.presentation=input.presentation===undefined?(card.main.type==='clock'?PRESENTATIONS.clock:card.main.type==='value'?(card.meter?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text):input.presentation;
	  card.identitySymbol=input.identitySymbol===undefined?0:input.identitySymbol;
	  card.compactItem=input.compactItem===undefined?0:input.compactItem;
	  card.directions=input.directions===undefined?[0,0]:input.directions;
	  card.qualifier=typeof input.qualifier==='string'?wire.text(input.qualifier,304):'';
	  card.visualToken=input.visualToken===undefined?[0,0,0,0,0,0,0,0]:input.visualToken;
	  if(!wire.integer(card.presentation,1,5)||!wire.integer(card.identitySymbol,0,10)||!wire.integer(card.compactItem,0,1)||card.compactItem&&!card.support||
	    !Array.isArray(card.directions)||card.directions.length!==2||!card.directions.every(function(x){return wire.integer(x,0,4);})||
	    !Array.isArray(card.visualToken)||card.visualToken.length!==8||!card.visualToken.every(function(x){return wire.integer(x,0,255);})){return null;}
	  if(card.presentation===PRESENTATIONS.media&&(card.main.type!=='text'||card.support&&card.support.type!=='text'||card.compactItem||card.meter)){return null;}
	  if(card.presentation===PRESENTATIONS.text&&card.main.type!=='text'||card.presentation===PRESENTATIONS.clock&&card.main.type!=='clock'||card.presentation===PRESENTATIONS.value&&card.main.type!=='value'||card.presentation===PRESENTATIONS.ranged&&(!card.meter||card.main.type!=='value'||card.meter.source!=='main')){return null;}
	  if(card.directions[0]&&card.main.type!=='value'||card.directions[1]&&(!card.support||card.support.type!=='value')||card.presentation!==PRESENTATIONS.media&&card.visualToken.some(function(x){return x!==0;})){return null;}
	  ['providerName','selectionKey','name','openApp','playback','sourceFormat','entityRef','actions','mediaItemId'].forEach(function(k){if(input[k]!==undefined){card[k]=clone(input[k]);}});
	  // Keep shrinking monotonic even when strings share a pool reference.
	  // Splitting a deduplicated string can increase storage, so optional aliases
	  // are omitted rather than leaving ellipsis-only context behind.
	  var fields=[['qualifier'],['caption'],['main','label'],['support','label']];
	  if(card.support&&card.support.type==='text'){fields.push(['support','text']);}
	  if(card.main.type==='text'){fields.push(['main','text']);}
	  for(var f=0;poolFor(card).bytes.length>304&&f<fields.length;f++){
	    var field=fields[f],owner=field.length===1?card:card[field[0]],key=field[field.length-1];if(!owner||!owner[key]){continue;}
	    var requiredText=key==='text'&&(field[0]==='main'||card.compactItem===1||card.presentation===PRESENTATIONS.media);
	    var before=poolFor(card).bytes.length,original=owner[key],size=wire.utf8(original).length;
	    var limit=Math.max(requiredText?8:0,size-(before-304));
	    owner[key]=limit<4?'':wire.text(original,limit);
	    if(poolFor(card).bytes.length>=before){owner[key]=requiredText?wire.text(original,8):'';}
	    if(field[0]==='support'&&key==='text'&&!owner.text){card.support=null;card.directions[1]=0;if(card.meter&&card.meter.source==='support'){card.meter=null;}}
	  }
	  if(poolFor(card).bytes.length>304||!card.main.text&&card.main.type!=='clock'||card.compactItem===1&&(!card.support||!card.support.text&&card.support.type!=='clock')){return null;}
	  return card;
	}
	function compiledDatum(d,source){
	  var out={type:d.type,label:d.label||'',observedAt:source.observedAt,validUntil:source.validUntil,retain:!source.private,estimated:false};
	  if(d.type==='text'){out.text=d.text;}
	  else if(d.type==='value'){out.text=numericText(d.value,d.unit||'');if(typeof d.value==='number'){out.value=d.value;out.unit=d.unit||'';}}
	  else{out.mode=d.mode==='countdown'?'deadline':'elapsed';out.running=d.deadline!==undefined||d.since!==undefined;out.anchorAt=out.running?(d.since===undefined?source.observedAt:d.since):0;out.baseSeconds=d.deadline===undefined?d.seconds||0:Math.max(0,d.deadline-source.observedAt);}
	  return out;
	}
	function textPart(d){return d&&d.type==='text'?(d.label?d.label+': ':'')+d.text:'';}
	function unique(parts){var seen=Object.create(null);return parts.filter(function(x){if(!x||seen[x]){return false;}seen[x]=true;return true;}).join(' · ');}
	function fromSummary(input,provider){
	  var source=summary.sourceRecord(input,provider);if(!source){return null;}
	  var r=source.record,media=r.type==='media',selected=r.summary==='detail'?1:0;
	  var card={provider:source.provider,id:r.id,kind:media?'music':typeof r.icon==='string'?r.icon:'activity',revision:source.revision,state:media?(r.playback==='paused'?'paused':'active'):r.state,
	    observedAt:source.observedAt,validUntil:source.validUntil,private:source.private,unconfirmed:source.unconfirmed,showTerminal:!media&&r.result,
	    caption:media?r.artist||'':r.name||source.displayName||'',main:media?compiledDatum({type:'text',text:r.title},source):compiledDatum(r.headline,source),
	    support:media?(r.artist?compiledDatum({type:'text',text:r.artist},source):null):(r.detail?compiledDatum(r.detail,source):null),
	    image:media?r.artwork||typeof r.icon==='object'&&r.icon:typeof r.icon==='object'?r.icon:undefined,
	    compactItem:media?0:selected,identitySymbol:summary.ICONS.indexOf(typeof r.icon==='string'?r.icon:media?'media':'activity'),
	    directions:media?[0,0]:[summary.DIRECTIONS.indexOf(r.headline.symbol)+1,summary.DIRECTIONS.indexOf(r.detail&&r.detail.symbol)+1],
	    presentation:media?PRESENTATIONS.media:r.headline.type==='clock'?PRESENTATIONS.clock:r.headline.type==='value'?(r.headline.range?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text,
	    visualToken:media?token(r.itemId===undefined?r.title:r.itemId):[0,0,0,0,0,0,0,0],
	    qualifier:media?unique([r.name,r.artist].filter(function(part){return part!==r.title;})):unique([textPart(selected?r.headline:r.detail),r.name].filter(function(part){var d=selected?r.detail:r.headline;return part!==d.label&&part!==textPart(d);})),sourceFormat:4,playback:r.playback,mediaItemId:r.itemId};
	  if(!card.image){delete card.image;}
	  if(r.headline&&r.headline.range){card.meter={kind:'progress',source:'main',min:r.headline.range.min,max:r.headline.range.max};}
	  if(r.openApp){card.openApp=r.openApp;}if(r.actions){card.actions=r.actions;}if(r.entityRef){card.entityRef=r.entityRef;}
	  if(source.displayName){card.providerName=source.displayName;}if(r.name){card.name=r.name;}
	  return normalize(card);
	}
	function fromLegacy(input){
	  var card=input&&input.main?clone(input):view.fromLegacy(input);if(!card){return null;}
	  var media=card.kind==='music';
	  card.presentation=media?PRESENTATIONS.media:card.main.type==='clock'?PRESENTATIONS.clock:card.main.type==='value'?(card.meter&&card.meter.source==='main'?PRESENTATIONS.ranged:PRESENTATIONS.value):PRESENTATIONS.text;
	  var kind=card.kind==='music'?'media':card.kind==='notification'||card.kind==='notifications'?'message':card.kind;
	  card.identitySymbol=Math.max(0,summary.ICONS.indexOf(kind));card.compactItem=0;card.directions=[0,0];card.qualifier='';
	  if(media){
	    if(card.caption&&card.caption.indexOf('__dynamic_media__')===0){card.caption=card.caption.slice('__dynamic_media__'.length);}
	    card.visualToken=token(card.main.text);card.qualifier=card.support?card.support.text:'';card.caption=card.support?card.support.text:'';
	  }
	  [card.main,card.support].forEach(function(d){if(d&&['Track','Artist','Text','Value','Left','Activity','Music',card.caption,card.providerName].indexOf(d.label)>=0){d.label='';}});
	  if(!media){card.qualifier=unique([card.support&&card.support.type==='text'?card.support.text:'',card.caption]);}
	  return normalize(card);
	}
	function writeDatum(header,offset,item,refs){
	  if(!item){return;}header[offset]=view.TYPES[item.type];header[offset+1]=(item.type==='clock'&&item.mode==='elapsed'?1:0)|(item.running?2:0)|(item.retain?4:0)|(item.estimated?8:0);
	  put32(header,offset+4,item.observedAt);put32(header,offset+8,item.validUntil);put32(header,offset+12,item.baseSeconds||0);put32(header,offset+16,item.anchorAt||0);
	  put16(header,offset+20,refs.text.offset);put16(header,offset+22,refs.text.length);put16(header,offset+24,refs.label.offset);put16(header,offset+26,refs.label.length);
	}
	function encode(cards,options){
	  options=options||{};var seq=options.sequence===undefined?options.revision:options.sequence;
	  if(!Array.isArray(cards)||cards.length>2||!wire.integer(options.session,2,MAX)||!wire.integer(seq,1,MAX)||!wire.integer(options.sentAt,1,MAX)){throw new Error('INVALID_SNAPSHOT');}
	  var out=[65,67,84,51,3,cards.length,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0],seen=Object.create(null);
	  put32(out,12,options.session);put32(out,16,seq);put32(out,20,options.sentAt);
	  cards.forEach(function(raw){
	    var card=normalize(raw);if(!card||seen[card.provider+'|'+card.id]){throw new Error('INVALID_ACTIVITY');}seen[card.provider+'|'+card.id]=true;
	    var pool=poolFor(card),id=wire.utf8(card.id),h=[];for(var i=0;i<104;i++){h.push(0);}
	    h[2]=wire.STATES[card.state];h[3]=(card.private?1:0)|(card.unconfirmed?2:0)|(card.showTerminal?4:0)|(card.image?8:0);
	    put32(h,4,card.revision);put32(h,8,card.observedAt);put32(h,12,card.validUntil);h[16]=id.length;h[17]=card.image?card.image.width:0;h[18]=card.image?card.image.height:0;h[19]=card.meter?view.METERS[card.meter.kind]:0;
	    put16(h,20,card.image?card.image.pixels.length:0);put16(h,22,pool.bytes.length);put16(h,24,pool.refs.caption.offset);put16(h,26,pool.refs.caption.length);
	    put16(h,28,card.meter?Math.round(card.meter.fraction*65535):0);h[30]=card.meter&&card.meter.source==='support'?1:0;
	    writeDatum(h,32,card.main,pool.refs.main);writeDatum(h,60,card.support,pool.refs.support);
	    h[88]=card.presentation;h[89]=card.identitySymbol;h[90]=card.compactItem;h[91]=card.directions[0]|card.directions[1]<<3;
	    put16(h,92,pool.refs.qualifier.offset);put16(h,94,pool.refs.qualifier.length);for(i=0;i<8;i++){h[96+i]=card.visualToken[i];}
	    var record=h.concat(wire.utf8(card.provider),id,pool.bytes);if(card.image){record=record.concat(card.image.palette,card.image.pixels);}put16(record,0,record.length);out=out.concat(record);
	  });
	  if(out.length>2672){throw new Error('SNAPSHOT_TOO_LARGE');}put16(out,6,out.length);put16(out,8,wire.crc16(out));return out;
	}
	function formatDatum(d,now){
	  if(d.type==='text'){return textPart(d);}
	  if(d.type==='value'){return numericText(d.value,d.unit||'');}
	  return wire.formatClock(d.mode==='countdown'?(d.deadline===undefined?d.seconds:Math.max(0,d.deadline-now)):Math.min(MAX,(d.seconds||0)+(d.since===undefined?0:Math.max(0,now-d.since))));
	}
	function compactText(record,now){
	  var r=summary.normalize(record,now);if(!r){return null;}
	  if(r.type==='media'){return unique([r.title,r.name,r.artist]);}
	  var selected=r.summary==='detail'?r.detail:r.headline,other=r.summary==='detail'?r.headline:r.detail;
	  return unique([formatDatum(selected,now),selected.type==='text'?'':selected.label,textPart(other),r.name]);
	}
	module.exports={VERSION:3,PRESENTATIONS:PRESENTATIONS,LIMITS:LIMITS,normalize:normalize,encode:encode,fromSummary:fromSummary,fromLegacy:fromLegacy,poolFor:poolFor,compactText:compactText,visualToken:token,numericText:numericText};


/***/ }),
/* 14 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var wire=__webpack_require__(10);
	var MUSIC='builtin:music';
	var NOTIFICATIONS='builtin:notifications';
	function key(value){return value===MUSIC||value===NOTIFICATIONS||wire.uuid(value)?value:null;}
	function list(value){return (Array.isArray(value)?value:[]).map(key).filter(function(v,i,a){return v&&a.indexOf(v)===i;}).slice(0,64);}
	function normalizePreferences(value){value=value&&typeof value==='object'?value:{};return {order:list(value.order),hidden:list(value.hidden)};}
	function providerKey(card){return card&&[MUSIC,NOTIFICATIONS].indexOf(card.selectionKey)>=0?card.selectionKey:card&&key(card.provider);}
	function terminal(card){return card.state==='completed'||card.state==='cancelled';}
	function countdown(card){var d=card.main;return d&&d.type==='clock'&&d.mode==='deadline'?d:null;}
	/** Pure host policy. Persist provider keys only; cards and run IDs stay transient. */
	function select(cards,options){
	  options=options||{};var prefs=normalizePreferences(options),limit=wire.integer(options.limit,0,2)?options.limit:2;
	  var entries=(Array.isArray(cards)?cards:[]).map(function(card,index){return {card:card,index:index,key:providerKey(card)};})
	    .filter(function(entry){return entry.key&&prefs.hidden.indexOf(entry.key)<0;}),positions=Object.create(null);
	  entries.forEach(function(entry,index){if(countdown(entry.card)&&!terminal(entry.card)){(positions[entry.key]||(positions[entry.key]=[])).push(index);}});
	  Object.keys(positions).forEach(function(provider){
	    var slots=positions[provider],runs=slots.map(function(index){return {card:entries[index].card,index:index};}).sort(function(a,b){
	      var ac=countdown(a.card),bc=countdown(b.card);if(ac.running!==bc.running){return ac.running?-1:1;}
	      return ac.baseSeconds+(ac.running?ac.anchorAt:0)-bc.baseSeconds-(bc.running?bc.anchorAt:0)||a.index-b.index;
	    });
	    slots.forEach(function(index,run){entries[index].card=runs[run].card;});
	  });
	  return entries
	    .sort(function(a,b){
	      var at=terminal(a.card),bt=terminal(b.card);if(at!==bt){return at?1:-1;}
	      var ar=prefs.order.indexOf(a.key),br=prefs.order.indexOf(b.key);ar=ar<0?prefs.order.length:ar;br=br<0?prefs.order.length:br;
	      if(ar!==br){return ar-br;}
	      return a.index-b.index;
	    }).slice(0,limit).map(function(entry){return entry.card;});
	}
	module.exports={select:select,normalizePreferences:normalizePreferences,providerKey:providerKey,MUSIC_KEY:MUSIC,NOTIFICATIONS_KEY:NOTIFICATIONS};


/***/ }),
/* 15 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var wire=__webpack_require__(10);
	var view=__webpack_require__(11);
	var activity=__webpack_require__(9);
	var summary=__webpack_require__(12),summaryView=__webpack_require__(13);
	var PROPERTIES=['schema_version','kind','state','clock','revision','name','main','footer','observed_at','valid_until','deadline','duration','clock_at','private','unconfirmed','value','artwork'];
	function scalar(p,name,shape,field) {return p && p[name] && p[name][shape] ? p[name][shape][field||'value'] : undefined;}
	function string(p,name) {var v=scalar(p,name,'longText','text');return v===undefined?scalar(p,name,'shortText','text'):v;}
	function sourceCard(instance,provider) {
	  if(!instance || !wire.object(instance.properties)) {return null;}
	  var p=instance.properties;
	  if(scalar(p,'schema_version','numericValue')!==1) {return null;}
	  var number=p.value && p.value.numericValue;
	  return wire.normalize({id:instance.instanceId,kind:string(p,'kind'),state:string(p,'state'),clock:string(p,'clock'),
	    revision:scalar(p,'revision','numericValue'),observedAt:scalar(p,'observed_at','timestamp'),validUntil:scalar(p,'valid_until','timestamp'),
	    deadline:scalar(p,'deadline','timestamp'),duration:scalar(p,'duration','numericValue'),clockAt:scalar(p,'clock_at','timestamp'),
	    main:string(p,'main')===undefined?string(p,'value'):string(p,'main'),footer:string(p,'footer')===undefined?string(p,'name'):string(p,'footer'),
	    private:scalar(p,'private','boolean')!==false,unconfirmed:scalar(p,'unconfirmed','boolean')===true,value:number && number.value,unit:number && number.unit,
	    image:p.artwork && (p.artwork.image || p.artwork.icon)},provider);
	}
	function sourceItem(plugin,format) {
	  if(!plugin||!wire.uuid(plugin.uuid)||!Array.isArray(plugin.sources)){return null;}
	  var items=[];
	  plugin.sources.forEach(function(source){if(wire.object(source)&&source.category===wire.CATEGORY&&Array.isArray(source.items)&&source.properties&&
	    Array.isArray(source.properties.schema_version)&&source.properties.schema_version.indexOf('numericValue')>=0){items=items.concat(source.items);}});
	  return format>=3&&items.indexOf(summary.ITEM)>=0?summary.ITEM:
	    format>=2&&items.indexOf(activity.ITEM)>=0?activity.ITEM:
	    format>=2&&items.indexOf(view.ITEM)>=0?view.ITEM:items.indexOf(wire.ITEM)>=0?wire.ITEM:null;
	}
	function compatible(plugin,format) {
	  return !!sourceItem(plugin,format);
	}
	function errorCode(error) {return error && typeof error.code==='string' && /^[A-Z0-9_]{1,48}$/.test(error.code)?error.code:'UNKNOWN';}
	function clone(value) {return JSON.parse(JSON.stringify(value));}
	function sourceFingerprint(source) {
	  // Omit mutable capabilities without first copying the complete bitmap and
	  // parsing it back. The source has already passed its format's validation.
	  var copy={};
	  Object.keys(source).forEach(function(name){if(name!=='unconfirmed'&&name!=='displayName'){copy[name]=source[name];}});
	  if(source.record){
	    copy.record={};Object.keys(source.record).forEach(function(name){
	      if(name!=='actions'&&name!=='entityRef'&&name!=='openApp'){copy.record[name]=source.record[name];}
	    });
	  }
	  return JSON.stringify(copy);
	}
	module.exports=function createActivities(options) {
	  options=options||{};
	  var nativeFormat=options.nativeFormat===3?3:options.nativeFormat===2?2:1,codec=nativeFormat===3?summaryView:nativeFormat===2?view:wire;
	  var pebble=options.pebble||{}, now=options.now||Date.now, later=options.later||setTimeout, cancel=options.cancelLater||clearTimeout;
	  var keys=options.keys||{}, send=options.send, groups=Object.create(null), session=0, sequence=0, generation=0;
	  var stopped=false,connected=true,enabled=true,available=typeof pebble.enumeratePlugins==='function' && typeof pebble.subscribeToSource==='function';
	  var expiryTimer=null,expiryAt=Infinity,discoveryTimer=null,retryTimer=null,bootTimer=null,deliveryEpoch=0,lastError='',bootRequested=false,bootAttempts=0,failureCount=0,seenOrder=0,enumerated=false;
	  var revisions=Object.create(null), orders=Object.create(null), lastSignature='',currentSettings={},installed=[],providerMetadata=Object.create(null),lastView=null;
	  function seconds(){return Math.max(1,Math.floor(now()/1000));}
	  function key(name){return keys[name]===undefined?name:keys[name];}
	  function readSettings(){var s=typeof options.getSettings==='function'?options.getSettings():{};return s&&typeof s==='object'?s:{};}
	  function isEnabled(s){return s.enabled!==false && s.showActivities!==false;}
	  function allowed(provider){return (!Array.isArray(currentSettings.providers)||currentSettings.providers.indexOf(provider)>=0) &&
	    (!Array.isArray(currentSettings.disabledProviders)||currentSettings.disabledProviders.indexOf(provider)<0);}
	  function stopGroup(group){group.generation++;var handle=group.handle;group.handle=null;if(handle && typeof handle.unsubscribe==='function'){try{handle.unsubscribe();}catch(ignored){}}}
	  function accepted(card){try{return typeof options.acceptActivity!=='function'||options.acceptActivity(clone(card))!==false;}catch(ignored){return false;}}
	  function visible(card,t){return card.validUntil>t&&
	    (nativeFormat<2||card.main.validUntil>t&&(!card.unconfirmed||!card.private&&card.main.retain))&&
	    ((card.state!=='completed'&&card.state!=='cancelled')||nativeFormat>=2&&card.showTerminal);}
	  function cleanGroup(provider){var group=groups[provider];if(!group){return;}stopGroup(group);group.cards=[];delete groups[provider];}
	  function catalogue(defensive){
	    var t=seconds(), result=[];
	    Object.keys(groups).forEach(function(provider){
	      var metadata=providerMetadata[provider];
	      groups[provider].cards.forEach(function(card){if(visible(card,t)&&accepted(card)){
	        // Internal default selection can borrow immutable cards: normalize()
	        // below owns the resulting copy. User callbacks/public reads get deep
	        // copies, including nested artwork and capabilities.
	        var copy=defensive?clone(card):card;
	        if(metadata&&metadata.name){
	          if(!defensive){copy={};Object.keys(card).forEach(function(k){copy[k]=card[k];});}
	          copy.providerName=metadata.name;
	        }
	        result.push(copy);
	      }});
	    });
	    result.sort(function(a,b){return orders[a.provider+'|'+a.id]-orders[b.provider+'|'+b.id];});
	    return result;
	  }
	  function catalogueCount(){
	    var t=seconds(),count=0;
	    Object.keys(groups).forEach(function(provider){groups[provider].cards.forEach(function(card){if(visible(card,t)&&accepted(card)){count++;}});});
	    return count;
	  }
	  function projection(){
	    var custom=typeof options.select==='function',all=catalogue(custom),result=custom?options.select(all):all.slice(0,2);
	    if(!Array.isArray(result)){result=[];}
	    return result.slice(0,2).map(function(card){return codec.normalize(card);}).filter(Boolean);
	  }
	  function notify(){if(typeof options.onChanged==='function'){options.onChanged();}}
	  function deliveryCurrent(epoch,token){return epoch===deliveryEpoch&&token===session&&!stopped&&connected&&enabled;}
	  function invalidateDelivery(){
	    deliveryEpoch++;lastView=null;bootRequested=false;bootAttempts=0;
	    [retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});retryTimer=bootTimer=null;
	  }
	  function requestBootstrap(){
	    if(bootRequested || typeof send!=='function' || !connected || !enabled || stopped){return;}
	    if(bootAttempts>=3){return;}bootRequested=true;bootAttempts++;var attempt=bootAttempts,epoch=deliveryEpoch,payload={};payload[key('REQUEST_ACTIVITIES')]=1;
	    function live(){return deliveryCurrent(epoch,0)&&attempt===bootAttempts;}
	    function retry(){if(!live()){return;}if(bootTimer!==null){cancel(bootTimer);}bootTimer=later(function(){bootTimer=null;if(live()){bootRequested=false;requestBootstrap();}},2000);}
	    function failed(){if(!live()){return;}bootRequested=false;retry();}
	    try{send(payload,retry,failed);}catch(ignored){failed();}
	  }
	  function publish(force,afterAccepted){
	    if(stopped || !connected || !enabled){return;}
	    scheduleExpiry();notify();
	    if(!session){requestBootstrap();return;}
	    var cards=projection(),signature=JSON.stringify(cards);
	    if(!force && signature===lastSignature){return;}
	    if(signature!==lastSignature){failureCount=0;}lastSignature=signature;
	    sequence=sequence===wire.MAX_EPOCH?1:sequence+1;
	    if(typeof send!=='function'){return;}
	    var revision=sequence,epoch=deliveryEpoch,token=session,payload={},barriers=[];
	    Object.keys(groups).forEach(function(provider){var group=groups[provider];
	      if(group.rebinding&&!cards.some(function(card){return card.provider===provider;})){barriers.push({group:group,generation:group.generation});}
	    });
	    var sentAt=seconds();payload[key('ACTIVITY_DATA')]=codec.encode(cards,{session:session,revision:revision,sentAt:sentAt});
	    // projection() owns these normalized records. Only copied snapshots leave
	    // the consumer, so retaining them needs no second JSON round trip.
	    lastView={session:session,viewSequence:revision,sequence:revision,sentAt:sentAt,cards:cards};
	    if(typeof options.onView==='function'){options.onView(clone(lastView));}
	    if(!deliveryCurrent(epoch,token)){return;}
	    if(retryTimer!==null){cancel(retryTimer);retryTimer=null;}
	    try{send(payload,function(){
	      if(!deliveryCurrent(epoch,token)){return;}
	      if(revision===sequence){failureCount=0;}
	      // Any acknowledged view excluding a resetting provider is a valid clear
	      // barrier, including one that superseded the original queued clear.
	      barriers.forEach(function(barrier){
	        var group=barrier.group,provider=group.provider;
	        if(groups[provider]!==group||group.generation!==barrier.generation||!group.rebinding){return;}
	        var pending=group.pendingReset;group.pendingReset=null;group.rebinding=false;
	        var needsRebind=group.pendingRebind;group.pendingRebind=false;
	        if(group.pendingMode!=='snapshot'){Object.keys(revisions).forEach(function(id){if(id.indexOf(provider+'|')===0){delete revisions[id];}});}
	        if(needsRebind){bind(provider,group.item);}
	        else if(pending){receive(group,pending,true);}
	      });
	      if(typeof afterAccepted==='function'){afterAccepted();}
	    },function(error){
	      if(!deliveryCurrent(epoch,token)||revision!==sequence||error && error.code==='SUPERSEDED'){return;}
	      if(++failureCount<3){retryTimer=later(function(){retryTimer=null;publish(true);},2000);}
	    });}catch(ignored){if(deliveryCurrent(epoch,token)&&++failureCount<3){retryTimer=later(function(){retryTimer=null;publish(true);},2000);}}
	  }
	  function uncertain(group){
	    var before=group.cards.length,changed=false,t=seconds();
	    group.cards=group.cards.filter(function(card){return !card.private&&card.validUntil>t&&
	      (nativeFormat>=2?card.main.retain&&card.main.validUntil>t:card.clock!=='none');}).map(function(card){
	        if(card.unconfirmed){return card;}
	        changed=true;var copy={};Object.keys(card).forEach(function(k){copy[k]=card[k];});copy.unconfirmed=true;return copy;
	      });
	    return changed||before!==group.cards.length;
	  }
	  function expire(){
	    var t=seconds(), changed=false;
	    Object.keys(groups).forEach(function(provider){
	      var group=groups[provider],before=group.cards.length;
	      group.cards=group.cards.filter(function(card){return card.validUntil>t&&(nativeFormat<2||card.main.validUntil>t);});
	      if(group.expiresAt!==null && group.expiresAt<=t){group.expiresAt=null;group.error='SOURCE_EXPIRED';if(uncertain(group)){changed=true;}}
	      if(before!==group.cards.length){changed=true;}
	    });
	    if(changed){publish();}else{scheduleExpiry();}
	  }
	  function scheduleExpiry(){
	    if(stopped||!connected||!enabled){if(expiryTimer!==null){cancel(expiryTimer);}expiryTimer=null;expiryAt=Infinity;return;}
	    var t=seconds(),end=Infinity;
	    Object.keys(groups).forEach(function(provider){var group=groups[provider];if(group.expiresAt!==null && group.expiresAt>t){end=Math.min(end,group.expiresAt);}group.cards.forEach(function(card){if(card.validUntil>t){end=Math.min(end,card.validUntil);}if(nativeFormat>=2){[card.main,card.support].forEach(function(d){if(d&&d.validUntil>t){end=Math.min(end,d.validUntil);}});}});});
	    if(expiryTimer!==null&&expiryAt===end){return;}
	    if(expiryTimer!==null){cancel(expiryTimer);expiryTimer=null;}
	    expiryAt=end;
	    if(end!==Infinity){expiryTimer=later(function(){expiryTimer=null;expiryAt=Infinity;expire();},Math.max(1,end*1000-now()));}
	  }
	  function receive(group,envelope,rebound){
	    if(!envelope || envelope.pluginUuid!==group.provider || !Array.isArray(envelope.instances) || envelope.instances.length>(group.item===summary.ITEM?17:wire.LIMITS.instances)){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	    var t=seconds(),expiry=envelope.validUntilMs===undefined?null:Math.floor(envelope.validUntilMs/1000);
	    if(expiry!==null && !wire.integer(expiry,1,wire.MAX_EPOCH)){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	    var snapshotHeader=null;
	    if(group.item===summary.ITEM){
	      snapshotHeader=summary.header(envelope);
	      if(!snapshotHeader){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	      if(!rebound&&group.incarnation&&group.incarnation!==snapshotHeader.incarnation){
	        group.cards=[];group.incarnation=null;group.snapshotSequence=0;
	        // The source-floor clear must reach native before a reset managed
	        // revision. Queue only this cleared view until the send completes.
	        group.rebinding=true;group.pendingReset=null;group.pendingMode=snapshotHeader.mode;group.pendingRebind=true;
	        stopGroup(group);
	        publish(true);return;
	      }
	      if(group.rebinding&&!rebound){
	        var pendingHeader=summary.header(group.pendingReset);
	        if(!pendingHeader||pendingHeader.incarnation!==snapshotHeader.incarnation||snapshotHeader.sequence>pendingHeader.sequence){group.pendingReset=envelope;group.pendingMode=snapshotHeader.mode;}
	        return;
	      }
	      if(group.incarnation===snapshotHeader.incarnation&&group.publisherMode!==snapshotHeader.mode){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	      if(group.incarnation===snapshotHeader.incarnation&&snapshotHeader.sequence<group.snapshotSequence){return;}
	      var responseSignature=JSON.stringify(envelope.instances);
	      if(group.incarnation===snapshotHeader.incarnation&&snapshotHeader.sequence===group.snapshotSequence){
	        if(group.responseSignature!==responseSignature){group.cards=[];group.error='INVALID_SOURCE';publish();return;}
	        // A source can recover on the same handle or immediately deliver its
	        // cached response on a new binding. Its outer availability can also
	        // change independently. Revalidate those cases without renewing any
	        // owner observation/validity; healthy exact duplicates remain inert.
	        if(group.ready&&!group.error&&expiry===group.expiresAt){return;}
	      }
	      group.incarnation=snapshotHeader.incarnation;group.publisherMode=snapshotHeader.mode;group.snapshotSequence=snapshotHeader.sequence;group.responseSignature=responseSignature;
	    }
	    var next=[],seen=Object.create(null),pendingRevisions=Object.create(null),pendingOrders=[],malformed=false;
	    envelope.instances.forEach(function(instance){
	      if(group.item===summary.ITEM&&instance&&instance.instanceId==='@snapshot'){return;}
	
	      var source=group.item===summary.ITEM?summary.sourceCard(instance,group.provider):group.item===activity.ITEM?activity.sourceCard(instance,group.provider):
	        group.item===view.ITEM?view.sourceCard(instance,group.provider):sourceCard(instance,group.provider);
	      if(!source){malformed=true;return;}
	      if(group.item===summary.ITEM&&!source.displayName){
	        var metadataEntry=providerMetadata[group.provider];
	        if(metadataEntry&&metadataEntry.name){source.displayName=metadataEntry.name;}
	      }
	      var card=group.item===summary.ITEM?summary.toView(source):group.item===activity.ITEM?activity.toView(source):nativeFormat>=2&&group.item!==view.ITEM?view.fromLegacy(source):source;
	      if(nativeFormat===3&&group.item!==summary.ITEM&&card){card=summaryView.fromLegacy(card);}
	      if(!card&&group.item!==summary.ITEM){malformed=true;return;}
	      if(card&&!accepted(card)){return;}
	      var fingerprint=sourceFingerprint(source),identity=source.provider+'|'+source.id;
	      var state=source.record?(source.record.state||'active'):source.state;
	      var metadata=JSON.stringify([source.kind||source.type,state,source.observedAt,source.validUntil,source.private]);
	
	      if(seen[identity]){malformed=true;return;}seen[identity]=true;
	      var previous=revisions[identity];
	      if(previous && source.revision<previous.revision){
	        var retained=group.cards.filter(function(old){return old.id===source.id && old.revision===previous.revision;})[0];
	        if(retained && retained.validUntil>t){next.push(retained);}return;
	      }
	      if(previous && (source.revision===previous.revision && (metadata!==previous.metadata || group.item===previous.item&&fingerprint!==previous.fingerprint) || previous.terminal && state!=='completed' && state!=='cancelled')){malformed=true;return;}
	      pendingRevisions[identity]={revision:source.revision,fingerprint:fingerprint,metadata:metadata,item:group.item,terminal:state==='completed'||state==='cancelled'};
	      if(!card){return;}
	      card.sourceFormat=group.item===summary.ITEM?4:group.item===activity.ITEM?3:group.item===view.ITEM?2:1;
	      if(card.kind==='music'){
	        card.validUntil=Math.min(card.validUntil,card.observedAt+120);
	        if(nativeFormat>=2){card.main.validUntil=Math.min(card.main.validUntil,card.validUntil);if(card.support){card.support.validUntil=Math.min(card.support.validUntil,card.validUntil);}}
	      }
	      if(!Object.prototype.hasOwnProperty.call(orders,identity)){pendingOrders.push(identity);}
	      if(card.validUntil>t&&((card.state!=='completed'&&card.state!=='cancelled')||nativeFormat>=2&&card.showTerminal)){next.push(card);}
	    });
	    // A malformed/redacted entry cannot leave an older private preview alive.
	    if(malformed){next=[];}
	    else{
	      // A rejected complete response cannot advance another record's source
	      // floor or install a terminal tombstone through its valid-looking rows.
	      Object.keys(pendingRevisions).forEach(function(identity){revisions[identity]=pendingRevisions[identity];});
	      pendingOrders.forEach(function(identity){orders[identity]=++seenOrder;});
	    }
	    group.cards=next;group.receivedAt=t;group.expiresAt=expiry;group.error=malformed?'INVALID_SOURCE':'';group.ready=true;
	    if(expiry!==null && expiry<=t){uncertain(group);group.error='SOURCE_EXPIRED';}
	    // Bound revision/ordering tombstones independently of untrusted source churn.
	    var identities=Object.keys(revisions);
	    if(identities.length>1024){var live=Object.create(null);Object.keys(groups).forEach(function(provider){groups[provider].cards.forEach(function(card){live[card.provider+'|'+card.id]=true;});});identities.filter(function(id){return !live[id];}).slice(0,identities.length-1024).forEach(function(id){delete revisions[id];delete orders[id];});}
	    publish();
	  }
	  function bind(provider,item){
	    var group=groups[provider]||{provider:provider,generation:0,handle:null,cards:[],error:'',receivedAt:null,expiresAt:null,ready:false};
	    groups[provider]=group;stopGroup(group);group.item=item;group.ready=false;group.settled=false;group.error='';var run=group.generation;
	    function live(){return !stopped && connected && enabled && groups[provider]===group && run===group.generation;}
	    try{
	      var handle=pebble.subscribeToSource({plugin:provider,category:wire.CATEGORY,item:item,properties:(item===summary.ITEM?summary.PROPERTIES:item===activity.ITEM?activity.PROPERTIES:item===view.ITEM?view.PROPERTIES:PROPERTIES).slice(),iconPixelSize:{w:40,h:40},
	        onData:function(envelope){if(live()){group.settled=true;receive(group,envelope);}},
	        onError:function(error){if(!live()){return;}group.settled=true;group.error=errorCode(error);if(group.error==='TIMEOUT'||group.error==='PLUGIN_UNAVAILABLE'||group.error==='RATE_LIMITED'){uncertain(group);}else{group.cards=[];}publish();}});
	      if(live()){group.handle=handle;}else if(handle && typeof handle.unsubscribe==='function'){handle.unsubscribe();}
	    }catch(error){group.settled=true;group.error=errorCode(error);group.cards=[];publish();}
	  }
	  function discover(rebind){
	    if(stopped||!connected||!enabled){return;}
	    available=typeof pebble.enumeratePlugins==='function' && typeof pebble.subscribeToSource==='function';
	    if(!available){Object.keys(groups).forEach(cleanGroup);lastError='API_UNAVAILABLE';publish();return;}
	    var run=++generation;enumerated=false;
	    function apply(plugins){
	      if(run!==generation||stopped||!connected||!enabled){return;}
	      if(!Array.isArray(plugins)){lastError='INVALID_CATALOGUE';Object.keys(groups).forEach(cleanGroup);publish();return;}
	      var items=Object.create(null),metadata=Object.create(null);
	      plugins.filter(function(p){return compatible(p,nativeFormat);}).forEach(function(p){
	        // The official plugin-test app reads enumeratePlugins().name. Treat it
	        // as untrusted display metadata, never as source/revision identity.
	        if(!metadata[p.uuid]){metadata[p.uuid]={uuid:p.uuid,name:wire.text(p.name,64),item:sourceItem(p,nativeFormat),available:true};}
	      });
	      installed=Object.keys(metadata).sort().slice(0,wire.LIMITS.providers).map(function(uuid){return metadata[uuid];});
	      providerMetadata=Object.create(null);installed.forEach(function(p){providerMetadata[p.uuid]=p;});
	      var providers=installed.filter(function(p){return allowed(p.uuid);}).map(function(p){items[p.uuid]=p.item;return p.uuid;});
	      enumerated=true;
	      Object.keys(groups).forEach(function(provider){if(providers.indexOf(provider)<0){cleanGroup(provider);}});
	      providers.forEach(function(provider){var group=groups[provider];if(rebind||!group||group.item!==items[provider]||
	        !group.rebinding&&(group.error||!group.handle)){bind(provider,items[provider]);}});
	      lastError='';publish();
	    }
	    try{var result=pebble.enumeratePlugins();if(result && typeof result.then==='function'){result.then(apply,function(){if(run===generation){lastError='CATALOGUE_UNAVAILABLE';Object.keys(groups).forEach(cleanGroup);publish();}});}else{apply(result);}}
	    catch(ignored){lastError='CATALOGUE_UNAVAILABLE';Object.keys(groups).forEach(cleanGroup);publish();}
	    if(discoveryTimer!==null){cancel(discoveryTimer);}
	    discoveryTimer=later(function(){discoveryTimer=null;discover(false);},60000);
	  }
	  function configure(){
	    if(stopped){return;}
	    var next=readSettings(),previous=enabled;currentSettings=next;enabled=isEnabled(next);
	    if(!enabled){invalidateDelivery();Object.keys(groups).forEach(cleanGroup);lastSignature='';if(expiryTimer!==null){cancel(expiryTimer);expiryTimer=null;}if(discoveryTimer!==null){cancel(discoveryTimer);discoveryTimer=null;}
	      if(previous && connected && session && typeof send==='function'){sequence=sequence===wire.MAX_EPOCH?1:sequence+1;var payload={};payload[key('ACTIVITY_DATA')]=codec.encode([],{session:session,revision:sequence,sentAt:seconds()});try{send(payload,function(){},function(){});}catch(ignored){}}
	      notify();return;
	    }
	    // Apply known policy immediately: asynchronous discovery may be slow or
	    // never settle, and cannot be the boundary for withdrawing private data.
	    var removed=false;
	    Object.keys(groups).forEach(function(provider){if(!allowed(provider)){cleanGroup(provider);removed=true;}});
	    if(removed){publish();}
	    discover(false);
	  }
	  function refresh(rebaseline,token){
	    if(stopped){return;}
	    if(typeof rebaseline==='number'){token=rebaseline;rebaseline=true;}
	    if(wire.integer(token,2,wire.MAX_EPOCH) && token!==session){invalidateDelivery();session=token;sequence=0;lastSignature='';failureCount=0;}
	    else if(rebaseline && !token){bootRequested=false;bootAttempts=0;}failureCount=0;
	    currentSettings=readSettings();enabled=isEnabled(currentSettings);
	    if(!enabled){configure();return;}
	    discover(true);publish(true);
	  }
	  function connectionChanged(value,token){
	    if(stopped || typeof value!=='boolean'){return;}
	    connected=value;generation++;
	    if(!connected){invalidateDelivery();Object.keys(groups).forEach(cleanGroup);session=0;sequence=0;lastSignature='';
	      [expiryTimer,discoveryTimer,retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});expiryTimer=discoveryTimer=retryTimer=bootTimer=null;notify();}
	    else{refresh(true,token);}
	  }
	  return {refresh:refresh,configure:configure,connectionChanged:connectionChanged,reproject:function(){publish(true);},
	    providers:function(){return clone(installed);},
	    catalogue:function(){return catalogue(true);},
	    view:function(){return lastView?clone(lastView):null;},
	    status:function(){var providers=Object.keys(groups).map(function(provider){var group=groups[provider];return {pluginUuid:provider,state:group.error?'unavailable':group.ready?'ready':'waiting',error:group.error,receivedAt:group.receivedAt};});var count=catalogueCount(),complete=enumerated&&Object.keys(groups).every(function(provider){return groups[provider].settled;});var ready=enabled&&available&&connected&&enumerated&&providers.every(function(p){return p.state==='ready';});return {available:available,connected:connected,enabled:enabled,ready:ready,complete:complete,phase:ready?'ready':count?'partial':complete||lastError||!connected||!available?'unavailable':'loading',error:lastError||providers.map(function(p){return p.error;}).filter(Boolean)[0]||'',providers:providers,count:count};},
	    stop:function(){stopped=true;generation++;invalidateDelivery();Object.keys(groups).forEach(cleanGroup);[expiryTimer,discoveryTimer,retryTimer,bootTimer].forEach(function(timer){if(timer!==null){cancel(timer);}});expiryTimer=discoveryTimer=retryTimer=bootTimer=null;revisions=Object.create(null);orders=Object.create(null);}}
	};
	module.exports.sourceCard=sourceCard;
	module.exports.compatible=compatible;
	module.exports.PROPERTIES=PROPERTIES;


/***/ }),
/* 16 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var wire = __webpack_require__(17);
	var activityWire = __webpack_require__(10);
	var activity = __webpack_require__(9);
	var summary = __webpack_require__(12);
	// Namespace of this host adapter only; never claim an unknown SDK provider UUID.
	var MUSIC_ADAPTER_UUID = '718089b7-d9d4-4d6b-81c0-915dcd4c7e4a';
	var NOTIFICATION_ADAPTER_UUID = 'cdb6d497-547a-4940-8026-f7c97ea73a9d';
	var NOTIFICATIONS_APP_UUID = 'b2cae818-10f8-46df-ad2b-98ad2254a3c1';
	var KIND = wire.SEMANTIC_KIND;
	var SOURCE = wire.SOURCE_KIND;
	var LEASE = 120;
	var NOTICE_SUMMARY_LIFE = 3;
	var NOTICE_MESSAGE_LIFE = 8;
	var NOTICE_QUIET = 3;
	var NOTICE_STABLE_MS = 900;
	var PAUSED_GRACE = 5;
	var HEARTBEAT = 60000;
	var MAX_EPOCH = 4294967295;
	var DEFINITIONS = {
	  music:{category:'music', item:'track', properties:['title','artist','playing','artwork']},
	  notifications:{category:'notifications', item:'notification', properties:['name','body','app','package','app_icon']},
	  phone:{category:'phone', item:'phone_state', properties:['battery_level']}
	};
	
	function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
	function finite(value) { return typeof value === 'number' && isFinite(value); }
	function tokenOf(value) {
	  return finite(value) && Math.floor(value) === value && value>=2 && value<=2147483647 ? value : null;
	}
	function textOf(value) {
	  if (!object(value)) { return ''; }
	  return object(value.shortText) && typeof value.shortText.text === 'string' ? value.shortText.text :
	    object(value.longText) && typeof value.longText.text === 'string' ? value.longText.text : '';
	}
	function clean(value) {
	  return wire.normalizeText(typeof value === 'string' ? value.slice(0,4096)
	    .replace(/[\u00ad\u061c\u200b-\u200f\u202a-\u202e\u2060-\u206f\ufeff\ufff9-\ufffb]/g,' ') : '',128);
	}
	function codeOf(error) {
	  return error && typeof error.code === 'string' && /^[A-Z0-9_]{1,48}$/.test(error.code) ? error.code : 'UNKNOWN';
	}
	function bytesOf(value, max) {
	  if (typeof value !== 'string' || value.length > Math.ceil(max / 3) * 4 ||
	      !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(value)) { return null; }
	  var alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
	  var out = [];
	  for (var i=0; i<value.length; i+=4) {
	    var a=alphabet.indexOf(value[i]), b=alphabet.indexOf(value[i+1]);
	    var c=value[i+2] === '=' ? 0 : alphabet.indexOf(value[i+2]);
	    var d=value[i+3] === '=' ? 0 : alphabet.indexOf(value[i+3]);
	    if (value[i+2] === '=' && (b & 15) || value[i+3] === '=' && value[i+2] !== '=' && (c & 3)) { return null; }
	    out.push((a << 2) | (b >> 4));
	    if (value[i+2] !== '=') { out.push(((b & 15) << 4) | (c >> 2)); }
	    if (value[i+3] !== '=') { out.push(((c & 3) << 6) | d); }
	  }
	  return out.length <= max ? out : null;
	}
	// The source bitmap has tightly packed rows; the existing watch packet uses
	// four-byte aligned rows. Do not assume that every source returns a 24px square.
	function bitmapOf(shape,image,maxSize) {
	  maxSize=maxSize || 24;
	  if (!object(shape) || !Number.isInteger(shape.width) || !Number.isInteger(shape.height) ||
	      shape.width<1 || shape.width>maxSize || shape.height<1 || shape.height>maxSize) { return null; }
	  var palette=bytesOf(shape.palette,16), source=bytesOf(shape.pixels,Math.ceil(maxSize/2)*maxSize);
	  var sourceStride=Math.ceil(shape.width/2), stride=((shape.width+7)>>3)*4;
	  if (!palette || !palette.length || !source || source.length !== sourceStride*shape.height) { return null; }
	  var pixels=[];
	  for (var i=0; i<stride*shape.height; i++) { pixels.push(0); }
	  for (var y=0; y<shape.height; y++) {
	    for (var x=0; x<shape.width; x++) {
	      var pair=source[y*sourceStride+(x>>1)], value=x&1 ? pair&15 : pair>>4;
	      if (value>=palette.length) { return null; }
	      pixels[y*stride+(x>>1)] |= x&1 ? value : value<<4;
	    }
	  }
	  return {width:shape.width,height:shape.height,palette:palette,pixels:pixels,image:image};
	}
	function pictureOf(property,maxSize) {
	  return object(property) ? bitmapOf(property.image,true,maxSize) || bitmapOf(property.icon,false,maxSize) : null;
	}
	function activityImage(bitmap) {
	  if (!bitmap) { return undefined; }
	  var pixels=[],stride=((bitmap.width+7)>>3)*4,row=Math.ceil(bitmap.width/2);
	  for (var y=0;y<bitmap.height;y++) { pixels=pixels.concat(bitmap.pixels.slice(y*stride,y*stride+row)); }
	  return {width:bitmap.width,height:bitmap.height,palette:bitmap.palette.slice(),pixels:pixels};
	}
	function keyOf(instance) {
	  return object(instance) && typeof instance.instanceId === 'string' && instance.instanceId.length>0 &&
	    instance.instanceId.length<=1024 && !/[\x00-\x1f\x7f]/.test(instance.instanceId) ? instance.instanceId : null;
	}
	function filterNames(value) {
	  return (typeof value === 'string' ? value.slice(0,2048) : '').split(',').map(function(name) {
	    return name.trim().toLowerCase();
	  }).filter(function(name,index,names) { return name && names.indexOf(name) === index; }).slice(0,64);
	}
	function fingerprintOf(instance) {
	  var p=instance.properties;
	  // Android conversation notifications often reuse the same notification key.
	  // Observe their text too, but exclude late artwork or an unchanged redelivery.
	  // Keep only bounded text digests in the baseline, rather than retaining bodies.
	  var hash=2166136261, second=5381;
	  ['app','name','body'].forEach(function(name) {
	    var source=textOf(p[name]);
	    var value=(source.slice(0,1024)+'\u001f'+source.slice(-1024))
	      .replace(/[\x00-\x1f\x7f-\x9f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u206f\ufeff]/g,' ')
	      .replace(/ +/g,' ').trim();
	    value=value.length+':'+value+'\u001f';
	    for (var i=0; i<value.length; i++) {
	      var point=value.charCodeAt(i);
	      hash=Math.imul(hash ^ point,16777619);
	      second=((second << 5)+second) ^ point;
	    }
	  });
	  return (hash>>>0).toString(16)+':'+(second>>>0).toString(16);
	}
	function digest(value) {
	  var hash=2166136261,second=5381;
	  for (var i=0;i<value.length;i++) {
	    var point=value.charCodeAt(i);hash=Math.imul(hash ^ point,16777619);second=((second << 5)+second) ^ point;
	  }
	  return (hash>>>0).toString(16)+':'+(second>>>0).toString(16);
	}
	
	/** Ephemeral context only: sends to the watch, never persists or logs content. */
	module.exports = function createContext(options) {
	  var pebble=options.pebble || {};
	  var groups={};
	  Object.keys(DEFINITIONS).forEach(function(name) {
	    groups[name]={handle:null,generation:0,error:'',hasData:false,receivedAt:null,recovery:null,attempt:0};
	  });
	  var settings=null;
	  var connected=true;
	  var stopped=false;
	  var available=typeof pebble.subscribeToSource === 'function';
	  var records=[null,null,null,null,null];
	  var playing=false;
	  var pausedUntil=0;
	  var musicCard=null, musicRun=0, musicRevision=0, musicIdentity='';
	  var baseline=false;
	  var notificationIds=Object.create(null);
	  var activeNotice=null;
	  var noticeMetadata=null, notificationCard=null, notificationRun=0, notificationRevision=0;
	  var notificationIdentity='', notificationSignature='';
	  var noticeWindowEnd=0, lastNoticeAt=0;
	  var burstSequence=0, noticeBurst=0;
	  var noticeShownAt=0, pendingNotice=null, noticeUpdateTimer=null;
	  var markerNeeded=false, baselineGeneration=0, baselineToken=null;
	  var heartbeat=null, expiryTimer=null;
	  var pending=false, sending=false, deliveryTimer=null, deliveryGeneration=0;
	  var revision=0;
	
	  function now() { return Math.floor(options.now()/1000); }
	  function readSettings() {
	    var value={};
	    try { value=options.getSettings() || {}; } catch (ignored) {}
	    return {showMusic:value.showMusic !== false,showNotifications:value.showNotifications === true,
	      notificationPreview:value.notificationPreview === true,notificationAppOnly:value.notificationAppOnly === true,
	      notificationApps:filterNames(value.notificationApps),
	      showStatus:value.showStatus !== false};
	  }
	  function enabled(name) {
	    return settings && (name === 'music' ? settings.showMusic : name === 'phone' ? settings.showStatus : settings.showNotifications);
	  }
	  function fresh(record) {
	    return record && Number.isInteger(record.confirmedAt) && record.confirmedAt>0 && record.confirmedAt<=now() &&
	      Number.isInteger(record.validUntil) && now()<record.validUntil && record.validUntil<=MAX_EPOCH;
	  }
	  function until(envelope, seconds) {
	    var end=now()+seconds;
	    if (envelope.validUntilMs !== undefined && envelope.validUntilMs !== null) {
	      if (!finite(envelope.validUntilMs)) { return 0; }
	      end=Math.min(end,Math.floor(envelope.validUntilMs/1000));
	    }
	    return end>now() && end<=MAX_EPOCH ? end : 0;
	  }
	  function record(text, bitmap, end, semantic) {
	    text=clean(text);
	    return (text || bitmap) && end>now() ? {status:2,text:text,bitmap:bitmap || undefined,
	      confirmedAt:now(),validUntil:end,semantic:semantic} : null;
	  }
	  function clearNotice() {
	    records[2]=records[3]=null;
	    activeNotice=null;
	    noticeMetadata=notificationCard=null;
	    pendingNotice=null; noticeShownAt=0;
	    if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
	  }
	  function clearGroup(name) {
	    if (name === 'music') { records[0]=records[1]=null; playing=false; pausedUntil=0; musicCard=null; musicIdentity=''; }
	    else if (name === 'phone') { records[4]=null; }
	    else { clearNotice(); baseline=false; notificationIds=Object.create(null); noticeWindowEnd=lastNoticeAt=noticeBurst=0; }
	  }
	  function markBaseline(token, replaceToken) {
	    if (replaceToken) {
	      var nextToken=tokenOf(token);
	      if (nextToken !== baselineToken) { burstSequence=0; }
	      baselineToken=nextToken;
	    }
	    baselineGeneration++;
	    markerNeeded=true;
	    clearGroup('notifications');
	    groups.notifications.hasData=false;
	  }
	  function currentSlots() {
	    return records.map(function(value,i) {
	      if (fresh(value)) { return value; }
	      if (value) { records[i]=null; }
	      return null;
	    });
	  }
	  function payload() {
	    var result={};
	    var slots=currentSlots();
	    // Opt-in hosts render this same ephemeral record in their activity slots.
	    // Do not let the compatibility footer defeat their hide/order preferences.
	    if (options.musicAsActivity === true && musicActivity()) { slots[0]=slots[1]=null; }
	    if (options.notificationAsActivity === true) { slots[2]=slots[3]=null; }
	    if (markerNeeded) {
	      // A boundary may itself have been queued before a second reconnect.
	      // Boundaries never contain private notification data. A fresh notice is
	      // sent only after this baseline's boundary has actually been acknowledged.
	      slots[2]=slots[3]=null;
	      // Startup may precede the watch's unique launch/reconnect token. An old
	      // token must never open that native notification gate, so wait for it.
	      if (baselineToken !== null && options.keys.REQUEST_CONTEXT !== undefined) {
	        result[options.keys.REQUEST_CONTEXT]=baselineToken;
	      }
	    }
	    result[options.keys.CONTEXT_DATA]=wire.packComplications(slots,now());
	    if (options.keys.CONTEXT_STATE !== undefined) {
	      // This sidecar travels atomically with its snapshot. It contains no
	      // provider identity or content, and is never persisted. The native host
	      // must check the session and notification gate before acting on it.
	      var notice=options.notificationAsActivity === true ? notificationActivity() : null;
	      var session=baselineToken || 0, event=!markerNeeded && (notice || slots[2]) ? noticeBurst : 0;
	      var state=[0,0,0,0,0,0,0,0,slots[0] && !playing ? 1 : 0];
	      for (var i=0; i<4; i++) { state[i]=(session >>> (i*8)) & 255; state[i+4]=(event >>> (i*8)) & 255; }
	      // Opt-in hosts no longer receive notification slots. Preserve the original
	      // deadline beside the event so a delayed queue cannot vibrate after expiry.
	      if (options.notificationAsActivity === true) {
	        var expiry=notice ? notice.validUntil : 0;
	        for (i=0;i<4;i++) { state[9+i]=(expiry >>> (i*8)) & 255; }
	      }
	      result[options.keys.CONTEXT_STATE]=state;
	    }
	    return result;
	  }
	  function cancelDelivery() {
	    deliveryGeneration++;
	    if (deliveryTimer !== null) { options.cancelLater(deliveryTimer); }
	    deliveryTimer=null; sending=false; pending=false;
	  }
	  function pump() {
	    if (stopped || !connected || sending || !pending) { return; }
	    pending=false; sending=true;
	    var generation=deliveryGeneration;
	    function attempt(number) {
	      if (generation !== deliveryGeneration || stopped || !connected) { return; }
	      var sentRevision=revision, sentBaselineGeneration=baselineGeneration, sentToken=baselineToken;
	      var sentMarker=markerNeeded && sentToken !== null && options.keys.REQUEST_CONTEXT !== undefined, done=false;
	      function finish(ok,error) {
	        if (done || generation !== deliveryGeneration) { return; }
	        done=true;
	        // Only this baseline's acknowledged boundary can release its marker.
	        // A packet copied into the shared queue before reconnect cannot do so.
	        if (ok && sentMarker && sentBaselineGeneration === baselineGeneration && sentToken === baselineToken) {
	          markerNeeded=false;
	          if (fresh(records[2])) { pending=true; }
	          if (options.notificationAsActivity === true) { notify(); }
	        }
	        if (deliveryTimer !== null) { options.cancelLater(deliveryTimer); }
	        deliveryTimer=null;
	        if (!ok && (!error || error.code !== 'SUPERSEDED') && !pending && revision === sentRevision && number<3) {
	          deliveryTimer=options.later(function() { deliveryTimer=null; attempt(number+1); },number*1000);
	          return;
	        }
	        sending=false;
	        pump();
	      }
	      // The shared transport can wait behind another bounded transfer. Its
	      // own watchdog owns a stuck native send; leave room for that queue here.
	      deliveryTimer=options.later(function() { finish(false); },45000);
	      try { options.send(payload(),function() { finish(true); },function(error) { finish(false,error); }); }
	      catch (ignored) { finish(false); }
	    }
	    attempt(1);
	  }
	  function publish() {
	    revision++;
	    if (options.send.supersedesSnapshots && sending) { cancelDelivery(); }
	    pending=true;
	    pump();
	    scheduleExpiry();
	    notify();
	  }
	  function notify() { if (typeof options.onChanged === 'function') { options.onChanged(); } }
	  function musicActivity() {
	    if (stopped || !connected || !enabled('music') || !fresh(records[0]) || !musicCard || musicCard.validUntil<=now()) { return null; }
	    // Reading a projection never changes the authoritative receipt or revision.
	    var result=JSON.parse(JSON.stringify(musicCard));
	    result.selectionKey='builtin:music'; result.providerName='Music';
	    return result;
	  }
	  function notificationActivity() {
	    if (stopped || !connected || markerNeeded || !enabled('notifications') || !fresh(records[2]) ||
	        !notificationCard || notificationCard.validUntil<=now()) { return null; }
	    return JSON.parse(JSON.stringify(notificationCard));
	  }
	  function syncNotificationActivity() {
	    if (!noticeMetadata || !noticeMetadata.provider || !fresh(records[2])) { notificationCard=null; return; }
	    var identity=digest(JSON.stringify([noticeMetadata.provider,activeNotice,noticeMetadata.burst]));
	    var source={provider:noticeMetadata.provider,observedAt:records[2].confirmedAt,validUntil:records[2].validUntil,
	      private:true,displayName:'Notifications',record:{id:'notification',type:'standard',icon:activityImage(records[2].bitmap)||'message',
	        name:noticeMetadata.appName,headline:{type:'text',text:records[2].text},
	        openApp:{watchAppUuid:NOTIFICATIONS_APP_UUID}}};
	    if (fresh(records[3])) { source.record.detail={type:'text',text:records[3].text}; }
	    // Retain only digests across a redaction, never an earlier body or source ID.
	    var signature=digest(JSON.stringify(source));
	    if (identity !== notificationIdentity || notificationRevision===MAX_EPOCH) {
	      notificationIdentity=identity; notificationRun++; notificationRevision=0; notificationSignature='';
	    }
	    if (signature !== notificationSignature) { notificationRevision++; notificationSignature=signature; }
	    source.revision=notificationRevision; source.record.id='legacy-notification-'+notificationRun;
	    notificationCard=summary.toView(source);
	    if (notificationCard) { notificationCard.selectionKey='builtin:notifications'; }
	  }
	  function activateNotice(next) {
	    records[2]=next.title; records[3]=next.body; activeNotice=next.id;
	    noticeMetadata={provider:next.provider,appName:next.appName,burst:next.burst};
	    noticeShownAt=options.now(); syncNotificationActivity();
	  }
	  function scheduleExpiry() {
	    if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
	    expiryTimer=null;
	    var end=Infinity;
	    records.forEach(function(value) { if (fresh(value)) { end=Math.min(end,value.validUntil); } });
	    if (pendingNotice && fresh(pendingNotice.title)) { end=Math.min(end,pendingNotice.title.validUntil); }
	    if (end !== Infinity && !stopped) {
	      expiryTimer=options.later(function() {
	        expiryTimer=null;
	        if (!fresh(records[2])) { clearNotice(); }
	        if (pendingNotice && !fresh(pendingNotice.title)) {
	          pendingNotice=null;
	          if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
	        }
	        currentSlots(); publish();
	      },Math.max(1,end*1000-options.now()));
	    }
	  }
	  function cancelRecovery(name, reset) {
	    var group=groups[name];
	    if (group.recovery !== null) { options.cancelLater(group.recovery); }
	    group.recovery=null;
	    if (reset) { group.attempt=0; }
	  }
	  function recover(name) {
	    var group=groups[name];
	    if (stopped || !connected || !enabled(name) || !available ||
	        ['PLUGIN_UNAVAILABLE','TIMEOUT','UNKNOWN'].indexOf(group.error)<0) { cancelRecovery(name,true); return; }
	    if (group.recovery !== null) { return; }
	    var generation=group.generation;
	    group.recovery=options.later(function() {
	      group.recovery=null;
	      if (generation !== group.generation || stopped || !connected || !enabled(name)) { return; }
	      group.attempt=Math.min(group.attempt+1,3);
	      bind(name); recover(name);
	    },[5000,15000,60000,120000][group.attempt]);
	  }
	  function sourceError(name,error) {
	    groups[name].error=codeOf(error);
	    groups[name].hasData=false;
	    clearGroup(name);
	    publish(); recover(name);
	  }
	  function sourceData(name,envelope) {
	    if (!object(envelope) || !Array.isArray(envelope.instances) || envelope.instances.length>512) {
	      sourceError(name,{code:'INVALID_DATA'}); return;
	    }
	    groups[name].error=''; groups[name].hasData=true; cancelRecovery(name,true);
	    var valid;
	    if (name === 'music') { valid=musicData(envelope); }
	    else if (name === 'phone') { valid=phoneData(envelope); }
	    else { valid=notificationData(envelope); }
	    if (valid === false) { sourceError(name,{code:'INVALID_DATA'}); return; }
	    groups[name].receivedAt=now();
	    if (valid !== 'deferred') { publish(); }
	  }
	  function musicData(envelope) {
	    if (!envelope.instances.length) { clearGroup('music'); return; }
	    var instance=envelope.instances[0], p=object(instance) && instance.properties;
	    var isPlaying=object(p) && object(p.playing) && object(p.playing.boolean) ? p.playing.boolean.value : null;
	    var title=object(p) ? clean(textOf(p.title)) : '';
	    var end=until(envelope,LEASE);
	    if (typeof isPlaying !== 'boolean' || !title || !end) { return false; }
	    if (isPlaying) { playing=true; pausedUntil=0; }
	    else {
	      if (playing) { pausedUntil=now()+PAUSED_GRACE; }
	      playing=false;
	      if (!pausedUntil || now()>=pausedUntil) { clearGroup('music'); return; }
	      end=Math.min(end,pausedUntil);
	    }
	    records[0]=record(title,pictureOf(p.artwork,40),end,{kind:KIND.GENERIC,source:SOURCE.MUSIC});
	    records[1]=record(textOf(p.artist),null,end,{kind:KIND.GENERIC,source:SOURCE.MUSIC});
	    var provider=envelope.pluginUuid===undefined?MUSIC_ADAPTER_UUID:activityWire.uuid(envelope.pluginUuid)?envelope.pluginUuid:null;
	    if (!provider) { musicCard=null; return; }
	    var artist=records[1] ? records[1].text : '', identity=JSON.stringify([provider,keyOf(instance),title,artist]);
	    if (identity !== musicIdentity || musicRevision===MAX_EPOCH) { musicIdentity=identity; musicRun++; musicRevision=0; }
	    musicRevision++;
	    var image=activityImage(records[0].bitmap);
	    // Missing optional metadata contributes no label or placeholder row.
	    var detail=/^(?:\?|unknown|unknown artist)$/i.test(artist.trim())?'':artist;
	    musicCard=activity.toView({provider:provider,id:'legacy-music-'+musicRun,kind:'music',revision:musicRevision,
	      state:playing?'active':'paused',observedAt:records[0].confirmedAt,validUntil:end,private:true,appName:'Music',
	      content:title,detail:detail||null,image:image});
	  }
	  function phoneData(envelope) {
	    if (!envelope.instances.length) { records[4]=null; return; }
	    var instance=envelope.instances[0], p=object(instance) && instance.properties;
	    var property=object(p) && p.battery_level;
	    var numeric=object(property) && property.numericValue;
	    var level=object(numeric) && numeric.value;
	    var end=until(envelope,LEASE);
	    if (!object(p) || property !== undefined && (!object(numeric) || !finite(level) || level<0 || level>100 ||
	        numeric.unit !== undefined && numeric.unit !== '%') || !end) { return false; }
	    records[4]=finite(level) && level>=0 && level<=15 &&
	      (numeric.unit === undefined || numeric.unit === '%') && end ? record(Math.round(level)+'%',null,end,
	        {kind:KIND.BATTERY,source:SOURCE.PHONE,detail:wire.DETAIL_KIND.PHONE_BATTERY,value:level,min:0,max:100,unit:'%'}) : null;
	  }
	  function notificationContent(instance) {
	    var p=object(instance) && instance.properties;
	    if (!object(p)) { return null; }
	    var app=textOf(p.app), packageName=textOf(p.package);
	    var allowed=!settings.notificationApps.length || settings.notificationApps.indexOf(app.trim().toLowerCase())>=0 ||
	      settings.notificationApps.indexOf(packageName.trim().toLowerCase())>=0;
	    var title=clean(textOf(p.name)), appTitle=wire.normalizeText(clean(app),24);
	    var heading=settings.notificationAppOnly ? clean(app) || clean(packageName) : title || clean(app);
	    if (!allowed || !heading) { return null; }
	    return {title:title,appTitle:appTitle,
	      appName:settings.notificationAppOnly || heading===clean(app) ? 'Notifications' :
	        wire.normalizeText(clean(app)||clean(packageName)||'Notifications',64),heading:heading,
	      body:settings.notificationPreview && !settings.notificationAppOnly ? clean(textOf(p.body)) : ''};
	  }
	  function notificationData(envelope) {
	    var incoming=Object.create(null), candidates=[], activeInstance=null, pendingInstance=null, deferred=false, changed=false;
	    var provider=envelope.pluginUuid===undefined?NOTIFICATION_ADAPTER_UUID:activityWire.uuid(envelope.pluginUuid)?envelope.pluginUuid:null;
	    envelope.instances.forEach(function(instance) {
	      var id=keyOf(instance);
	      if (id === null || incoming[id]) { return; }
	      incoming[id]=object(instance.properties) ? fingerprintOf(instance) : 'invalid';
	      if (id === activeNotice) { activeInstance=instance; }
	      if (pendingNotice && id === pendingNotice.id) { pendingInstance=instance; }
	      if (baseline && notificationIds[id] !== incoming[id] && object(instance.properties)) { candidates.push(instance); }
	    });
	    if (envelope.instances.length && !Object.keys(incoming).length) { return false; }
	    // A retained source ID does not mean its earlier private content is still
	    // available. Full redaction, malformed properties and a newly excluded app
	    // must clear both visible and queued text before the stable-reading delay.
	    if (activeNotice && !notificationContent(activeInstance)) { clearNotice(); }
	    if (pendingNotice && !notificationContent(pendingInstance)) {
	      pendingNotice=null;
	      if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
	    }
	    // Late artwork is not a new notice and must not renew its original lease.
	    if (activeInstance && fresh(records[2]) && notificationIds[activeNotice] === incoming[activeNotice]) {
	      var refreshedIcon=pictureOf(activeInstance.properties.app_icon,24);
	      if (refreshedIcon) { records[2].bitmap=refreshedIcon; }
	      if (noticeMetadata) { noticeMetadata.provider=provider; }
	    }
	    // First delivery is a snapshot of the existing phone shade, not a new
	    // notification. Reconnects, errors and settings changes establish it again.
	    notificationIds=incoming;
	    if (!baseline) { baseline=true; return; }
	    var availableEnd=until(envelope,NOTICE_MESSAGE_LIFE);
	    if (!availableEnd) { clearNotice(); return; }
	    // An unchanged redelivery may shorten the authoritative source lease. Cap
	    // visible AND queued text without changing its original observation time.
	    function cap(record) {
	      if (record && record.validUntil>availableEnd) { record.validUntil=availableEnd; changed=true; }
	    }
	    cap(records[2]); cap(records[3]);
	    if (pendingNotice) { cap(pendingNotice.title); cap(pendingNotice.body); }
	    if (noticeWindowEnd>availableEnd) { noticeWindowEnd=availableEnd; }
	    for (var i=0; i<candidates.length; i++) {
	      var instance=candidates[i], p=instance.properties;
	      var content=notificationContent(instance);
	      if (!content) { continue; }
	      var title=content.title, appTitle=content.appTitle, heading=content.heading, body=content.body;
	      var lifetime=options.notificationAsActivity === true || body ? NOTICE_MESSAGE_LIFE : NOTICE_SUMMARY_LIFE;
	      var end=Math.min(availableEnd,now()+lifetime);
	      var received=now();
	      if (received>=noticeWindowEnd) {
	        var quiet=lastNoticeAt === 0 || received-lastNoticeAt>=NOTICE_QUIET;
	        lastNoticeAt=received;
	        // A continuous burst gets one bounded interruption, not another
	        // lifetime on every message. New arrivals still advance the baseline,
	        // and a later independent burst can start after a short quiet gap.
	        if (!quiet) { break; }
	        noticeWindowEnd=end;
	        burstSequence=(burstSequence+1)>>>0 || 1;
	        noticeBurst=burstSequence;
	      } else { lastNoticeAt=received; }
	      end=Math.min(end,noticeWindowEnd);
	      var next={id:keyOf(instance),provider:provider,appName:content.appName,burst:noticeBurst,title:record(heading,pictureOf(p.app_icon,24),end,
	        {kind:KIND.GENERIC,source:SOURCE.NOTIFICATION,label:settings.notificationAppOnly ? '' : appTitle}),
	        body:body ? record(body,null,end,{kind:KIND.GENERIC,source:SOURCE.NOTIFICATION}) : null};
	      // A stable reading interval must never postpone a source redaction.
	      var removesPrivateText=fresh(records[3]) && !next.body ||
	        !title && fresh(records[2]) && records[2].text !== heading;
	      if (!removesPrivateText && fresh(records[2]) && options.now()<noticeShownAt+NOTICE_STABLE_MS) {
	        pendingNotice=next; deferred=true;
	        if (noticeUpdateTimer === null) {
	          noticeUpdateTimer=options.later(function() {
	            noticeUpdateTimer=null;
	            var pending=pendingNotice; pendingNotice=null;
	            if (!pending || stopped || !connected || !baseline || !enabled('notifications') || !fresh(pending.title)) { return; }
	            activateNotice(pending); publish();
	          },Math.max(1,noticeShownAt+NOTICE_STABLE_MS-options.now()));
	        }
	      } else {
	        if (noticeUpdateTimer !== null) { options.cancelLater(noticeUpdateTimer); noticeUpdateTimer=null; }
	        pendingNotice=null;
	        activateNotice(next);
	      }
	      break; // The native source orders instances newest first.
	    }
	    syncNotificationActivity();
	    return deferred && !changed ? 'deferred' : undefined;
	  }
	  function close(name) {
	    var group=groups[name];
	    group.generation++;
	    if (group.handle && typeof group.handle.unsubscribe === 'function') {
	      try { group.handle.unsubscribe(); } catch (ignored) {}
	    }
	    group.handle=null;
	    cancelRecovery(name,false);
	  }
	  function updateAvailability() {
	    var current=typeof pebble.subscribeToSource === 'function';
	    if (current === available) { return false; }
	    available=current;
	    markBaseline();
	    // The phone can enable or disable the preview API while PKJS remains
	    // loaded. Neither old handles nor an old notification baseline survive it.
	    Object.keys(groups).forEach(function(name) {
	      close(name); clearGroup(name);
	      groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0;
	    });
	    return true;
	  }
	  function bind(name) {
	    close(name);
	    if (!connected || stopped || !available || !enabled(name)) { return; }
	    var group=groups[name], generation=group.generation, definition=DEFINITIONS[name];
	    var request={category:definition.category,item:definition.item,properties:definition.properties.slice(),
	      onData:function(envelope) { if (generation === group.generation && !stopped && connected) { sourceData(name,envelope); } },
	      onError:function(error) { if (generation === group.generation && !stopped && connected) { sourceError(name,error); } }};
	    if (name !== 'phone') { request.iconPixelSize=name === 'music' ? {w:40,h:40} : {w:24,h:24}; }
	    try {
	      var handle=pebble.subscribeToSource(request);
	      if (generation === group.generation && !stopped && connected) { group.handle=handle; }
	      else if (handle && typeof handle.unsubscribe === 'function') { handle.unsubscribe(); }
	    } catch (error) { if (generation === group.generation) { sourceError(name,error); } }
	  }
	  function scheduleHeartbeat() {
	    if (heartbeat !== null) { options.cancelLater(heartbeat); }
	    heartbeat=null;
	    if (!stopped && connected && available && (enabled('music') || enabled('phone'))) {
	      heartbeat=options.later(function() {
	        heartbeat=null;
	        // Native sources expose current state immediately on subscription.
	        // Rebinding renews a lease only when that authoritative delivery occurs.
	        var changed=updateAvailability();
	        if (enabled('music')) { bind('music'); }
	        if (enabled('phone')) { bind('phone'); }
	        if (changed && available && enabled('notifications')) { bind('notifications'); }
	        if (changed) { publish(); }
	        scheduleHeartbeat();
	      },HEARTBEAT);
	    }
	  }
	  function configure() {
	    if (stopped) { return; }
	    var availabilityChanged=updateAvailability();
	    var previous=settings;
	    settings=readSettings();
	    Object.keys(groups).forEach(function(name) {
	      var changed=availabilityChanged || !previous || name === 'music' && previous.showMusic !== settings.showMusic ||
	        name === 'phone' && previous.showStatus !== settings.showStatus || name === 'notifications' &&
	        (previous.showNotifications !== settings.showNotifications || previous.notificationPreview !== settings.notificationPreview ||
	          previous.notificationAppOnly !== settings.notificationAppOnly ||
	          JSON.stringify(previous.notificationApps) !== JSON.stringify(settings.notificationApps));
	      if (changed) { clearGroup(name); groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0; bind(name); }
	    });
	    publish(); scheduleHeartbeat();
	  }
	  function refresh(rebaseline, token) {
	    if (stopped) { return; }
	    // Set the boundary before configure/bind can synchronously publish data.
	    if (rebaseline) { markBaseline(token,true); }
	    if (!settings) { configure(); return; }
	    updateAvailability();
	    if (rebaseline) { bind('notifications'); }
	    else if (enabled('notifications') && !groups.notifications.handle) { bind('notifications'); }
	    if (enabled('music')) { bind('music'); }
	    if (enabled('phone')) { bind('phone'); }
	    publish(); scheduleHeartbeat();
	  }
	  function connectionChanged(value, token) {
	    if (stopped || typeof value !== 'boolean') { return; }
	    if (!value) {
	      connected=false;
	      baselineToken=null;
	      Object.keys(groups).forEach(function(name) { close(name); clearGroup(name); groups[name].error=''; groups[name].hasData=false; groups[name].receivedAt=null; groups[name].attempt=0; });
	      cancelDelivery();
	      if (heartbeat !== null) { options.cancelLater(heartbeat); }
	      if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
	      heartbeat=expiryTimer=null;
	      notify();
	    } else { connected=true; refresh(true,token); }
	  }
	  return {refresh:refresh,configure:configure,connectionChanged:connectionChanged,musicActivity:musicActivity,notificationActivity:notificationActivity,
	    musicProvider:function(){var card=musicActivity();return card?{uuid:card.provider,name:'Music',item:'track',available:true}:null;},
	    notificationProvider:function(){var card=notificationActivity();return card?{uuid:card.provider,name:'Notifications',item:'notification',available:true}:null;},
	    status:function() {
	      var sources={}, sourceStates={}, error='';
	      Object.keys(groups).forEach(function(name) { sources[name]=groups[name].error; });
	      Object.keys(groups).some(function(name) { if (enabled(name) && groups[name].error) { error=groups[name].error; return true; } return false; });
	      if (!available && Object.keys(groups).some(enabled)) { error='API_UNAVAILABLE'; }
	      var ready=!!settings && connected && (available || !Object.keys(groups).some(enabled)) &&
	        Object.keys(groups).every(function(name) { return !enabled(name) || groups[name].hasData; });
	      Object.keys(groups).forEach(function(name) {
	        var group=groups[name], state='ready', message=group.error;
	        if (!enabled(name)) { state='off'; message=''; }
	        else if (!connected || !available) { state='unavailable'; message=!connected ? 'DISCONNECTED' : 'API_UNAVAILABLE'; }
	        else if (group.error) { state=group.error === 'PERMISSION_DENIED' ? 'denied' : 'unavailable'; }
	        else if (!group.hasData) { state='waiting'; }
	        else if (name === 'music') {
	          if (fresh(records[0])) { state=playing ? 'playing' : 'paused'; }
	          else if (playing) { state='unavailable'; message='SOURCE_EXPIRED'; }
	          else { state='idle'; }
	        } else if (name === 'phone' && group.receivedAt !== null && now()-group.receivedAt>=LEASE) {
	          state='unavailable'; message='SOURCE_EXPIRED';
	        } else if (name === 'notifications' && !fresh(records[2])) { state='idle'; }
	        sourceStates[name]={state:state,message:message,receivedAt:group.receivedAt,
	          receivedAgeSec:group.receivedAt === null ? null : Math.max(0,now()-group.receivedAt),
	          observedAt:null,observationAgeSec:null};
	      });
	      return {available:available,connected:connected,ready:ready,error:error,music:!!fresh(records[0]),notification:!!fresh(records[2]),
	        phoneBattery:!!fresh(records[4]),sources:sources,sourceStates:sourceStates};
	    },
	    stop:function() {
	      Object.keys(groups).forEach(function(name) { close(name); clearGroup(name); });
	      stopped=true; cancelDelivery();
	      if (heartbeat !== null) { options.cancelLater(heartbeat); }
	      if (expiryTimer !== null) { options.cancelLater(expiryTimer); }
	      heartbeat=expiryTimer=null;
	      notify();
	    }};
	};


/***/ }),
/* 17 */
/***/ (function(module, exports) {

	'use strict';
	
	var VERSION = 4;
	var HEADER_BYTES = 56;
	var SEMANTIC_KIND = {GENERIC:0,TEMPERATURE:1,PRECIPITATION:2,BATTERY:3,HUMIDITY:4,WIND:5,UV:6,CONDITION:7,RANGE:8,NUMBER:9,BOOLEAN:10,TIMESTAMP:11};
	var SOURCE_KIND = {GENERIC:0,WEATHER:1,PHONE:2,MUSIC:3,NOTIFICATION:4,OTHER:5};
	var DETAIL_KIND = {NONE:0,TEMPERATURE:1,FEELS_LIKE:2,HIGH:3,LOW:4,PRECIPITATION:5,HUMIDITY:6,WIND_SPEED:7,WIND_DIRECTION:8,UV:9,CONDITION:10,PHONE_BATTERY:11};
	var QUALIFIERS = {FORECAST:1};
	var DETAIL_SEMANTIC = [0,1,1,1,1,2,4,5,5,6,7,3];
	var SLOT_COUNT = 5;
	var TEXT = 1;
	var BITMAP = 2;
	var IMAGE = 4;
	var TIMESTAMP = 8;
	var EMPTY = 0;
	var READY = 2;
	var UNAVAILABLE = 3;
	var UNSUPPORTED = 5;
	var EXPIRED = 7;
	var MAX_EPOCH = 4294967295;
	var MAX_AGE = 7200;
	var MAX_TEXT_BYTES = 128;
	
	function object(value) { return value && typeof value === 'object' && !Array.isArray(value); }
	function integer(value, minimum, maximum) {
	  return typeof value === 'number' && isFinite(value) && value >= minimum &&
	    value <= maximum && Math.floor(value) === value;
	}
	function bytes(value) {
	  return Array.isArray(value) || Object.prototype.toString.call(value) === '[object Uint8Array]';
	}
	function byteArray(value, length) {
	  if (!bytes(value) || value.length !== length) { return false; }
	  for (var i = 0; i < length; i++) { if (!integer(value[i], 0, 255)) { return false; } }
	  return true;
	}
	function scalar(text, at) {
	  var first = text.charCodeAt(at);
	  if (first >= 0xD800 && first <= 0xDBFF) {
	    var second = text.charCodeAt(at + 1);
	    if (second >= 0xDC00 && second <= 0xDFFF) {
	      return {value:0x10000 + (first - 0xD800) * 1024 + second - 0xDC00, length:2};
	    }
	    return {value:0xFFFD, length:1};
	  }
	  return {value:first >= 0xDC00 && first <= 0xDFFF ? 0xFFFD : first, length:1};
	}
	function scalarText(value) {
	  if (value <= 0xFFFF) { return String.fromCharCode(value); }
	  value -= 0x10000;
	  return String.fromCharCode(0xD800 + Math.floor(value / 1024), 0xDC00 + value % 1024);
	}
	function utf8Length(value) { return value < 0x80 ? 1 : value < 0x800 ? 2 : value < 0x10000 ? 3 : 4; }
	
	// The native decoder rejects control characters. Keep ordinary word boundaries
	// when sanitizing them, repair orphan surrogates and truncate only whole UTF-8
	// scalars, reserving an ellipsis when content exceeds the byte limit. The
	// bounded returned string is also suitable for coordinator storage and replay.
	function normalizeText(value, maxBytes) {
	  maxBytes = integer(maxBytes, 3, MAX_TEXT_BYTES) ? maxBytes : MAX_TEXT_BYTES;
	  if (typeof value !== 'string') { return ''; }
	  var result = '';
	  var ellipsisPrefix = '';
	  var count = 0;
	  var pendingSpace = false;
	  for (var i = 0; i < value.length;) {
	    var next = scalar(value, i);
	    i += next.length;
	    var code = next.value;
	    if (code < 0x20 || (code >= 0x7F && code <= 0x9F) || code === 0x2028 || code === 0x2029) { code = 0x20; }
	    // Defer spaces until another scalar arrives: trailing controls or spaces
	    // alone do not make an otherwise fitting string require an ellipsis.
	    if (code === 0x20) { pendingSpace = result.length > 0; continue; }
	    var length = utf8Length(code) + (pendingSpace ? 1 : 0);
	    if (count + length > maxBytes) { return ellipsisPrefix + '\u2026'; }
	    result += (pendingSpace ? ' ' : '') + scalarText(code);
	    count += length;
	    pendingSpace = false;
	    if (count <= maxBytes - 3) { ellipsisPrefix = result; }
	  }
	  return result;
	}
	function utf8(text) {
	  var out = [];
	  for (var i = 0; i < text.length;) {
	    var next = scalar(text, i);
	    var code = next.value;
	    i += next.length;
	    if (code < 0x80) { out.push(code); }
	    else if (code < 0x800) { out.push(0xC0 | (code >> 6), 0x80 | (code & 63)); }
	    else if (code < 0x10000) { out.push(0xE0 | (code >> 12), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63)); }
	    else { out.push(0xF0 | (code >> 18), 0x80 | ((code >> 12) & 63), 0x80 | ((code >> 6) & 63), 0x80 | (code & 63)); }
	  }
	  return out;
	}
	function u16(out, at, value) { out[at] = value & 255; out[at + 1] = Math.floor(value / 256) & 255; }
	function u32(out, at, value) {
	  for (var i = 0; i < 4; i++) { out[at + i] = Math.floor(value / Math.pow(256, i)) % 256; }
	}
	function crc16Xmodem(value) {
	  var crc = 0;
	  for (var i = 0; i < value.length; i++) {
	    crc ^= value[i] << 8;
	    for (var bit = 0; bit < 8; bit++) { crc = ((crc << 1) ^ (crc & 0x8000 ? 0x1021 : 0)) & 0xFFFF; }
	  }
	  return crc;
	}
	function statusRecord(status, headerBytes) {
	  headerBytes = headerBytes || HEADER_BYTES;
	  var result = [];
	  for (var i = 0; i < headerBytes; i++) { result.push(0); }
	  result[1] = status;
	  return result;
	}
	function bitmapOf(value, maxSize) {
	  maxSize = maxSize || 40;
	  if (!object(value) || !integer(value.width, 1, maxSize) || !integer(value.height, 1, maxSize) ||
	      !bytes(value.palette) || !integer(value.palette.length, 1, 16)) { return null; }
	  var stride = ((value.width + 7) >> 3) * 4;
	  var count = stride * value.height;
	  if (!byteArray(value.palette, value.palette.length) || !byteArray(value.pixels, count)) { return null; }
	  // The original palette length matters before padding to the 16-byte wire
	  // palette. Ignore row padding and the unused low nibble of odd-width rows.
	  for (var y = 0; y < value.height; y++) {
	    for (var x = 0; x < value.width; x++) {
	      var pair = value.pixels[y * stride + (x >> 1)];
	      var index = x & 1 ? pair & 15 : pair >> 4;
	      if (index >= value.palette.length) { return null; }
	    }
	  }
	  var palette = [];
	  for (var i = 0; i < 16; i++) { palette.push(i < value.palette.length ? value.palette[i] : 0); }
	  return {width:value.width, height:value.height, palette:palette,
	    pixels:Array.prototype.slice.call(value.pixels), image:value.image === true};
	}
	function f64(out, at, value) {
	  var buffer = new ArrayBuffer(8), view = new DataView(buffer);
	  view.setFloat64(0, value, true);
	  for (var i = 0; i < 8; ++i) { out[at + i] = view.getUint8(i); }
	}
	function semanticOf(slot, version, identityOnly) {
	  var value = slot.semantic;
	  if (!object(value)) { return null; }
	  var kind = value.kind === undefined ? 0 : value.kind;
	  var source = value.source === undefined ? 0 : value.source;
	  if (!integer(kind, 0, 11) || !integer(source, 0, 5)) { return null; }
	  var result = {kind:kind,source:source,flags:0,unit:[],label:[],detail:0,qualifiers:0,observedAt:0};
	  if (version === 4) {
	    var detail = value.detail === undefined ? 0 : value.detail;
	    var qualifiers = value.qualifiers === undefined ? 0 : value.qualifiers;
	    var observedAt = identityOnly || value.observedAt === undefined ? 0 : value.observedAt;
	    if (!integer(detail,0,11) || detail && DETAIL_SEMANTIC[detail] !== kind &&
	        !(detail === DETAIL_KIND.PRECIPITATION && (kind === SEMANTIC_KIND.GENERIC || kind === SEMANTIC_KIND.NUMBER)) ||
	        !integer(qualifiers,0,1) || qualifiers && source !== SOURCE_KIND.WEATHER ||
	        !integer(observedAt,0,MAX_EPOCH) || observedAt &&
	          (observedAt > slot.confirmedAt || qualifiers & QUALIFIERS.FORECAST)) { return null; }
	    result.detail=detail; result.qualifiers=qualifiers; result.observedAt=observedAt;
	  }
	  var fields = ['value','min','max'];
	  for (var i = 0; i < fields.length; ++i) {
	    if (!identityOnly && value[fields[i]] !== undefined) {
	      var numeric = value[fields[i]];
	      if (typeof numeric !== 'number' || !isFinite(numeric)) { return null; }
	      result[fields[i]] = numeric; result.flags |= 1 << i;
	    }
	  }
	  if ((result.flags & 6) === 6 && result.min > result.max) { return null; }
	  if (value.unit !== undefined) {
	    if (typeof value.unit !== 'string') { return null; }
	    result.unit = utf8(normalizeText(value.unit));
	    // A shortened unit could change its meaning. Omit invalid optional metadata.
	    if (result.unit.length > 16) { return null; }
	  }
	  if (value.label !== undefined) {
	    if (typeof value.label !== 'string') { return null; }
	    result.label = utf8(normalizeText(value.label,24));
	  }
	  return result;
	}
	
	function unavailableRecord(slot,status,version,header) {
	  if (version !== 4 || status === EMPTY) { return statusRecord(status === EXPIRED ? UNAVAILABLE : status,header); }
	  var metadata=semanticOf(slot,version,true), out=statusRecord(status,header);
	  // Identity may survive a public source failure, but private source names,
	  // old content, numbers and observation times never survive this path.
	  if (!metadata || metadata.source === SOURCE_KIND.MUSIC || metadata.source === SOURCE_KIND.NOTIFICATION) { return out; }
	  out[20]=metadata.kind; out[22]=metadata.unit.length; out[23]=metadata.label.length;
	  out[24]=metadata.source; out[25]=metadata.detail; out[26]=metadata.qualifiers;
	  return out.concat(metadata.unit,metadata.label);
	}
	function record(slot, nowSec, version) {
	  var header = version === 4 ? HEADER_BYTES : version === 3 ? 52 : 20;
	  if (slot === undefined || slot === null) { return statusRecord(EMPTY,header); }
	  if (!object(slot) || !integer(slot.status, 0, 7)) { return statusRecord(UNSUPPORTED,header); }
	  if (slot.status !== READY) { return unavailableRecord(slot,slot.status,version,header); }
	  if (!integer(nowSec, 1, MAX_EPOCH) || !integer(slot.confirmedAt, 1, MAX_EPOCH) ||
	      !integer(slot.validUntil, 1, MAX_EPOCH) || slot.confirmedAt > nowSec) { return statusRecord(UNAVAILABLE,header); }
	  var until = Math.min(slot.validUntil, slot.confirmedAt + MAX_AGE, MAX_EPOCH);
	  if (nowSec >= until) { return unavailableRecord(slot,version === 4 ? EXPIRED : UNAVAILABLE,version,header); }
	  var text = utf8(normalizeText(slot.text,version >= 3 ? 128 : 48));
	  var event = !text.length && integer(slot.timestamp, 1, MAX_EPOCH) ? slot.timestamp : null;
	  var bitmap = bitmapOf(slot.bitmap,version >= 3 ? 40 : 24);
	  var flags = (text.length ? TEXT : event !== null ? TIMESTAMP : 0) |
	    (bitmap ? BITMAP | (bitmap.image ? IMAGE : 0) : 0);
	  if (!flags) { return statusRecord(slot.timestamp === 0 ? UNAVAILABLE : UNSUPPORTED,header); }
	  var out = statusRecord(READY,header);
	  out[0] = flags;
	  out[2] = text.length;
	  out[3] = bitmap ? bitmap.width : 0;
	  out[4] = bitmap ? bitmap.height : 0;
	  // V2 uses the former reserved byte for a provider-aware presentation hint.
	  // Generic percentages (battery, humidity) never acquire precipitation art.
	  out[5] = version !== 1 && slot.displayKind === 1 && text.length ? 1 : 0;
	  u32(out, 6, slot.confirmedAt);
	  u32(out, 10, until);
	  u16(out, 14, bitmap ? bitmap.pixels.length : 0);
	  if (event !== null) { u32(out, 16, event); }
	  var semantic = version >= 3 ? semanticOf(slot,version,false) : null;
	  if (semantic) {
	    out[20] = semantic.kind; out[21] = semantic.flags;
	    out[22] = semantic.unit.length; out[23] = semantic.label.length; out[24] = semantic.source;
	    if (version === 4) {
	      out[25]=semantic.detail; out[26]=semantic.qualifiers; u32(out,52,semantic.observedAt);
	    }
	    if (semantic.flags & 1) { f64(out,28,semantic.value); }
	    if (semantic.flags & 2) { f64(out,36,semantic.min); }
	    if (semantic.flags & 4) { f64(out,44,semantic.max); }
	  }
	  out = out.concat(text,semantic ? semantic.unit : [],semantic ? semantic.label : []);
	  if (bitmap) { out = out.concat(bitmap.palette, bitmap.pixels); }
	  return out;
	}
	
	/** Five fixed slots, including holes. No fetching, cache mutation or inference. */
	function packComplications(slots, nowSec, version) {
	  version = version === 1 || version === 2 || version === 3 ? version : VERSION;
	  var out = [version, 0, 0, 0, 0, 0];
	  var values = Array.isArray(slots) ? slots : [];
	  for (var i = 0; i < SLOT_COUNT; i++) { out = out.concat(record(values[i], nowSec,version)); }
	  u16(out, 2, out.length);
	  // CRC bytes stay zero while calculating the checksum over the whole packet.
	  u16(out, 4, crc16Xmodem(out));
	  return out;
	}
	
	module.exports = {packComplications:packComplications, normalizeText:normalizeText, crc16Xmodem:crc16Xmodem, SEMANTIC_KIND:SEMANTIC_KIND, SOURCE_KIND:SOURCE_KIND, DETAIL_KIND:DETAIL_KIND, QUALIFIERS:QUALIFIERS};


/***/ }),
/* 18 */
/***/ (function(module, exports) {

	'use strict';
	
	var WATCH_STATE = '00000000-0000-0000-0001-000000000007';
	var RESULT = {PENDING: 1, SUCCESS: 2, FAILED: 3, STALE: 4, PERMISSION: 5, CANCELLED: 6, CONFIRM: 7};
	function positive(value) { return typeof value === 'number' && isFinite(value) && Math.floor(value) === value && value > 0 && value <= 2147483647; }
	function choice(value,max) { return typeof value==='number'&&isFinite(value)&&Math.floor(value)===value&&value>=0&&value<=max; }
	function copy(value) { return JSON.parse(JSON.stringify(value)); }
	function safeText(value) { return typeof value === 'string' ? value.replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 64) : ''; }
	
	module.exports = function createCommands(options) {
	  var pebble = options.pebble, now = options.now || Date.now, later = options.later || setTimeout;
	  var cancel = options.cancelLater || clearTimeout, session = 0, entries = Object.create(null), outstanding = null, watermark=0;
	  function prune(){
	    var ids=Object.keys(entries).sort(function(a,b){return Number(a)-Number(b);});
	    while(ids.length>32){
	      var evict=ids.filter(function(key){return entries[key]!==outstanding;})[0];
	      if(evict===undefined)return;
	      delete entries[evict];ids.splice(ids.indexOf(evict),1);
	    }
	  }
	  function emit(item, result, text) {
	    item.result = result; item.text = text || '';
	    options.sendResult(item.request, result, item.text);
	  }
	  function valid(item) {
	    var binding = options.lookup(item.token);
	    return session === item.session && binding && binding.version === item.version &&
	      binding.valid !== false && (!binding.expiresAt || binding.expiresAt * 1000 > now()) ? binding : null;
	  }
	  function finish(item, result, text) {
	    if (item.state !== 'dispatched' && item.state !== 'scheduled') return;
	    if (item.timer !== null) cancel(item.timer);
	    item.timer = null; item.state = 'done';
	    if (outstanding === item) outstanding = null;
	    if (options.onPending) options.onPending(item.token, false, result !== RESULT.SUCCESS);
	    if (session === item.session) emit(item, result, text);
	  }
	  function run(item) {
	    item.state = 'scheduled'; outstanding = item;
	    emit(item, RESULT.PENDING, 'Working…');
	    if (options.onPending) options.onPending(item.token, true, false);
	    // Dispatch in a microtask so a queued cancellation/source withdrawal can
	    // invalidate this exact target before the platform operation starts.
	    Promise.resolve().then(function () {
	      if (item.state !== 'scheduled' || session !== item.session) return;
	      var binding = valid(item), command = binding && (item.open ? binding.openApp : binding.actions && binding.actions[item.action]);
	      if (!command) { finish(item, RESULT.STALE, 'Item changed'); return; }
	      item.state = 'dispatched';
	      item.timer = later(function () { finish(item, RESULT.FAILED, 'No response'); }, 8000);
	      var request = item.open ? {plugin: WATCH_STATE, action: 'launch_app', args: {uuid: command.watchAppUuid}, timeoutMs: 8000} :
	        {plugin: command.plugin, action: command.action, args: copy(command.args || {}), timeoutMs: 8000};
	      var pending;
	      try { pending = pebble.invokeAction(request); }
	      catch (error) { finish(item, RESULT.FAILED, 'Action unavailable'); return; }
	      Promise.resolve(pending).then(function (result) {
	        if (item.state !== 'dispatched' || session !== item.session) return;
	        if (!result || result.ok !== true) {
	          var code = result && result.code;
	          finish(item, code === 'PERMISSION_DENIED' || code === 'AUTH_REQUIRED' ? RESULT.PERMISSION : RESULT.FAILED,
	            code === 'PERMISSION_DENIED' ? 'Allow in Pebble app' : code === 'AUTH_REQUIRED' ? 'Sign in on phone' : 'Action failed');
	          return;
	        }
	        finish(item, RESULT.SUCCESS, safeText(result.text) || (item.open ? 'Opening app' : 'Action sent'));
	        if (!item.open && options.onRefresh) options.onRefresh(result.refreshed, binding);
	      }, function (error) {
	        if (item.state === 'dispatched') finish(item, error && error.code === 'PERMISSION_DENIED' ? RESULT.PERMISSION : RESULT.FAILED,
	          error && error.code === 'PERMISSION_DENIED' ? 'Allow in Pebble app' : 'Action failed');
	      });
	    });
	  }
	  function cancelAll() {
	    Object.keys(entries).forEach(function (key) { var item = entries[key]; if (item.timer !== null) cancel(item.timer); item.state = 'cancelled'; });
	    entries = Object.create(null); outstanding = null;watermark=0;
	  }
	  return {
	    start: function (next) { cancelAll(); session = positive(next) ? next : 0; },
	    stop: function () { cancelAll(); session = 0; },
	    execute: function (request, open) {
	      if(request&&open&&request.action===undefined){request=copy(request);request.action=0;}
	      if (!request || request.session !== session || !positive(session) || !positive(request.request) ||
	          !positive(request.token) || !positive(request.version) || !choice(request.action,2) || !choice(request.confirm,1) ||
	          typeof pebble.invokeAction !== 'function') return false;
	      var old = entries[request.request];
	      if (old) {
	        if (old.token !== request.token || old.version !== request.version || old.open !== !!open || old.action !== request.action) return false;
	        if (old.state === 'confirm' && request.confirm === 1) {
	          if (outstanding) { old.state='done';emit(old,RESULT.FAILED,'Still working');return false; }
	          if (!valid(old)) { old.state = 'done'; emit(old, RESULT.STALE, 'Item changed'); return false; }
	          run(old); return true;
	        }
	        emit(old, old.result, old.text); return false;
	      }
	      // Keep only recent receipt details. The native request counter is strictly
	      // increasing; its high-water mark prevents an evicted old request from
	      // ever being dispatched again, without limiting the session's lifetime.
	      if(request.request<=watermark){options.sendResult(request.request,RESULT.STALE,'Already handled');return false;}
	      watermark=request.request;
	      var item = {session: session, request: request.request, token: request.token, version: request.version,
	        action: request.action, open: !!open, state: 'new', timer: null};
	      entries[item.request] = item;
	      prune();
	      var binding = valid(item), command = binding && (open ? binding.openApp : binding.actions && binding.actions[item.action]);
	      if (!command) { item.state = 'done'; emit(item, RESULT.STALE, 'Item changed'); return false; }
	      if (outstanding) { item.state = 'done'; emit(item, RESULT.FAILED, 'Still working'); return false; }
	      if (!open && command.confirm) { item.state = 'confirm'; emit(item, RESULT.CONFIRM, command.label || 'Confirm action'); return true; }
	      if (request.confirm === 1) { item.state = 'done'; emit(item, RESULT.STALE, 'Confirm again'); return false; }
	      run(item); return true;
	    }
	  };
	};
	module.exports.RESULT = RESULT;


/***/ }),
/* 19 */
/***/ (function(module, exports) {

	'use strict';
	
	// All snapshots and command replies share one FIFO. Only unsent display frames
	// are replaceable; acknowledgements/results are never coalesced or retried.
	module.exports = function createQueue(send, options) {
	  options = options || {};
	  var pending = [], active = null, epoch = 0, limit = options.limit || 12;
	  function flush() {
	    if (active || !pending.length) return;
	    var item = pending.shift(), generation = epoch, settled = false;
	    active = item;
	    function done(ok) {
	      if (settled) return;
	      settled = true;
	      active = null;
	      var callback = generation === epoch ? ok ? item.success : item.failure : null;
	      if (callback) callback();
	      flush();
	    }
	    try { send(item.message, function () { done(true); }, function () { done(false); }); }
	    catch (error) { done(false); }
	  }
	  return {
	    send: function (message, success, failure, replaceKey) {
	      if (replaceKey) {
	        pending = pending.filter(function (item) {
	          if (item.replaceKey !== replaceKey) return true;
	          if (item.failure) item.failure('SUPERSEDED');
	          return false;
	        });
	      }
	      if (pending.length >= limit) { if (failure) failure('QUEUE_FULL'); return false; }
	      pending.push({message: message, success: success, failure: failure, replaceKey: replaceKey});
	      flush(); return true;
	    },
	    // AppMessage still owns an in-flight send. Wait for that one callback before
	    // sending the new session, while suppressing all obsolete continuations.
	    clear: function () { epoch++; pending = []; },
	    length: function () { return pending.length + (active ? 1 : 0); }
	  };
	};


/***/ }),
/* 20 */
/***/ (function(module, exports, __webpack_require__) {

	'use strict';
	
	var model = __webpack_require__(5);
	var appPicker = __webpack_require__(21);
	var makeLanguage = __webpack_require__(22);
	function behavior(initial, makeModel, makeApps, makeLanguage) {
	  'use strict';
	  var language = makeLanguage((navigator.languages && navigator.languages[0]) || navigator.language || 'en'), t = language.text;
	  language.staticPage(document.body);
	  var model = makeModel(), apps = makeApps(), $ = function(id) { return document.getElementById(id); };
	  var draft, confirmed = '', loaded = false, phase = 'loading', uncertain = false, repairing = false, savedHere = false;
	  var catalogue = initial.catalogue || {plugins:[], instances:[], activities:[]}, bridgeReady = false, pkjsReady = false;
	  var channels = {}, editing = null, inspectVersion = 0, sourceEntries = [], actionEntries = [], argumentFields = [];
	  var legacy = initial.mode === 'legacy';
	  var cataloguePhase = legacy ? catalogue.error ? 'error' : 'ready' : 'waiting';
	  var catalogueMessage = '', bridgeTimer = null, catalogueRefresh = 0, catalogueTargetTimer = null;
	  var appEntries = [], appResults = [], appRequest = null, appSearchVersion = 0;
	  function clone(value) { return JSON.parse(JSON.stringify(value)); }
	  function say(value, error) { $('status').textContent = t(value); $('status').className = error ? 'status error' : 'status'; }
	  function meta(value, fallback) { return typeof value === 'string' && value ? value : fallback || ''; }
	  function node(tag, value, className) { var el = document.createElement(tag); if (value !== undefined) el.textContent = value; if (className) el.className = className; return el; }
	  function option(select, value, label) { var el = node('option', label); el.value = value; select.appendChild(el); }
	  function pending() { return phase === 'saving'; }
	  function dirty() {
	    if(!loaded)return false;if(repairing||uncertain)return true;
	    if(editing!==null){try{return JSON.stringify(editedSettings())!==confirmed;}catch(error){return true;}}
	    return JSON.stringify(draft)!==confirmed;
	  }
	  function controls() {
	    document.querySelectorAll('[data-edit]').forEach(function(field) { field.disabled = !loaded || pending() || editing !== null && !!field.closest('#pins') || field.getAttribute('data-boundary') === 'true' || field.getAttribute('data-automatic') === 'true'; });
	    $('save').disabled = !loaded || pending() || !dirty();
	    $('discard').disabled = pending() || !loaded || !dirty() && editing === null;
	    $('discard').textContent = legacy ? t('Cancel') : uncertain ? t('Reload saved') : t('Discard');
	    $('save').textContent = t('Save');
	    $('retry').hidden = phase !== 'load-error';
	    $('add-pin').disabled = !loaded || pending() || editing !== null || draft.pins.length >= 64;
	    $('preview').disabled = !loaded || pending() || !draft.showNotifications;
	    $('editor').hidden = editing === null;
	    $('editor-cancel').disabled = pending();
	    if (editing !== null) {
	      $('editor-heading').textContent = editing.index < draft.pins.length ? t('Edit pinned item') : t('Add pinned item');
	      $('editor-save').textContent = editing.index < draft.pins.length ? t('Done') : t('Add pin');
	      $('pin-quick-setup').hidden = editing.index < draft.pins.length;
	    }
	  }
	  function draftStatus() {
	    say(uncertain?t('Save not confirmed. Reload saved settings or save again.'):dirty()?t('Unsaved changes.'):savedHere?t('✓ Saved'):t('No changes to save.'),uncertain);
	  }
	  function changed() {
	    if (!loaded || pending()) return;
	    draft.dark = $('dark').value === 'dark'; draft.showNotifications = $('notifications').checked; draft.notificationPreview = $('preview').checked;
	    controls();draftStatus();
	  }
	  function apply(value, needsRepair) {
	    cancelAppSearch();
	    draft = model.normalize(value); confirmed = JSON.stringify(draft); loaded = true; phase = 'ready'; uncertain = false; repairing = !!needsRepair; savedHere = false; editing = null;
	    $('dark').value = draft.dark ? 'dark' : 'light'; $('notifications').checked = draft.showNotifications; $('preview').checked = draft.notificationPreview;
	    renderPins(); renderActivities(); controls();
	    say(repairing ? t('Saved settings were unreadable. Review these defaults before explicitly saving.') : t('No changes to save.'), repairing);
	  }
	  function request(payload, complete, failure, channel, target) {
	    channel = channel || 'settings';
	    var slot = channels[channel] || (channels[channel] = {id:0, timer:null}), id = ++slot.id;
	    if (slot.timer !== null) clearTimeout(slot.timer);
	    slot.timer = setTimeout(function() { if (slot.id === id) { slot.id++; slot.timer = null; failure(); } }, 7000);
	    function done(fn, response) { if (slot.id !== id) return; slot.id++; clearTimeout(slot.timer); slot.timer = null; fn(response); }
	    try {
	      var result = Pebble.sendMessage(target || 'plugin', payload);
	      if (!result || typeof result.then !== 'function') { done(failure); return; }
	      result.then(function(response) { done(complete, response); }, function() { done(failure); });
	    } catch (error) { done(failure); }
	  }
	  function loadFailed() { phase = 'load-error'; loaded = false; controls(); say(t('Could not load saved settings. Retry before editing.'), true); }
	  function load() {
	    phase = 'loading'; loaded = false; editing = null; controls(); say(t('Loading settings…'));
	    if (!bridgeReady) {
	      if (bridgeTimer !== null) clearTimeout(bridgeTimer);
	      bridgeTimer = setTimeout(function() { bridgeTimer = null; loadFailed(); catalogueFailed(t('Pebble did not connect to the settings plugin. Reopen this page from Pebble.')); }, 7000);
	      return;
	    }
	    request({type:'load_settings'}, function(response) {
	      try { if (!response || response.ok !== true) throw Error(); apply(response.settings, response.needsRepair); }
	      catch (error) { loadFailed(); }
	    }, loadFailed);
	    refreshCatalogue();
	  }
	  function sourceKey(reading) { return [reading.plugin || '',reading.category,reading.item].join('|'); }
	  function actionKey(action) { return action.plugin + '|' + action.action; }
	  function collectSources() {
	    var entries = [
	      {key:'|weather|location', category:'weather', item:'location', name:t('Weather'), properties:{temperature:['numericValue'], humidity:['numericValue'], high:['numericValue'], low:['numericValue'], condition:['shortText'], sunrise:['timestamp'], sunset:['timestamp']}},
	      {key:'|phone|phone_state', category:'phone', item:'phone_state', name:t('Phone'), properties:{battery_level:['numericValue'], charging:['boolean']}},
	      {key:'|watch-local|battery', category:'watch-local', item:'battery', name:t('Watch battery'), properties:{level:['numericValue']}}
	    ];
	    (catalogue.plugins || []).forEach(function(plugin) {
	      (plugin.sources || []).forEach(function(source) {
	        if (!source || typeof source.category !== 'string' || source.category === 'activity') return;
	        (source.items || []).forEach(function(item) {
	          if (typeof item !== 'string' || source.category === 'phone' && item === 'find_my_phone') return;
	          var entry = {plugin:plugin.uuid, category:source.category, item:item, properties:source.properties || {}, name:meta(plugin.name, 'Plugin') + ' · ' + friendly(item)};
	          entry.key = sourceKey(entry); entries.push(entry);
	        });
	      });
	    });
	    return entries;
	  }
	  function collectActions() {
	    var entries = [];
	    (catalogue.plugins || []).forEach(function(plugin) {
	      (plugin.actions || []).forEach(function(action) {
	        if (!action || typeof action.name !== 'string') return;
	        entries.push({key:plugin.uuid + '|' + action.name, plugin:plugin.uuid, action:action.name, name:meta(plugin.name, 'Plugin') + ' · ' + meta(action.label || action.title, friendly(action.name)), metadata:action});
	      });
	    });
	    return entries;
	  }
	  function refreshCatalogue() {
	    if (legacy || !bridgeReady) return;
	    var refresh = ++catalogueRefresh, chosen = false;
	    if (catalogueTargetTimer !== null) clearTimeout(catalogueTargetTimer);
	    catalogueTargetTimer = null;
	    cataloguePhase = 'loading'; catalogueMessage = ''; renderActivities(); controls();
	    $('catalogue-status').textContent = t('Loading available plugins…');
	    function fetch(target, fallback) {
	      if (refresh !== catalogueRefresh) return;
	      request({type:'catalogue'}, function(response) {
	        if (refresh !== catalogueRefresh) return;
	        if (!response || response.ok !== true || !response.catalogue || !Array.isArray(response.catalogue.plugins) || !Array.isArray(response.catalogue.activities)) {
	          if (target === 'pkjs' && (!response || response.ok !== false)) { fetch('plugin', true); return; }
	          catalogueFailed(response && response.message); return;
	        }
	        catalogue = response.catalogue; cataloguePhase = response.cached ? 'cached' : 'ready'; catalogueMessage = t(meta(response.message, ''));
	        if (fallback) catalogueMessage = t('Live discovery is unavailable. ') + (catalogueMessage || t('Open Dashboard on your watch to refresh installed plugins.'));
	        renderActivities(); controls();
	        $('catalogue-status').textContent = response.cached ? catalogueMessage || t('Saved plugin metadata. Open Dashboard on your watch to refresh installed plugins.') :
	          t('Choose from ') + (catalogue.plugins || []).length + t(' installed plugins. Saved unavailable bindings are kept.');
	        // A delayed catalogue reply must not replace fields being edited. The
	        // next explicit editor open picks up the refreshed metadata.
	        if (editing !== null) $('inspect-status').textContent = t('Available plugins updated. Reopen this item to use the refreshed choices.');
	        else { sourceEntries = collectSources(); actionEntries = collectActions(); }
	      }, function() { if (refresh !== catalogueRefresh) return; if (target === 'pkjs') fetch('plugin', true); else catalogueFailed(); }, 'catalogue', target);
	    }
	    function choose(target) {
	      if (chosen || refresh !== catalogueRefresh) return;
	      chosen = true; clearTimeout(catalogueTargetTimer); catalogueTargetTimer = null; fetch(target);
	    }
	    if (typeof Pebble.targets === 'function') {
	      catalogueTargetTimer = setTimeout(function() { choose(pkjsReady ? 'pkjs' : 'plugin'); }, 7000);
	      try { Promise.resolve(Pebble.targets()).then(function(targets) {
	        choose(Array.isArray(targets) ? targets.some(function(target) { return target && target.id === 'pkjs'; }) ? 'pkjs' : 'plugin' : pkjsReady ? 'pkjs' : 'plugin');
	      }, function() { choose(pkjsReady ? 'pkjs' : 'plugin'); }); }
	      catch (error) { choose(pkjsReady ? 'pkjs' : 'plugin'); }
	    } else choose(pkjsReady ? 'pkjs' : 'plugin');
	  }
	  function catalogueFailed(message) {
	    cataloguePhase = 'error'; catalogueMessage = t(meta(message, t('Plugin discovery failed. Check plugin access in Pebble, then retry.'))).slice(0, 180);
	    $('catalogue-status').textContent = catalogueMessage + t(' Your saved items are kept.');
	    renderActivities(); controls();
	  }
	  function summary(pin) {
	    var parts = [];
	    if (pin.reading) parts.push(readingTitle(pin.reading));
	    if (pin.builtin) parts.push(t('Tap: Ring phone'));
	    else if (pin.action) parts.push(t('Tap: ') + pin.action.label);
	    if (pin.openApp) parts.push(t('Hold: ') + pin.openApp.label);
	    return parts.join(' · ') || t('No reading or action configured');
	  }
	  function smallButton(label, action, title, disabled) {
	    var button = node('button', label); button.type = 'button'; button.setAttribute('data-edit', '');
	    if (title) button.setAttribute('aria-label', title); button.disabled = !!disabled;
	    if (disabled) button.setAttribute('data-boundary', 'true');
	    button.onclick = action; return button;
	  }
	  function moved() { renderPins(); renderActivities(); controls(); say(t('Unsaved changes.')); }
	  function renderPins() {
	    var list = $('pins'); list.textContent = '';
	    if (!draft) return;
	    draft.pins.forEach(function(pin, index) {
	      var row = node('li', undefined, 'item'), title = node('div', undefined, 'item-title');
	      title.appendChild(node('strong', pin.label)); title.appendChild(node('span', String(index + 1), 'position')); row.appendChild(title);
	      row.appendChild(node('p', summary(pin), 'hint'));
	      var buttons = node('div', undefined, 'row-buttons');
	      buttons.appendChild(smallButton(t('Edit'), function() { openEditor(index); }, t('Edit ') + pin.label));
	      buttons.appendChild(smallButton('↑', function() { if (index > 0) { var item = draft.pins.splice(index, 1)[0]; draft.pins.splice(index - 1, 0, item); moved(); } }, t('Move ') + pin.label + t(' up'), index === 0));
	      buttons.appendChild(smallButton('↓', function() { if (index + 1 < draft.pins.length) { var item = draft.pins.splice(index, 1)[0]; draft.pins.splice(index + 1, 0, item); moved(); } }, t('Move ') + pin.label + t(' down'), index + 1 === draft.pins.length));
	      buttons.appendChild(smallButton(t('Remove'), function() { draft.pins.splice(index, 1); moved(); }, t('Remove ') + pin.label));
	      row.appendChild(buttons); list.appendChild(row);
	    });
	    $('pins-empty').hidden = !!draft.pins.length;
	  }
	  function activityList() {
	    var known = {'builtin:music':{key:'builtin:music', name:t('Music')}};
	    (catalogue.activities || []).forEach(function(item) { if (item && typeof item.key === 'string') known[item.key] = {key:item.key, name:meta(item.name, item.key)}; });
	    var keys = (draft ? draft.activityOrder : []).slice();
	    if (draft) draft.disabledActivities.forEach(function(key) { if (keys.indexOf(key) < 0) keys.push(key); });
	    Object.keys(known).forEach(function(key) { if (keys.indexOf(key) < 0) keys.push(key); });
	    return keys.map(function(key) { return known[key] || {key:key, name:t('Unavailable activity (') + key + ')'}; });
	  }
	  function renderActivities() {
	    var status = $('activities-status'), retry = $('retry-activities');
	    status.className = cataloguePhase === 'error' ? 'hint error' : 'hint';
	    status.textContent = cataloguePhase === 'waiting' ? t('Connecting to Pebble to discover installed activity providers…') :
	      cataloguePhase === 'loading' ? t('Loading installed activity providers…') :
	      cataloguePhase === 'error' ? catalogueMessage || catalogue.error || t('Could not discover installed activity providers. Music and your saved choices are still shown.') :
	      cataloguePhase === 'cached' ? catalogueMessage || t('Saved provider list. Open Dashboard on your watch to refresh installed plugins, then check again.') :
	      t('Installed activity providers are listed even when no activity is running.');
	    retry.hidden = legacy || cataloguePhase !== 'error' && cataloguePhase !== 'cached'; retry.disabled = pending();
	    retry.textContent = cataloguePhase === 'cached' ? t('Check again') : t('Retry activity discovery');
	    var target = $('activities'); target.textContent = ''; if (!draft) return;
	    var activities = activityList(); $('activities-empty').hidden = !!activities.length;
	    activities.forEach(function(activity, index) {
	      var row = node('li', undefined, 'item activity-item'), label = node('label', undefined, 'inline'), check = node('input');
	      check.type = 'checkbox'; check.checked = draft.disabledActivities.indexOf(activity.key) < 0; check.setAttribute('data-edit', '');
	      check.onchange = function() {
	        var i = draft.disabledActivities.indexOf(activity.key);
	        if (check.checked && i >= 0) draft.disabledActivities.splice(i, 1);
	        if (!check.checked && i < 0) draft.disabledActivities.push(activity.key);
	        controls(); say(t('Unsaved changes.'));
	      };
	      label.appendChild(check); label.appendChild(node('span', activity.name)); row.appendChild(label);
	      var buttons = node('div', undefined, 'row-buttons');
	      function move(delta) { var keys = activities.map(function(item) { return item.key; }), next = index + delta; if (next < 0 || next >= keys.length) return; keys.splice(index, 1); keys.splice(next, 0, activity.key); draft.activityOrder = keys; moved(); }
	      buttons.appendChild(smallButton('↑', function() { move(-1); }, t('Raise priority of ') + activity.name, index === 0));
	      buttons.appendChild(smallButton('↓', function() { move(1); }, t('Lower priority of ') + activity.name, index + 1 === activities.length));
	      row.appendChild(buttons); target.appendChild(row);
	    });
	  }
	  function currentSource() { return sourceEntries.filter(function(entry) { return entry.key === $('source').value; })[0]; }
	  function currentAction() { return actionEntries.filter(function(entry) { return entry.key === $('action').value; })[0]; }
	  function friendly(value) {
	    if (typeof value !== 'string' || !value) return t('Reading');
	    var labels = {temperature:t('Temperature'),humidity:t('Humidity'),high:t('High'),low:t('Low'),condition:t('Conditions'),sunrise:t('Sunrise'),sunset:t('Sunset'),
	      battery_level:t('Battery'),level:t('Level'),charging:t('Charging'),brightness:t('Brightness'),on:t('On / off'),name:t('Name')};
	    return labels[value] || value.replace(/[_-]+/g, ' ').replace(/^./, function(c) { return c.toUpperCase(); });
	  }
	  function readingTitle(reading) {
	    if (reading.category === 'watch-local') return t('Watch battery');
	    if (reading.category === 'phone') return t('Phone · ') + friendly(reading.property);
	    if (reading.category === 'weather') return t('Weather · ') + friendly(reading.property);
	    var plugin = (catalogue.plugins || []).filter(function(item) { return item.uuid === reading.plugin; })[0];
	    return (plugin ? meta(plugin.name, 'Plugin') + ' · ' : '') + friendly(reading.property);
	  }
	  function suggestName(name, icon) {
	    if (!editing || editing.index < draft.pins.length) return;
	    if (!editing.nameChanged) $('pin-label').value = apps.label(name) || t('New item');
	    if (!editing.iconChanged && icon) $('icon').value = icon;
	  }
	  function cancelAppSearch() {
	    appSearchVersion++;
	    var current = appRequest; appRequest = null;
	    if (current) try { current.abort(); } catch (ignored) {}
	    if ($('app-search')) $('app-search').textContent = t('Search');
	  }
	  function currentApp() { return appEntries.filter(function(entry) { return entry.uuid === $('app-target').value; })[0]; }
	  function renderAppChoices(selected) {
	    if (!editing) return;
	    var chosen = selected === undefined ? $('app-target').value : selected, seen = Object.create(null), entries = [];
	    function add(entry) {
	      if (!entry || !entry.uuid || seen[entry.uuid.toLowerCase()]) return;
	      var copy = clone(entry); copy.uuid = copy.uuid.toLowerCase(); seen[copy.uuid] = true; entries.push(copy);
	    }
	    apps.common().forEach(add);
	    draft.pins.forEach(function(pin) { if (pin.openApp) add({uuid:pin.openApp.watchAppUuid,name:pin.openApp.label,origin:'saved',icon:pin.icon || 'generic'}); });
	    if (editing.pin.openApp) add({uuid:editing.pin.openApp.watchAppUuid,name:editing.pin.openApp.label,origin:'saved',icon:editing.pin.icon || 'generic'});
	    add(editing.app); appResults.forEach(add);
	    if (chosen && chosen !== '__custom__' && !seen[chosen]) add({uuid:chosen,name:$('app-label').value || t('Saved app'),origin:'saved',icon:'generic'});
	    appEntries = entries; var target = $('app-target'); target.textContent = ''; option(target, '', t('Do nothing'));
	    [['system',t('PebbleOS apps')],['common',t('Other apps')],['saved',t('Your saved apps')],['store',t('Store search results')]].forEach(function(group) {
	      var items = entries.filter(function(entry) { return entry.origin === group[0]; }); if (!items.length) return;
	      var list = node('optgroup'); list.label = t(group[1]);
	      items.forEach(function(entry) { option(list, entry.uuid, entry.name + (entry.author && entry.origin !== 'system' ? ' · ' + entry.author : '')); }); target.appendChild(list);
	    });
	    option(target, '__custom__', t('Custom app…')); target.value = chosen || '';
	    renderAppState(); renderAppResults();
	  }
	  function renderAppResults() {
	    var list = $('app-results'); list.textContent = '';
	    appResults.forEach(function(entry) {
	      var button = node('button'); button.type = 'button'; button.setAttribute('data-edit', ''); button.setAttribute('data-app-uuid', entry.uuid);
	      button.setAttribute('aria-label', t('Choose ') + entry.name + (entry.author ? t(' by ') + entry.author : ''));
	      button.appendChild(node('strong', entry.name)); if (entry.author) button.appendChild(node('span', entry.author, 'hint'));
	      button.onclick = function() { $('app-target').value = entry.uuid; selectApp(); $('app-search-panel').open = false; $('app-target').scrollIntoView({block:'center'}); };
	      list.appendChild(button);
	    });
	  }
	  function renderAppState() {
	    var selected = $('app-target').value, custom = selected === '__custom__';
	    $('app-fields').hidden = !selected; $('custom-app-fields').hidden = !custom;
	    if (custom) $('app-advanced').open = true;
	    $('app-selection').textContent = !selected ? t('Hold Select will do nothing.') : custom ? t('Enter the details for an unlisted app below.') :
	      t('Hold Select opens ') + ($('app-label').value || (currentApp() && currentApp().name) || t('the selected app')) + '.';
	  }
	  function selectApp() {
	    if (!editing) return;
	    cancelAppSearch();
	    var selected = currentApp();
	    if (selected) {
	      var previous = $('app-uuid').value.trim().toLowerCase(); editing.app = clone(selected); $('app-uuid').value = selected.uuid;
	      if (selected.uuid !== previous || !$('app-label').value.trim()) $('app-label').value = apps.label(selected.name);
	      suggestName(selected.name, selected.icon || 'generic');
	    }
	    renderAppState();
	  }
	  function searchApps() {
	    if (!editing || !loaded || pending()) return;
	    cancelAppSearch(); var editor = editing, version = appSearchVersion, query = $('app-search-query').value.trim(), url;
	    try { url = apps.searchUrl(query); } catch (error) { $('app-status').textContent = t(error.message || t('Enter an app name.')); return; }
	    appResults = []; renderAppChoices();
	    $('app-status').textContent = t('Searching the Pebble app store…'); $('app-search').textContent = t('Search again');
	    function active() { return editing === editor && version === appSearchVersion; }
	    function failed() { if (active()) { appRequest = null; $('app-search').textContent = t('Search'); $('app-status').textContent = t('Could not search the app store. Check your connection and Dashboard’s app-store Internet access in Pebble. After changing access, finish and save any edits, then reopen these settings. Your selected app is kept.'); } }
	    try {
	      var request = new XMLHttpRequest(); appRequest = request; request.open('GET', url, true); request.timeout = 7000; request.withCredentials = false;
	      request.onerror = request.ontimeout = failed;
	      request.onload = function() {
	        if (!active()) return;
	        appRequest = null; $('app-search').textContent = t('Search');
	        try {
	          if (request.status !== 200 || typeof request.responseText !== 'string' || request.responseText.length > 524288) throw Error('Invalid app store response');
	          var body = JSON.parse(request.responseText); if (!body || !Array.isArray(body.hits)) throw Error('Invalid app store response');
	          appResults = apps.parseResults(body); renderAppChoices();
	          $('app-status').textContent = appResults.length ? t('Choose an app below. It must already be installed on your watch.') : t('No compatible apps found. Try another name, or use Custom app for an unlisted app.');
	        } catch (error) { failed(); }
	      };
	      request.send();
	    } catch (error) { failed(); }
	  }
	  function refreshEditorChoices() {
	    if (editing === null) return;
	    var current = editing.pin, sourceValue = $('source').value || current.reading && sourceKey(current.reading), actionValue = $('action').value || (current.builtin ? 'builtin:find-phone' : current.action && actionKey(current.action)) || 'none';
	    sourceEntries = collectSources(); actionEntries = collectActions();
	    if (current.reading && !sourceEntries.some(function(entry) { return entry.key === sourceKey(current.reading); })) {
	      var missing = clone(current.reading); missing.key = sourceKey(missing); missing.name = t('Saved source · unavailable'); missing.properties = {}; missing.properties[missing.property] = ['shortText']; sourceEntries.push(missing);
	    }
	    $('source').textContent = ''; sourceEntries.forEach(function(entry) { option($('source'), entry.key, entry.name); }); $('source').value = sourceValue || sourceEntries[0].key;
	    $('action').textContent = ''; option($('action'), 'none', t('No tap action')); option($('action'), 'builtin:find-phone', t('Find phone · Ring'));
	    actionEntries.forEach(function(entry) { option($('action'), entry.key, entry.name); });
	    if (current.action && !actionEntries.some(function(entry) { return entry.key === actionKey(current.action); })) {
	      var missingAction = {key:actionKey(current.action), plugin:current.action.plugin, action:current.action.action, name:t('Saved action · unavailable'), metadata:{}}; actionEntries.push(missingAction); option($('action'), missingAction.key, missingAction.name);
	    }
	    $('action').value = actionValue; refreshProperties(current.reading); renderArguments(current.action && current.action.args || {}); renderEditorState();
	  }
	  function refreshProperties(reading) {
	    var source = currentSource(), selectedProperty = reading && reading.property || $('property').value, props = source && source.properties || {};
	    $('property').textContent = '';
	    Object.keys(props).filter(function(name) { return (props[name] || []).some(function(shape) { return ['shortText','longText','numericValue','timestamp','boolean'].indexOf(shape) >= 0; }); }).forEach(function(name) { option($('property'), name, friendly(name)); });
	    if (selectedProperty && !Array.from($('property').options).some(function(item) { return item.value === selectedProperty; })) option($('property'), selectedProperty, selectedProperty + t(' (saved)'));
	    if (selectedProperty) $('property').value = selectedProperty;
	    $('toggle').textContent = ''; option($('toggle'), '', t('Use the entered action arguments'));
	    Object.keys(props).filter(function(name) { return (props[name] || []).indexOf('boolean') >= 0; }).forEach(function(name) { option($('toggle'), name, t('Toggle using ') + name); });
	    if (reading && editing && editing.pin.action && editing.pin.action.toggleProperty) {
	      var toggle = editing.pin.action.toggleProperty;
	      if (!Array.from($('toggle').options).some(function(item) { return item.value === toggle; })) option($('toggle'), toggle, toggle + t(' (saved on/off property)'));
	      $('toggle').value = toggle;
	    }
	    renderInstances(reading);
	    automaticArguments();
	  }
	  function renderInstances(reading) {
	    var source = currentSource(), selected = reading && reading.instanceId !== undefined ? 'id:' + reading.instanceId : $('instance').value || 'index:0';
	    $('instance').textContent = ''; option($('instance'), 'index:0', t('First instance (source order)'));
	    (catalogue.instances || []).filter(function(item) { return source && item.category === source.category && item.item === source.item && (!source.plugin || item.plugin === source.plugin); }).forEach(function(item) { option($('instance'), 'id:' + item.instanceId, meta(item.name, item.instanceId)); });
	    if (reading && reading.instanceId === undefined && reading.index > 0) { selected = 'index:' + reading.index; option($('instance'), selected, t('Source position ') + (reading.index + 1) + t(' (saved)')); }
	    if (selected && !Array.from($('instance').options).some(function(item) { return item.value === selected; })) option($('instance'), selected, selected.slice(3) + t(' (saved instance)'));
	    $('instance').value = selected;
	    $('inspect-source').disabled = !source || source.category === 'watch-local';
	    $('inspect-source').setAttribute('data-boundary', $('inspect-source').disabled ? 'true' : 'false');
	  }
	  function renderEditorState() {
	    $('reading-fields').hidden = !$('has-reading').checked;
	    var hasAction = $('action').value !== 'none'; $('action-fields').hidden = !hasAction || $('action').value === 'builtin:find-phone';
	    renderAppState();
	    automaticArguments();
	  }
	  function automaticArguments() {
	    var entry = currentAction(), source = currentSource(), schema = entry && entry.metadata.parameters || {};
	    var on = schema.properties && schema.properties.on;
	    var automatic = !!(entry && entry.action === 'set_on' && on && on.type === 'boolean' &&
	      $('has-reading').checked && source && $('toggle').value && $('instance').value.indexOf('id:') === 0);
	    argumentFields.forEach(function(argument) {
	      var derived = automatic && ['item','instanceId','on'].indexOf(argument.name) >= 0;
	      argument.automatic = derived; argument.field.parentNode.hidden = derived;
	      argument.field.setAttribute('data-automatic', derived ? 'true' : 'false');
	      argument.field.disabled = derived || !loaded || pending();
	    });
	    $('automatic-args').hidden = !automatic;
	    return automatic;
	  }
	  function renderArguments(args) {
	    var entry = currentAction(), schema = entry && (entry.metadata.parameters || entry.metadata.argsSchema || entry.metadata.inputSchema || entry.metadata.schema) || {};
	    var properties = schema && schema.properties || {}, required = schema.required || [];
	    $('arguments').textContent = ''; argumentFields = [];
	    Object.keys(properties).slice(0, 24).forEach(function(name) {
	      var property = properties[name] || {}, label = node('label', meta(property.title, name) + (required.indexOf(name) >= 0 ? ' *' : ''));
	      var field;
	      if (Array.isArray(property.enum)) { field = node('select'); if (required.indexOf(name) < 0) option(field, '', t('Not set')); property.enum.forEach(function(value) { option(field, JSON.stringify(value), String(value)); }); if (args[name] !== undefined) field.value = JSON.stringify(args[name]); }
	      else if (property.type === 'boolean') { field = node('select'); if (required.indexOf(name) < 0) option(field, '', t('Not set')); option(field, 'true', t('On / true')); option(field, 'false', t('Off / false')); if (args[name] !== undefined) field.value = String(args[name]); }
	      else if (property.type === 'number' || property.type === 'integer') { field = node('input'); field.type = 'number'; field.step = property.type === 'integer' ? '1' : 'any'; if (property.minimum !== undefined) field.min = property.minimum; if (property.maximum !== undefined) field.max = property.maximum; if (args[name] !== undefined) field.value = args[name]; }
	      else if (property.type === 'string' || !property.type) { field = node('input'); field.type = 'text'; if (property.maxLength) field.maxLength = property.maxLength; field.value = args[name] === undefined ? '' : String(args[name]); }
	      else { field = node('textarea'); field.rows = 3; field.value = args[name] === undefined ? '' : JSON.stringify(args[name]); }
	      field.setAttribute('data-edit', ''); field.setAttribute('aria-label', meta(property.title, name));
	      label.appendChild(field); $('arguments').appendChild(label); argumentFields.push({name:name, field:field, schema:property, required:required.indexOf(name) >= 0});
	    });
	    $('args-json').value = JSON.stringify(args, null, 2); $('args-json-wrap').open = !argumentFields.length && Object.keys(args).length > 0;
	    $('arguments-note').textContent = argumentFields.length ? t('Values below are taken from the plugin’s declared action fields.') : t('This action declares no editable fields. Extra arguments can be entered under Advanced arguments.');
	    automaticArguments();
	  }
	  function openEditor(index) {
	    if (!loaded || pending()) return;
	    cancelAppSearch(); appResults = [];
	    var pin = draft.pins[index] || {id:'pin-' + Date.now().toString(36), label:t('New item'), icon:'generic'};
	    editing = {index:index, pin:clone(pin), nameChanged:false, iconChanged:false, app:null}; inspectVersion++;
	    $('pin-label').value = pin.label; $('icon').value = pin.icon || 'generic'; $('has-reading').checked = !!pin.reading;
	    $('source').textContent = ''; $('action').textContent = ''; $('property').textContent = ''; $('instance').textContent = '';
	    $('action-label').value = pin.action && pin.action.label || t('Run'); $('confirm-action').checked = !!(pin.action && pin.action.confirm);
	    $('app-uuid').value = pin.openApp && pin.openApp.watchAppUuid || ''; $('app-label').value = pin.openApp && pin.openApp.label || '';
	    $('app-search-query').value = ''; $('app-status').textContent = ''; $('app-search-panel').open = false; $('app-advanced').open = false;
	    renderAppChoices(pin.openApp ? pin.openApp.watchAppUuid : '');
	    $('editor-error').textContent = ''; $('inspect-status').textContent = '';
	    refreshEditorChoices(); controls(); say(t('Edit this pin, then Save to apply your changes.')); $('editor').scrollIntoView({block:'start', behavior:'auto'});
	  }
	  function gatherArguments() {
	    var args;
	    try { args = JSON.parse($('args-json').value || '{}'); } catch (error) { throw Error(t('Advanced arguments must contain a JSON object.')); }
	    if (!args || typeof args !== 'object' || Array.isArray(args)) throw Error(t('Action arguments must be an object.'));
	    var automatic = automaticArguments();
	    argumentFields.forEach(function(entry) {
	      if (entry.automatic) { delete args[entry.name]; return; }
	      var value = entry.field.value, schema = entry.schema;
	      if (value === '') { if (entry.required) throw Error(t('Enter ') + entry.name + '.'); delete args[entry.name]; return; }
	      if (Array.isArray(schema.enum) || schema.type === 'boolean' || schema.type === 'object' || schema.type === 'array') { try { value = JSON.parse(value); } catch (error) { throw Error(t('Enter a valid value for ') + entry.name + '.'); } }
	      else if (schema.type === 'number' || schema.type === 'integer') { value = Number(value); if (!isFinite(value) || schema.type === 'integer' && value % 1) throw Error(t('Enter a valid number for ') + entry.name + '.'); if (schema.minimum !== undefined && value < schema.minimum || schema.maximum !== undefined && value > schema.maximum) throw Error(entry.name + t(' is outside its allowed range.')); }
	      if (typeof value === 'string' && (schema.minLength && value.length < schema.minLength || schema.maxLength && value.length > schema.maxLength)) throw Error(t('Check the length of ') + entry.name + '.');
	      args[entry.name] = value;
	    });
	    if (automatic) ['item','instanceId','on'].forEach(function(name) { delete args[name]; });
	    return args;
	  }
	  function editedSettings() {
	    var pin = {id:editing.pin.id, label:$('pin-label').value.trim(), icon:$('icon').value};
	    if ($('has-reading').checked) {
	      var source = currentSource(); if (!source || !$('property').value) throw Error(t('Choose a source and reading.'));
	      pin.reading = {category:source.category, item:source.item, property:$('property').value}; if (source.plugin) pin.reading.plugin = source.plugin;
	      var instance = $('instance').value; if (instance.indexOf('id:') === 0) pin.reading.instanceId = instance.slice(3); else pin.reading.index = Number(instance.slice(6));
	    }
	    if ($('action').value === 'builtin:find-phone') pin.builtin = 'find-phone';
	    else if ($('action').value !== 'none') {
	      var action = currentAction(); if (!action) throw Error(t('Choose an available action or keep its saved binding.'));
	      pin.action = {plugin:action.plugin, action:action.action, args:gatherArguments(), label:$('action-label').value.trim(), confirm:$('confirm-action').checked};
	      if ($('toggle').value) { if (!pin.reading) throw Error(t('Choose a reading before binding its on/off state.')); pin.action.toggleProperty = $('toggle').value; }
	    }
	    if ($('app-target').value) pin.openApp = {watchAppUuid:$('app-target').value === '__custom__' ? $('app-uuid').value.trim() : $('app-target').value, label:$('app-label').value.trim()};
	    var next = clone(draft); if (editing.index < next.pins.length) next.pins[editing.index] = pin; else next.pins.push(pin);
	    return model.normalize(next);
	  }
	  function acceptEditor(event) {
	    if (event) event.preventDefault(); if (!editing || pending()) return;
	    try {
	      draft = editedSettings(); cancelAppSearch(); editing = null; inspectVersion++; renderPins(); controls();draftStatus();
	    } catch (error) { $('editor-error').textContent = t(error.message || t('Check this pinned item.')); }
	  }
	  $('editor-form').onsubmit = acceptEditor;
	  function editorDraftChanged(event) {
	    if(!editing||pending()||event&&event.target.id==='app-search-query')return;
	    controls();draftStatus();
	  }
	  $('editor-form').addEventListener('input',editorDraftChanged);
	  $('editor-form').addEventListener('change',editorDraftChanged);
	
	  $('editor-cancel').onclick = function() { cancelAppSearch(); editing = null; inspectVersion++; controls();draftStatus(); };
	  $('add-pin').onclick = function() { openEditor(draft.pins.length); };
	  ['dark','notifications','preview'].forEach(function(id) { $(id).onchange = changed; });
	  $('has-reading').onchange = renderEditorState;
	  $('pin-label').oninput = function() { if (editing) editing.nameChanged = true; };
	  $('icon').onchange = function() { if (editing) editing.iconChanged = true; };
	  $('app-target').onchange = selectApp; $('app-search').onclick = searchApps; $('app-label').oninput = renderAppState;
	  $('app-search-query').onkeydown = function(event) { if (event.key === t('Enter')) { event.preventDefault(); searchApps(); } };
	  $('pin-reading').onclick = function() { $('has-reading').checked = true; renderEditorState(); $('source').onchange(); $('reading-fields').scrollIntoView({block:'center'}); };
	  $('pin-action').onclick = function() { $('action').scrollIntoView({block:'center'}); };
	  $('pin-app').onclick = function() { $('app-target').scrollIntoView({block:'center'}); };
	  $('instance').onchange = automaticArguments; $('toggle').onchange = automaticArguments;
	  $('source').onchange = function() { inspectVersion++; $('instance').value = 'index:0'; refreshProperties(); $('inspect-status').textContent = ''; var source = currentSource(); if (source) suggestName(readingTitle({category:source.category,property:$('property').value,plugin:source.plugin}), source.category === 'weather' ? 'weather' : source.category === 'phone' ? 'phone' : source.category === 'watch-local' ? 'battery' : 'generic'); };
	  $('property').onchange = function() { var source = currentSource(); if (source) suggestName(readingTitle({category:source.category,property:$('property').value,plugin:source.plugin})); };
	  $('action').onchange = function() { var entry = currentAction(); if (entry) { $('action-label').value = apps.label(meta(entry.metadata.label || entry.metadata.title, friendly(entry.action))); suggestName(meta(entry.metadata.label || entry.metadata.title, friendly(entry.action))); } else if ($('action').value === 'builtin:find-phone') suggestName(t('Find phone'), 'find'); $('toggle').value = ''; renderArguments({}); renderEditorState(); };
	  $('inspect-source').onclick = function() {
	    if (legacy || !bridgeReady) { $('inspect-status').textContent = t('Reopen Dashboard settings from the Pebble app to refresh instances.'); return; }
	    var source = currentSource(), version = ++inspectVersion; if (!source || source.category === 'watch-local') return;
	    $('inspect-status').textContent = t('Loading instances…');
	    var requestSource = {category:source.category, item:source.item}; if (source.plugin) requestSource.plugin = source.plugin;
	    request({type:'inspect_source', source:requestSource}, function(response) {
	      if (!editing || inspectVersion !== version || currentSource().key !== source.key) return;
	      if (!response || !response.ok || !Array.isArray(response.instances)) { $('inspect-status').textContent = response && t(response.message) || t('Instances could not be loaded. Saved choices are kept.'); return; }
	      catalogue.instances = (catalogue.instances || []).filter(function(item) { return !(item.category === source.category && item.item === source.item && (!source.plugin || item.plugin === source.plugin)); }).concat(response.instances);
	      renderInstances(); $('inspect-status').textContent = response.instances.length ? t('Instances loaded. Choose the item you want.') : t('No current instances. The saved binding is kept.');
	    }, function() { if (editing && inspectVersion === version) $('inspect-status').textContent = t('Instances could not be loaded. Saved choices are kept.'); }, 'inspect');
	  };
	  $('refresh-catalogue').onclick = refreshCatalogue; $('retry-activities').onclick = refreshCatalogue; $('retry').onclick = load;
	  $('discard').onclick = function() {
	    if (legacy) { location.href = 'pebblejs://close#'; return; }
	    if (uncertain) { load(); return; }
	    apply(JSON.parse(confirmed), repairing);
	  };
	  function saveFailed() { phase = 'ready'; uncertain = true; controls(); say(t('Save not confirmed. Reload saved settings or save again.'), true); }
	  function settingsTarget(complete, failure) {
	    if (typeof Pebble.targets !== 'function') { complete(pkjsReady ? 'pkjs' : 'plugin'); return; }
	    var settled = false, timer = setTimeout(function() { finish(failure); }, 7000);
	    function finish(fn, value) { if (settled) return; settled = true; clearTimeout(timer); fn(value); }
	    try {
	      Promise.resolve(Pebble.targets()).then(function(targets) {
	        if (!Array.isArray(targets)) { finish(failure); return; }
	        finish(complete, targets.some(function(target) { return target && target.id === 'pkjs'; }) ? 'pkjs' : 'plugin');
	      }, function() { finish(failure); });
	    } catch (error) { finish(failure); }
	  }
	  $('save').onclick = function(event) {
	    if (event) event.preventDefault(); if ($('save').disabled) return;
	    var chosen; try { chosen = editing !== null ? editedSettings() : model.normalize(draft); }
	    catch (error) { if (editing !== null) $('editor-error').textContent = t(error.message || t('Check this pinned item.')); say(t('Couldn’t save. Try again.'),true); return; }
	    if (legacy) { location.href = 'pebblejs://close#' + encodeURIComponent(JSON.stringify(chosen)); return; }
	    cancelAppSearch(); inspectVersion++;
	    phase = 'saving'; controls(); say(t('Saving…'));
	    var attempts = 0;
	    function saved(value) {
	      var x=window.scrollX,y=window.scrollY,editorIndex=editing&&editing.index;
	      var editorHadFocus=editing&&$('editor').contains(document.activeElement);
	      apply(value,false);savedHere=true;say(t('✓ Saved'));
	      if(editorHadFocus){var row=$('pins').children[editorIndex],button=row&&row.querySelector('button');if(button)button.focus({preventScroll:true});}
	      if(window.scrollX!==x||window.scrollY!==y)window.scrollTo(x,y);
	    }
	    function write(target) {
	      if (++attempts > 3) { saveFailed(); return; }
	      request({type:'save_settings', settings:chosen}, function(response) {
	        var value;
	        try {
	          if (!response || !response.ok) throw Error();
	          value = model.normalize(response.settings);
	          if (JSON.stringify(value) !== JSON.stringify(chosen)) throw Error();
	        } catch (error) { saveFailed(); return; }
	        // Android PKJS keeps a separate storage snapshot. It must own live
	        // writes, including when it starts during a closed-plugin save.
	        if (target === 'plugin') settingsTarget(function(current) { if (current === 'pkjs') write(current); else saved(value); }, saveFailed);
	        else saved(value);
	      }, function() {
	        if (target !== 'pkjs') { saveFailed(); return; }
	        // Only confirmed shutdown permits the plugin fallback: a still-live
	        // PKJS could later overwrite it with its stale storage snapshot.
	        settingsTarget(function(current) { if (current === 'plugin') write(current); else saveFailed(); }, saveFailed);
	      }, 'settings', target);
	    }
	    settingsTarget(write, saveFailed);
	  };
	  function measureFooter() {
	    var footer = $('actions'), height = footer.getBoundingClientRect().height, viewport = window.visualViewport && window.visualViewport.height || window.innerHeight;
	    var flow = viewport < 560 || height > viewport * 0.3;
	    footer.setAttribute('data-flow', flow ? 'true' : 'false'); document.documentElement.style.setProperty('--footer-space', (flow ? 0 : height) + 'px');
	  }
	  window.addEventListener('resize', measureFooter); if (window.visualViewport) window.visualViewport.addEventListener('resize', measureFooter);
	  if (typeof ResizeObserver !== 'undefined') new ResizeObserver(measureFooter).observe($('actions'));
	  model.icons.forEach(function(icon) { option($('icon'), icon, language.language==='cs'?t(icon):icon.charAt(0).toUpperCase() + icon.slice(1)); });
	  if (legacy) { sourceEntries = collectSources(); actionEntries = collectActions(); try { apply(initial.settings, initial.needsRepair); } catch (error) { loadFailed(); } $('catalogue-status').textContent = catalogue.error || t('Installed sources and saved bindings are shown below.'); }
	  else {
	    draft = model.defaults(); renderActivities(); load();
	    if (typeof Pebble !== 'undefined' && typeof Pebble.addEventListener === 'function') Pebble.addEventListener('ready', function(event) {
	      if (event && event.target === 'pkjs') { pkjsReady = true; if (bridgeReady) refreshCatalogue(); return; }
	      if (event && event.target && event.target !== 'plugin' || bridgeReady) return;
	      bridgeReady = true; clearTimeout(bridgeTimer); bridgeTimer = null; load();
	    });
	  }
	  measureFooter();
	}
	function render(initial) {
	  return [
	    '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dashboard settings</title><style>',
	    ':root{color-scheme:light;--page:#f4f5f7;--card:#fff;--ink:#15181c;--muted:#5d6571;--line:#d9dee6;--field:#f4f5f7;--accent:#076b65;--button:#076b65;--button-ink:#fff;--error:#a32622;--footer-space:130px}',
	    '@media(prefers-color-scheme:dark){:root{color-scheme:dark;--page:#11151b;--card:#1d232d;--ink:#f3f5f7;--muted:#b5bfcc;--line:#465165;--field:#272f3a;--accent:#83d7ca;--button:#83d7ca;--button-ink:#102522;--error:#ffb5ad}}',
	    '*{box-sizing:border-box}html{scroll-padding-bottom:calc(var(--footer-space) + 20px)}body{margin:0;background:var(--page);color:var(--ink);font:16px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}main{max-width:512px;margin:auto;padding:24px 16px calc(var(--footer-space) + 28px)}h1{font-size:28px;line-height:1.2;margin:0 0 10px;letter-spacing:-.5px}header{margin-bottom:24px}header:after{content:"";display:block;width:48px;height:4px;border-radius:2px;background:var(--accent);margin-top:16px}h2{font-size:20px;line-height:1.3;margin:0 0 16px;color:var(--ink)}h3{font-size:17px;margin:16px 0 8px}p{margin:8px 0 16px}header p,.hint{color:var(--muted)}.hint{font-size:14px;overflow-wrap:anywhere}.card{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:16px;margin:24px 0}.card>p:last-child{margin-bottom:0}',
	    'button,input,select,textarea{font:inherit}button,select,input:not([type=checkbox]),textarea{min-height:44px;border:1px solid var(--line);border-radius:8px;background:var(--field);color:var(--ink);padding:10px}button{font-weight:650;cursor:pointer;overflow-wrap:anywhere}button:disabled{opacity:.45;cursor:default}input,select,textarea{width:100%;min-width:0}input[type=checkbox]{width:22px;height:22px;flex:0 0 22px;accent-color:var(--accent)}label{display:block;font-weight:650;margin:16px 0 8px}label input,label select,label textarea{display:block;margin-top:7px}.inline{display:flex;align-items:center;gap:12px;min-height:44px}.inline input{margin:0}.inline span{min-width:0;overflow-wrap:anywhere}.item-title{display:flex;align-items:start;justify-content:space-between;gap:16px}.item-title strong{overflow-wrap:anywhere}.position{color:var(--muted);font-size:14px}.items{list-style:none;margin:0;padding:0}.item{padding:16px 0;border-top:1px solid var(--line)}.item:first-child{border-top:0;padding-top:0}.row-buttons{display:flex;gap:8px;flex-wrap:wrap}.row-buttons button{flex:1;min-width:4.5em;padding-left:6px;padding-right:6px}.row-buttons button:nth-child(2),.row-buttons button:nth-child(3){flex:0 0 2.75em;min-width:2.75em}.activity-item .row-buttons button{flex:0 0 2.75em;min-width:2.75em}.item .hint{margin-bottom:12px}summary{min-height:44px;cursor:pointer;font-weight:650;align-content:center}.error{color:var(--error)}#editor{scroll-margin-top:16px}#editor .card{margin:12px 0}fieldset{border:0;padding:0;margin:0}legend{font-size:16px;font-weight:650;padding:0}button:focus-visible,input:focus-visible,select:focus-visible,textarea:focus-visible,summary:focus-visible{outline:3px solid var(--accent);outline-offset:3px}[hidden]{display:none!important}',
	    'footer{position:fixed;bottom:0;left:0;right:0;padding:12px 16px max(16px,env(safe-area-inset-bottom));background:var(--page);border-top:1px solid var(--line)}footer[data-flow=true]{position:static}.footer-inner{max-width:480px;margin:auto}.status{font-size:14px;min-height:21px;margin:0 0 10px}.actions{display:flex;gap:8px}.actions button{flex:1;min-width:0;overflow-wrap:anywhere}#save,#editor-save{min-height:48px;background:var(--button);color:var(--button-ink);border-color:var(--button)}.editor-actions{display:flex;gap:10px;margin-top:20px}.editor-actions button{flex:1}@media(max-width:340px){main{padding-left:12px;padding-right:12px}.card{padding:16px 12px}.row-buttons{gap:6px}.row-buttons button{padding-left:8px;padding-right:8px}.actions{flex-wrap:wrap}.actions button{min-width:90px}}',
	    '.pin-section{border-top:1px solid var(--line);margin-top:24px;padding-top:20px}.pin-section legend{padding-top:18px;font-size:18px}.pin-section>label:first-of-type{margin-top:8px}.quick-setup{display:flex;gap:8px;flex-wrap:wrap}.quick-setup button{flex:1;min-width:110px}.search-row{display:flex;gap:8px;align-items:end}.search-row label{flex:1;min-width:0}.search-row button{flex:0 0 auto;margin-bottom:8px}.pin-section details{margin-top:12px}#app-selection{margin-bottom:8px}#app-results button{display:block;width:100%;margin:8px 0;text-align:left;overflow-wrap:anywhere}#app-results strong,#app-results span{display:block}@media(max-width:340px){.search-row{display:block}.search-row button{width:100%}}',
	    'button{transition:background-color 144ms ease-out,border-color 144ms ease-out}button:active:not(:disabled){transform:translateY(1px)}details[open]>:not(summary){animation:disclose 160ms ease-out}@keyframes disclose{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}@media(prefers-reduced-motion:reduce){button{transition:none}button:active:not(:disabled){transform:none}details[open]>:not(summary){animation:none}}',
	    '</style></head><body><main><header><h1>Dashboard</h1><p>Choose Dashboard’s pinned items and activity priority.</p></header>',
	    '<section class="card"><h2>On the watch</h2><label>Watch appearance<select id="dark" data-edit><option value="light">Light</option><option value="dark">Dark</option></select></label><label class="inline"><input id="notifications" type="checkbox" data-edit><span>Show latest notification</span></label><label class="inline"><input id="preview" type="checkbox" data-edit><span>Show notification message text</span></label><p class="hint">Message text stays private and is cleared when its source withdraws it. The notification row always opens native Notifications, even without a preview.</p></section>',
	    '<section class="card"><h2>Pinned items</h2><p class="hint">The first two appear on Snapshot. Hold Down there to browse all pins. A pin can show a reading, perform a tap action, or do both.</p><ol id="pins" class="items"></ol><p id="pins-empty" class="hint" hidden>No pinned items yet.</p><button id="add-pin" type="button" data-edit>Add pinned item</button></section>',
	    '<section id="editor" class="card" hidden><h2 id="editor-heading">Pinned item</h2><form id="editor-form"><div id="pin-quick-setup"><p class="hint">Start with what you need. You can combine a reading, a tap action and an app in the same pin.</p><div class="quick-setup"><button id="pin-reading" type="button" data-edit>Show a reading</button><button id="pin-action" type="button" data-edit>Add an action</button><button id="pin-app" type="button" data-edit>Open an app</button></div></div><label>Name on the watch<input id="pin-label" type="text" maxlength="32" autocomplete="off" data-edit></label><details><summary>Change icon</summary><label>Icon<select id="icon" data-edit></select></label></details>',
	    '<fieldset class="pin-section"><legend>Show a reading</legend><label class="inline"><input id="has-reading" type="checkbox" data-edit><span>Show a value on this pin</span></label><div id="reading-fields"><label>From<select id="source" data-edit></select></label><label>Value<select id="property" data-edit></select></label><label>Which item<select id="instance" data-edit></select></label><button id="inspect-source" type="button" data-edit>Refresh items</button><p id="inspect-status" class="hint" role="status"></p></div></fieldset>',
	    '<fieldset class="pin-section"><legend>Tap Select</legend><label>Action<select id="action" data-edit></select></label><div id="action-fields"><p id="arguments-note" class="hint"></p><p id="automatic-args" class="hint" hidden>The selected item and its next on/off state are filled automatically from this reading when you press Select.</p><div id="arguments"></div><label>Use this reading’s on/off state<select id="toggle" data-edit></select></label><p class="hint">Optional: toggle using a real on/off value. Brightness is a separate reading.</p><details><summary>Action options</summary><label>Name on the watch<input id="action-label" type="text" maxlength="32" data-edit></label><label class="inline"><input id="confirm-action" type="checkbox" data-edit><span>Ask before running</span></label><details id="args-json-wrap"><summary>Advanced arguments</summary><p class="hint">Optional extra arguments as a JSON object. The fields above take precedence.</p><label>Arguments<textarea id="args-json" rows="4" spellcheck="false" data-edit>{}</textarea></label></details></details></div></fieldset>',
	    '<fieldset class="pin-section"><legend>Hold Select</legend><label>Open app<select id="app-target" data-edit><option value="">Do nothing</option></select></label><p id="app-selection" class="hint">Hold Select will do nothing.</p><p class="hint">PebbleOS apps need no store search. Some depend on your watch or PebbleOS version.</p><details id="app-search-panel"><summary>Find another app by name</summary><p class="hint">Search the Pebble app store for an app already installed on your watch. Store results do not show what you have installed. Search needs Dashboard’s app-store Internet access in Pebble.</p><div class="search-row"><label>App name<input id="app-search-query" type="search" maxlength="80" autocomplete="off" data-edit></label><button id="app-search" type="button" data-edit>Search</button></div><p id="app-status" class="hint" role="status" aria-live="polite"></p><div id="app-results"></div></details><div id="app-fields" hidden><details id="app-advanced"><summary>App details</summary><label>Name on the watch<input id="app-label" type="text" maxlength="32" data-edit></label><div id="custom-app-fields" hidden><label>Watchapp UUID<input id="app-uuid" type="text" autocomplete="off" spellcheck="false" placeholder="00000000-0000-0000-0000-000000000000" data-edit></label><p class="hint">Only needed for an unlisted custom app. Existing destinations stay saved when offline or unavailable.</p></div></details></div></fieldset>',
	    '<p id="editor-error" class="error" role="alert"></p><div class="editor-actions"><button id="editor-cancel" type="button">Cancel</button><button id="editor-save" type="submit" data-edit>Add pin</button></div></form></section>',
	    '<section class="card"><h2>Activity priority</h2><p class="hint">The highest-priority available activity appears on Snapshot. Hold Up there to browse all activities. Hide a provider to keep its activities out of Dashboard. Dynamic keeps its own order.</p><p id="activities-status" class="hint" role="status" aria-live="polite">Connecting to Pebble…</p><button id="retry-activities" type="button" hidden>Retry activity discovery</button><ol id="activities" class="items"></ol><p id="activities-empty" class="hint">Compatible activity providers appear here after discovery.</p></section>',
	    '<details class="card"><summary>Available plugins &amp; help</summary><p id="catalogue-status" class="hint">Waiting for plugin discovery…</p><button id="refresh-catalogue" type="button">Retry discovery</button><p class="hint">Allow the selected source/action permissions in Pebble. Missing providers keep their saved bindings and appear unavailable; they never switch to a different plugin.</p><p class="hint">The watch shows a button guide once on first use. Tap Select on Music to play or pause; hold Select to open the Music app. Other items use their available action on tap or associated app on hold. On Snapshot, hold Up for Activities or Down for Pinned. Within a list, hold Up/Down to scroll. Timer controls are planned separately.</p></details>',
	    '</main><footer id="actions"><div class="footer-inner"><p id="status" class="status" role="status" aria-live="polite" aria-atomic="true">Loading settings…</p><div class="actions"><button id="retry" type="button" hidden>Retry loading</button><button id="discard" type="button" disabled>Discard</button><button id="save" type="button" disabled>Save</button></div></div></footer><script>(', behavior.toString(), ')(',
	    JSON.stringify(initial).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029'), ',(', model.browserFactory.toString(), '),(', appPicker.browserFactory.toString(), '),(', makeLanguage.toString(), '));</script></body></html>'
	  ].join('\n');
	}
	module.exports = function(settings, catalogue) {
	  var current, needsRepair = false;
	  try { current = model.normalize(settings); } catch (error) { current = model.defaults(); needsRepair = true; }
	  return render({mode:'legacy', settings:current, catalogue:catalogue || {plugins:[], instances:[], activities:[]}, needsRepair:needsRepair});
	};
	module.exports.config = function() { return render({mode:'plugin'}); };


/***/ }),
/* 21 */
/***/ (function(module, exports) {

	'use strict';
	
	// This factory is also embedded verbatim in the bundled and legacy settings pages.
	function createAppPickerModel() {
	  var SEARCH_HOST = 'https://gm3s9tryo4-dsn.algolia.net';
	  var SEARCH_APP = 'GM3S9TRYO4';
	  // Public client-search credential shipped by the official Pebble phone app.
	  var SEARCH_KEY = '0b83b4f8e4e8e9793d2f1f93c21894aa';
	  var UUID = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
	
	  function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
	  function uuid(value) {
	    return typeof value === 'string' && UUID.test(value) &&
	      value !== '00000000-0000-0000-0000-000000000000' ? value.toLowerCase() : '';
	  }
	  function text(value, maxBytes, maxCharacters) {
	    if (typeof value !== 'string') return '';
	    value = value.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
	    var out = '', used = 0, characters = 0;
	    for (var i = 0; i < value.length; i++) {
	      var first = value.charCodeAt(i), part = value.charAt(i), size;
	      if (first >= 0xd800 && first <= 0xdbff) {
	        var second = value.charCodeAt(i + 1);
	        if (!(second >= 0xdc00 && second <= 0xdfff)) continue;
	        part += value.charAt(++i); size = 4;
	      } else if (first >= 0xdc00 && first <= 0xdfff) continue;
	      else size = first < 0x80 ? 1 : first < 0x800 ? 2 : 3;
	      if (used + size > maxBytes || characters >= maxCharacters) break;
	      out += part; used += size; characters++;
	    }
	    return out.trim();
	  }
	  function label(value) { return text(value, 32, 32); }
	  function common() {
	    return [
	      {uuid:'61b22bc8-1e29-460d-a236-3fe409a439ff', name:'Weather', author:'Pebble', icon:'weather', origin:'system'},
	      {uuid:'1f03293d-47af-4f28-b960-f2b02a6dd757', name:'Music', author:'Pebble', icon:'media', origin:'system'},
	      {uuid:'b2cae818-10f8-46df-ad2b-98ad2254a3c1', name:'Notifications', author:'Pebble', icon:'notification', origin:'system'},
	      {uuid:'67a32d95-ef69-46d4-a0b9-854cc62f97f9', name:'Alarms', author:'Pebble', icon:'timer', origin:'system'},
	      {uuid:'fef82c82-7176-4e22-88de-35a3fc18d43f', name:'Workout', author:'Pebble', icon:'workout', origin:'system'},
	      {uuid:'36d8c6ed-4c83-4fa1-a9e2-8f12dc941f8c', name:'Health', author:'Pebble', icon:'workout', origin:'system'},
	      {uuid:'426ccd53-b380-4d83-8d06-9893de3477ce', name:'Timeline', author:'Pebble', icon:'calendar', origin:'system'},
	      {uuid:'07e0d9cb-8957-4bf7-9d42-35bf47caadfe', name:'Settings', author:'Pebble', icon:'generic', origin:'system'},
	      {uuid:'18e443ce-38fd-47c8-84d5-6d0c775fbe55', name:'Watchfaces', author:'Pebble', icon:'generic', origin:'system'},
	      {uuid:'50e9ef12-a5ab-4369-a3b5-3447bfba5151', name:'Timer', author:'Xef', icon:'timer', origin:'common'}
	    ];
	  }
	  function searchUrl(query) {
	    query = text(query, 320, 80);
	    if (!query) throw new Error('Enter an app name to search the store.');
	    return SEARCH_HOST + '/1/indexes/apps?query=' + encodeURIComponent(query) +
	      '&hitsPerPage=15&page=0&tagFilters=' + encodeURIComponent('[["watchapp","companion-app"]]') +
	      '&attributesToRetrieve=' + encodeURIComponent('["id","uuid","title","author","type","compatibility"]') +
	      '&attributesToHighlight=' + encodeURIComponent('[]') + '&attributesToSnippet=' + encodeURIComponent('[]') +
	      '&x-algolia-application-id=' + SEARCH_APP + '&x-algolia-api-key=' + SEARCH_KEY;
	  }
	  function parseResults(body) {
	    if (!object(body) || !Array.isArray(body.hits)) return [];
	    var out = [], seen = Object.create(null);
	    // Requests return at most 15 hits; also bound work for malformed input.
	    var hits = body.hits.slice(0, 100);
	    for (var i = 0; i < hits.length && out.length < 15; i++) {
	      var hit = hits[i];
	      if (!object(hit) || (hit.type !== 'watchapp' && hit.type !== 'companion-app')) continue;
	      var id = uuid(hit.uuid), name = text(hit.title, 128, 128);
	      if (!id || !name || seen[id] || !object(hit.compatibility) ||
	          !object(hit.compatibility.emery) || hit.compatibility.emery.supported !== true) continue;
	      // has_binary:false can mean a compatible scaled Basalt binary, not a plugin.
	      seen[id] = true;
	      out.push({uuid:id, name:name, author:text(hit.author, 96, 96), origin:'store', icon:'generic'});
	    }
	    return out;
	  }
	  return {common:common, label:label, searchUrl:searchUrl, parseResults:parseResults};
	}
	
	module.exports = createAppPickerModel();
	module.exports.browserFactory = createAppPickerModel;


/***/ }),
/* 22 */
/***/ (function(module, exports) {

	'use strict';
	
	// Page-owned interface copy only. Provider names, saved labels and arguments
	// remain source/user text. The factory is embedded in both generated pages.
	function languageFactory(language) {
	  var cs = /^cs(?:-|$)/i.test(language || '');
	  var words = {
	    'Dashboard settings':'Nastavení Dashboardu',
	    'Choose Dashboard’s pinned items and activity priority.':'Vyber připnuté položky a pořadí aktivit Dashboardu.',
	    'On the watch':'Na hodinkách', 'Watch appearance':'Vzhled hodinek', 'Light':'Světlý', 'Dark':'Tmavý',
	    'Show latest notification':'Zobrazovat poslední oznámení', 'Show notification message text':'Zobrazovat text oznámení',
	    'Message text stays private and is cleared when its source withdraws it. The notification row always opens native Notifications, even without a preview.':'Text zprávy zůstává soukromý a zmizí, když ho zdroj přestane poskytovat. Řádek oznámení otevře systémová Oznámení i bez náhledu.',
	    'Pinned items':'Připnuté položky',
	    'The first two appear on Snapshot. Hold Down there to browse all pins. A pin can show a reading, perform a tap action, or do both.':'První dvě položky se zobrazí v přehledu. Podržením dolního tlačítka otevřeš všechny. Položka může zobrazovat hodnotu, provést akci nebo obojí.',
	    'No pinned items yet.':'Zatím nejsou připnuté žádné položky.', 'Add pinned item':'Přidat připnutou položku', 'Pinned item':'Připnutá položka',
	    'Start with what you need. You can combine a reading, a tap action and an app in the same pin.':'Vyber, co potřebuješ. Jedna položka může spojovat hodnotu, akci při stisku a přidruženou aplikaci.',
	    'Show a reading':'Zobrazit hodnotu', 'Add an action':'Přidat akci', 'Open an app':'Otevřít aplikaci',
	    'Name on the watch':'Název na hodinkách', 'Change icon':'Změnit ikonu', 'Icon':'Ikona',
	    'Show a value on this pin':'Zobrazovat u položky hodnotu', 'From':'Zdroj', 'Value':'Hodnota', 'Which item':'Která položka', 'Refresh items':'Obnovit položky',
	    'Tap Select':'Stisk prostředního tlačítka', 'Action':'Akce',
	    'The selected item and its next on/off state are filled automatically from this reading when you press Select.':'Vybraná položka a její příští stav zapnuto/vypnuto se při stisku prostředního tlačítka doplní automaticky z této hodnoty.',
	    'Use this reading’s on/off state':'Použít stav zapnuto/vypnuto z této hodnoty',
	    'Optional: toggle using a real on/off value. Brightness is a separate reading.':'Volitelné: přepínat podle skutečného stavu zapnuto/vypnuto. Jas je samostatná hodnota.',
	    'Action options':'Možnosti akce', 'Ask before running':'Před provedením se zeptat', 'Advanced arguments':'Pokročilé parametry',
	    'Optional extra arguments as a JSON object. The fields above take precedence.':'Volitelné další parametry jako objekt JSON. Pole nahoře mají přednost.', 'Arguments':'Parametry',
	    'Hold Select':'Podržení prostředního tlačítka', 'Open app':'Otevřít aplikaci', 'Do nothing':'Nic nedělat',
	    'Hold Select will do nothing.':'Podržení prostředního tlačítka nic neprovede.',
	    'PebbleOS apps need no store search. Some depend on your watch or PebbleOS version.':'Systémové aplikace PebbleOS není třeba hledat v obchodě. Některé závisí na modelu hodinek nebo verzi PebbleOS.',
	    'Find another app by name':'Najít jinou aplikaci podle názvu',
	    'Search the Pebble app store for an app already installed on your watch. Store results do not show what you have installed. Search needs Dashboard’s app-store Internet access in Pebble.':'Vyhledej v obchodě Pebble aplikaci, kterou už máš na hodinkách. Výsledky neukazují, co máš nainstalované. Dashboard potřebuje v Pebble povolený přístup k internetu pro obchod.',
	    'App name':'Název aplikace', 'Search':'Hledat', 'Search again':'Hledat znovu', 'App details':'Podrobnosti aplikace', 'Watchapp UUID':'UUID aplikace pro hodinky',
	    'Only needed for an unlisted custom app. Existing destinations stay saved when offline or unavailable.':'Potřeba jen pro vlastní aplikaci mimo seznam. Uložené cíle zůstávají zachované i bez připojení nebo při nedostupnosti.',
	    'Cancel':'Zrušit', 'Add pin':'Přidat položku', 'Done':'Hotovo', 'Edit pinned item':'Upravit připnutou položku',
	    'Activity priority':'Pořadí aktivit',
	    'The highest-priority available activity appears on Snapshot. Hold Up there to browse all activities. Hide a provider to keep its activities out of Dashboard. Dynamic keeps its own order.':'V přehledu se zobrazí dostupná aktivita s nejvyšší prioritou. Podržením horního tlačítka otevřeš všechny aktivity. Skrytý poskytovatel se v Dashboardu nezobrazuje. Dynamic má vlastní pořadí.',
	    'Connecting to Pebble…':'Připojování k Pebble…', 'Retry activity discovery':'Znovu načíst aktivity',
	    'Compatible activity providers appear here after discovery.':'Po načtení se zde zobrazí kompatibilní poskytovatelé aktivit.',
	    'Available plugins & help':'Dostupné pluginy a nápověda', 'Waiting for plugin discovery…':'Čekání na seznam pluginů…', 'Retry discovery':'Znovu načíst pluginy',
	    'Allow the selected source/action permissions in Pebble. Missing providers keep their saved bindings and appear unavailable; they never switch to a different plugin.':'Povol v Pebble přístup k vybraným zdrojům a akcím. Nedostupní poskytovatelé si ponechají uložené vazby; nikdy se nenahradí jiným pluginem.',
	    'The watch shows a button guide once on first use. Tap Select on Music to play or pause; hold Select to open the Music app. Other items use their available action on tap or associated app on hold. On Snapshot, hold Up for Activities or Down for Pinned. Within a list, hold Up/Down to scroll. Timer controls are planned separately.':'Při prvním použití hodinky ukážou přehled tlačítek. U hudby prostřední tlačítko přehrává nebo pozastaví; podržení otevře Hudbu. U ostatních položek stisk provede dostupnou akci a podržení otevře přidruženou aplikaci. V přehledu podrž horní tlačítko pro aktivity nebo dolní pro připnuté položky. V seznamu podržení listuje. Ovládání časovače se řeší samostatně.',
	    'Loading settings…':'Načítání nastavení…', 'Retry loading':'Znovu načíst', 'Discard':'Zahodit změny', 'Save':'Uložit', 'Saving…':'Ukládání…', '✓ Saved':'✓ Uloženo',
	    'No changes to save.':'Žádné změny k uložení.', 'Unsaved changes.':'Neuložené změny.', 'Reload saved':'Načíst uložené',
	    'Save not confirmed. Reload saved settings or save again.':'Uložení není potvrzené. Načti uložené nastavení nebo ulož znovu.',
	    'Couldn’t save. Try again.':'Nepodařilo se uložit. Zkus to znovu.',
	    'Saved settings were unreadable. Review these defaults before explicitly saving.':'Uložené nastavení nelze přečíst. Před uložením zkontroluj tyto výchozí hodnoty.',
	    'Could not load saved settings. Retry before editing.':'Uložené nastavení se nepodařilo načíst. Před úpravami ho zkus načíst znovu.',
	    'Pebble did not connect to the settings plugin. Reopen this page from Pebble.':'Pebble se nepřipojilo k pluginu nastavení. Otevři tuto stránku znovu z Pebble.',
	    'Weather':'Počasí', 'Phone':'Telefon', 'Watch battery':'Baterie hodinek', 'Music':'Hudba', 'Reading':'Hodnota',
	    'Tap: Ring phone':'Stisk: prozvonit telefon', 'Tap: ':'Stisk: ', 'Hold: ':'Podržení: ', 'No reading or action configured':'Není nastavená hodnota ani akce',
	    'Edit':'Upravit', 'Remove':'Odebrat', 'Edit ':'Upravit ', 'Remove ':'Odebrat ', 'Move ':'Posunout ', ' up':' nahoru', ' down':' dolů',
	    'Raise priority of ':'Zvýšit prioritu: ', 'Lower priority of ':'Snížit prioritu: ', 'Show activity':'Zobrazovat aktivitu',
	    'Unavailable activity (':'Nedostupná aktivita (',
	    'Connecting to Pebble to discover installed activity providers…':'Připojování k Pebble a načítání poskytovatelů aktivit…',
	    'Loading installed activity providers…':'Načítání poskytovatelů aktivit…',
	    'Could not discover installed activity providers. Music and your saved choices are still shown.':'Poskytovatele aktivit se nepodařilo načíst. Hudba a uložené volby zůstávají zobrazené.',
	    'Saved provider list. Open Dashboard on your watch to refresh installed plugins, then check again.':'Uložený seznam poskytovatelů. Otevři Dashboard na hodinkách pro obnovení pluginů a potom seznam načti znovu.',
	    'Installed activity providers are listed even when no activity is running.':'Poskytovatelé aktivit se zobrazují i tehdy, když žádná aktivita neběží.',
	    'Check again':'Zkontrolovat znovu', 'Loading available plugins…':'Načítání dostupných pluginů…',
	    'Live discovery is unavailable. ':'Živé načtení není dostupné. ',
	    'Open Dashboard on your watch to refresh installed plugins.':'Pro obnovení pluginů otevři Dashboard na hodinkách.',
	    'Saved plugin metadata. Open Dashboard on your watch to refresh installed plugins.':'Uložené údaje o pluginech. Pro jejich obnovení otevři Dashboard na hodinkách.',
	    'Choose from ':'Nainstalované pluginy: ', ' installed plugins. Saved unavailable bindings are kept.':'. Uložené nedostupné vazby zůstanou zachované.',
	    'Available plugins updated. Reopen this item to use the refreshed choices.':'Seznam pluginů byl obnoven. Pro nové možnosti otevři položku znovu.',
	    'Plugin discovery failed. Check plugin access in Pebble, then retry.':'Pluginy se nepodařilo načíst. Zkontroluj přístup v Pebble a zkus to znovu.',
	    ' Your saved items are kept.':' Uložené položky zůstávají zachované.',
	    'Temperature':'Teplota', 'Humidity':'Vlhkost', 'High':'Maximum', 'Low':'Minimum', 'Conditions':'Podmínky', 'Sunrise':'Východ slunce', 'Sunset':'Západ slunce',
	    'Battery':'Baterie', 'Level':'Úroveň', 'Charging':'Nabíjení', 'Brightness':'Jas', 'On / off':'Zapnuto / vypnuto', 'Name':'Název',
	    'Phone · ':'Telefon · ', 'Weather · ':'Počasí · ', 'New item':'Nová položka', 'Saved app':'Uložená aplikace',
	    'PebbleOS apps':'Aplikace PebbleOS', 'Other apps':'Ostatní aplikace', 'Your saved apps':'Uložené aplikace', 'Store search results':'Výsledky hledání v obchodě', 'Custom app…':'Vlastní aplikace…',
	    'Choose ':'Vybrat ', ' by ':' od ', 'Enter the details for an unlisted app below.':'Níže zadej údaje pro aplikaci mimo seznam.',
	    'Hold Select opens ':'Podržení prostředního tlačítka otevře ', 'the selected app':'vybranou aplikaci',
	    'Enter an app name.':'Zadej název aplikace.', 'Searching the Pebble app store…':'Hledání v obchodě Pebble…',
	    'Could not search the app store. Check your connection and Dashboard’s app-store Internet access in Pebble. After changing access, finish and save any edits, then reopen these settings. Your selected app is kept.':'Obchod se nepodařilo prohledat. Zkontroluj připojení a internetový přístup Dashboardu v Pebble. Po změně přístupu dokonči a ulož úpravy, potom nastavení otevři znovu. Vybraná aplikace zůstává zachovaná.',
	    'Choose an app below. It must already be installed on your watch.':'Níže vyber aplikaci. Musí už být nainstalovaná na hodinkách.',
	    'No compatible apps found. Try another name, or use Custom app for an unlisted app.':'Nebyla nalezena kompatibilní aplikace. Zkus jiný název nebo vlastní aplikaci mimo seznam.',
	    'Saved source · unavailable':'Uložený zdroj · nedostupný', 'Saved action · unavailable':'Uložená akce · nedostupná',
	    'None':'Žádná', 'Ring phone':'Prozvonit telefon', 'First available item':'První dostupná položka', 'Configured item':'Nastavená položka',
	    'Not set':'Nenastaveno', 'On / true':'Zapnuto / true', 'Off / false':'Vypnuto / false',
	    'Values below are taken from the plugin’s declared action fields.':'Hodnoty níže odpovídají polím akce, která deklaruje plugin.',
	    'This action declares no editable fields. Extra arguments can be entered under Advanced arguments.':'Tato akce nemá deklarovaná upravitelná pole. Další parametry lze zadat v pokročilých parametrech.',
	    'Run':'Provést', 'Edit this pin, then Save to apply your changes.':'Uprav položku a potom změny ulož.',
	    'Advanced arguments must contain a JSON object.':'Pokročilé parametry musí obsahovat objekt JSON.', 'Action arguments must be an object.':'Parametry akce musí být objekt.',
	    'Enter ':'Zadej ', 'Enter a valid value for ':'Zadej platnou hodnotu pro ', 'Enter a valid number for ':'Zadej platné číslo pro ',
	    ' is outside its allowed range.':' je mimo povolený rozsah.', 'Check the length of ':'Zkontroluj délku pole ',
	    'Choose a source and reading.':'Vyber zdroj a hodnotu.', 'Choose an available action or keep its saved binding.':'Vyber dostupnou akci nebo ponech uloženou vazbu.',
	    'Choose a reading before binding its on/off state.':'Před přiřazením stavu zapnuto/vypnuto vyber hodnotu.',
	    'Pinned item updated. Save to apply your changes.':'Položka byla upravena. Pro použití změny ulož.', 'Check this pinned item.':'Zkontroluj tuto položku.',
	    'Find phone':'Najít telefon', 'Reopen Dashboard settings from the Pebble app to refresh instances.':'Pro obnovení položek otevři nastavení Dashboardu znovu z aplikace Pebble.',
	    'Loading instances…':'Načítání položek…', 'Instances could not be loaded. Saved choices are kept.':'Položky se nepodařilo načíst. Uložené volby zůstávají zachované.',
	    'Instances loaded. Choose the item you want.':'Položky jsou načtené. Vyber tu, kterou chceš.', 'No current instances. The saved binding is kept.':'Žádné aktuální položky. Uložená vazba zůstává zachovaná.',
	    'Installed sources and saved bindings are shown below.':'Níže jsou nainstalované zdroje a uložené vazby.',
	    'No tap action':'Žádná akce při stisku', 'Find phone · Ring':'Najít telefon · prozvonit', ' (saved)':' (uloženo)',
	    'Use the entered action arguments':'Použít zadané parametry akce', 'Toggle using ':'Přepínat podle ', ' (saved on/off property)':' (uložený stav zapnuto/vypnuto)',
	    'First instance (source order)':'První položka (pořadí zdroje)', 'Source position ':'Pozice ve zdroji ', ' (saved instance)':' (uložená položka)', 'Enter':'Zadej',
	    'Open Dashboard on your watch once to discover installed activity providers.':'Pro načtení poskytovatelů aktivit jednou otevři Dashboard na hodinkách.',
	    'Saved provider list. Open Dashboard on your watch to refresh available plugins.':'Uložený seznam poskytovatelů. Pro jeho obnovení otevři Dashboard na hodinkách.',
	    'Could not read installed plugins. Retry discovery.':'Pluginy se nepodařilo načíst. Zkus to znovu.',
	    'Source inspection is unavailable. You can keep the configured instance.':'Načtení zdroje není dostupné. Nastavenou položku můžeš ponechat.',
	    'Could not read instances. Check source permissions in Pebble.':'Položky se nepodařilo načíst. Zkontroluj oprávnění zdroje v Pebble.',
	    'Could not read source instances.':'Položky zdroje se nepodařilo načíst.',
	    "Invalid Dashboard settings.":"Neplatné nastavení Dashboardu.",
	    "Unknown settings field.":"Neznámé pole nastavení.",
	    "Invalid plugin or watchapp UUID.":"Neplatné UUID pluginu nebo aplikace.",
	    "Action arguments are too deeply nested.":"Parametry akce jsou příliš hluboko vnořené.",
	    "Invalid action argument text.":"Neplatný text parametru akce.",
	    "Too many action argument values.":"Příliš mnoho hodnot parametrů akce.",
	    "Action arguments must contain JSON values.":"Parametry akce musí obsahovat hodnoty JSON.",
	    "Invalid action argument name.":"Neplatný název parametru akce.",
	    "Invalid source index.":"Neplatná pozice ve zdroji.",
	    "Action arguments exceed 2048 bytes.":"Parametry akce překračují 2048 bajtů.",
	    "Unknown pin icon.":"Neznámá ikona položky.",
	    "Unknown built-in pin.":"Neznámá vestavěná položka.",
	    "Choose either the built-in action or a custom action.":"Vyber buď vestavěnou, nebo vlastní akci.",
	    "Invalid Dashboard settings version or pin count.":"Neplatná verze nastavení nebo počet položek.",
	    "Duplicate pin ID.":"Duplicitní hodnota: ID položky.",
	    "Dashboard settings exceed 32 KiB.":"Nastavení překračuje 32 KiB.",
	    "Settings could not be confirmed.":"Nastavení se nepodařilo potvrdit.",
	    "Invalid source category.":"Neplatná hodnota: kategorie zdroje.",
	    "Duplicate source category.":"Duplicitní hodnota: kategorie zdroje.",
	    "Too many source category.":"Příliš mnoho hodnot: kategorie zdroje.",
	    "Invalid source item.":"Neplatná hodnota: položka zdroje.",
	    "Duplicate source item.":"Duplicitní hodnota: položka zdroje.",
	    "Too many source item.":"Příliš mnoho hodnot: položka zdroje.",
	    "Invalid reading property.":"Neplatná hodnota: vlastnost hodnoty.",
	    "Duplicate reading property.":"Duplicitní hodnota: vlastnost hodnoty.",
	    "Too many reading property.":"Příliš mnoho hodnot: vlastnost hodnoty.",
	    "Invalid source instance.":"Neplatná hodnota: instance zdroje.",
	    "Duplicate source instance.":"Duplicitní hodnota: instance zdroje.",
	    "Too many source instance.":"Příliš mnoho hodnot: instance zdroje.",
	    "Invalid action name.":"Neplatná hodnota: název akce.",
	    "Duplicate action name.":"Duplicitní hodnota: název akce.",
	    "Too many action name.":"Příliš mnoho hodnot: název akce.",
	    "Invalid action label.":"Neplatná hodnota: název akce na hodinkách.",
	    "Duplicate action label.":"Duplicitní hodnota: název akce na hodinkách.",
	    "Too many action label.":"Příliš mnoho hodnot: název akce na hodinkách.",
	    "Invalid action confirmation.":"Neplatná hodnota: potvrzení akce.",
	    "Duplicate action confirmation.":"Duplicitní hodnota: potvrzení akce.",
	    "Too many action confirmation.":"Příliš mnoho hodnot: potvrzení akce.",
	    "Invalid Boolean toggle property.":"Neplatná hodnota: stav přepínače.",
	    "Duplicate Boolean toggle property.":"Duplicitní hodnota: stav přepínače.",
	    "Too many Boolean toggle property.":"Příliš mnoho hodnot: stav přepínače.",
	    "Invalid pin ID.":"Neplatná hodnota: ID položky.",
	    "Too many pin ID.":"Příliš mnoho hodnot: ID položky.",
	    "Invalid pin name.":"Neplatná hodnota: název položky.",
	    "Duplicate pin name.":"Duplicitní hodnota: název položky.",
	    "Too many pin name.":"Příliš mnoho hodnot: název položky.",
	    "Invalid app label.":"Neplatná hodnota: název aplikace.",
	    "Duplicate app label.":"Duplicitní hodnota: název aplikace.",
	    "Too many app label.":"Příliš mnoho hodnot: název aplikace.",
	    "Invalid watch theme.":"Neplatná hodnota: vzhled hodinek.",
	    "Duplicate watch theme.":"Duplicitní hodnota: vzhled hodinek.",
	    "Too many watch theme.":"Příliš mnoho hodnot: vzhled hodinek.",
	    "Invalid notification preview.":"Neplatná hodnota: náhled oznámení.",
	    "Duplicate notification preview.":"Duplicitní hodnota: náhled oznámení.",
	    "Too many notification preview.":"Příliš mnoho hodnot: náhled oznámení.",
	    "Invalid notification visibility.":"Neplatná hodnota: zobrazení oznámení.",
	    "Duplicate notification visibility.":"Duplicitní hodnota: zobrazení oznámení.",
	    "Too many notification visibility.":"Příliš mnoho hodnot: zobrazení oznámení.",
	    "Invalid activity priority.":"Neplatná hodnota: pořadí aktivit.",
	    "Duplicate activity priority.":"Duplicitní hodnota: pořadí aktivit.",
	    "Too many activity priority.":"Příliš mnoho hodnot: pořadí aktivit.",
	    "Invalid hidden activities.":"Neplatná hodnota: skryté aktivity.",
	    "Duplicate hidden activities.":"Duplicitní hodnota: skryté aktivity.",
	    "Too many hidden activities.":"Příliš mnoho hodnot: skryté aktivity.",
	    'generic':'Obecná', 'timer':'Časovač', 'media':'Média', 'notification':'Oznámení', 'weather':'Počasí', 'phone':'Telefon', 'light':'Světlo', 'find':'Hledání', 'workout':'Cvičení', 'navigation':'Navigace', 'calendar':'Kalendář', 'battery':'Baterie', 'scene':'Scéna'
	  };
	  function text(value) { return cs && Object.prototype.hasOwnProperty.call(words,value) ? words[value] : value; }
	  function staticPage(root) {
	    if (!cs) return;
	    document.documentElement.lang = 'cs'; document.title = text(document.title);
	    var walker = document.createTreeWalker(root,4), item;
	    while ((item=walker.nextNode())) {
	      if (/^(SCRIPT|STYLE|TEXTAREA)$/.test(item.parentNode.tagName)) continue;
	      var raw=item.nodeValue, trimmed=raw.trim();
	      if (Object.prototype.hasOwnProperty.call(words,trimmed)) item.nodeValue=raw.slice(0,raw.indexOf(trimmed))+words[trimmed]+raw.slice(raw.indexOf(trimmed)+trimmed.length);
	    }
	  }
	  return {language:cs?'cs':'en', text:text, staticPage:staticPage};
	}
	module.exports = languageFactory;


/***/ })
/******/ ]);
//# sourceMappingURL=pebble-js-app.js.map