'use strict';
// Dashboard config-only sources; see bundled LICENSE.
(function(modules){var cache={};function load(id){if(cache[id])return cache[id].exports;var module={exports:{}};cache[id]=module;modules[id](module,module.exports,load);return module.exports;}load(0);})([
function(module,exports,require){
'use strict';

var settings = require(1);
var metadata = require(2);
function safeText(value, max) { return typeof value === 'string' ? value.replace(/[\u0000-\u001f]/g, '').slice(0, max || 128) : ''; }
function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function uuid(value) { return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value); }
function catalogue(plugins) {
  return metadata.fromPlugins(plugins);
}
function instanceName(instance) {
  var property = instance && instance.properties && instance.properties.name;
  return safeText(property && (property.shortText && property.shortText.text || property.longText && property.longText.text) || instance && instance.instanceId, 96);
}
function register(pebble, storage) {
  pebble.registerConfigHandler(function(message, respond) {
    message = message || {};
    var type = message.type;
    if (!type || type === 'load_settings' || type === 'getSettings') {
      var loaded = settings.load(storage);
      respond({ok:true, settings:loaded || settings.defaults(), needsRepair:!loaded});
    } else if (type === 'save_settings' || type === 'saveSettings') {
      try { respond({ok:true, settings:settings.save(storage, message.settings)}); }
      catch (error) { respond({ok:false, message:safeText(error && error.message || 'Settings were not saved.', 160)}); }
    } else if (type === 'catalogue') {
      var saved=metadata.load(storage);
      respond({ok:true,catalogue:saved||catalogue([]),cached:true,
        message:saved?'Saved provider list. Open Dashboard on your watch to refresh available plugins.':'Open Dashboard on your watch once to discover installed activity providers.'});
    } else if (type === 'inspect_source') {
      var source = message.source;
      if (!object(source) || typeof source.category !== 'string' || typeof source.item !== 'string' ||
          source.category.length > 64 || source.item.length > 64 || source.plugin !== undefined && !uuid(source.plugin) ||
          source.category === 'phone' && source.item === 'find_my_phone') {
        respond({ok:false, message:'This source cannot be inspected. Find phone is an action, not a reading.'}); return;
      }
      if (typeof pebble.readSource !== 'function') { respond({ok:false, message:'Source inspection is unavailable. You can keep the configured instance.'}); return; }
      try {
        var request = {category:source.category, item:source.item, properties:['name']};
        if (source.plugin) request.plugin = source.plugin;
        Promise.resolve(pebble.readSource(request)).then(function(envelope) {
          if (!envelope || !Array.isArray(envelope.instances) || !uuid(envelope.pluginUuid) || source.plugin && source.plugin.toLowerCase() !== envelope.pluginUuid.toLowerCase()) {
            respond({ok:false, message:'Source data is unavailable or came from a different plugin.'}); return;
          }
          respond({ok:true, instances:envelope.instances.slice(0, 128).filter(function(instance) { return instance && typeof instance.instanceId === 'string' && instance.instanceId.length <= 128 && !/[\u0000-\u001f]/.test(instance.instanceId); }).map(function(instance) {
            return {plugin:envelope.pluginUuid, category:source.category, item:source.item, instanceId:instance.instanceId, name:instanceName(instance), properties:Object.keys(instance.properties || {}).slice(0, 128)};
          })});
        }, function() { respond({ok:false, message:'Could not read instances. Check source permissions in Pebble.'}); });
      } catch (error) { respond({ok:false, message:'Could not read source instances.'}); }
    } else respond({ok:false, message:'Unknown settings request.'});
  });
}
if (typeof Pebble !== 'undefined') register(Pebble, localStorage);
module.exports = {register:register, catalogue:catalogue};

},
function(module,exports,require){
'use strict';

function createModel() {
var KEY = 'dashboard.settings.v1';
var ICONS = ['generic','timer','media','notification','weather','phone','light','find','workout','navigation','calendar','battery','scene'];
var UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function bytes(value) { return encodeURIComponent(value).replace(/%[0-9a-f]{2}|./gi, 'x').length; }
function invalid(message) { throw new Error(message || 'Invalid Dashboard settings.'); }
function known(value, names) {
  if (!object(value) || Object.keys(value).some(function(name) { return names.indexOf(name) < 0; })) invalid('Unknown settings field.');
}
function string(value, length, label) {
  if (typeof value !== 'string' || !value.length || /[\u0000-\u001f\u007f]/.test(value) || bytes(value) > length) invalid('Invalid ' + label + '.');
  return value;
}
function uuid(value) {
  if (typeof value !== 'string' || !UUID.test(value) || /^0{8}-0{4}-0{4}-0{4}-0{12}$/.test(value)) invalid('Invalid plugin or watchapp UUID.');
  return value.toLowerCase();
}
function identifier(value, label) {
  value = string(value, 64, label);
  if (!/^[a-zA-Z0-9_.:/-]+$/.test(value)) invalid('Invalid ' + label + '.');
  return value;
}
function boolean(value, fallback, label) {
  if (value === undefined) return fallback;
  if (typeof value !== 'boolean') invalid('Invalid ' + label + '.');
  return value;
}
function json(value, depth) {
  if (depth > 6) invalid('Action arguments are too deeply nested.');
  if (value === null || typeof value === 'boolean' || typeof value === 'string') {
    if (typeof value === 'string' && /[\u0000]/.test(value)) invalid('Invalid action argument text.');
    return value;
  }
  if (typeof value === 'number' && isFinite(value)) return value;
  if (Array.isArray(value)) {
    if (value.length > 64) invalid('Too many action argument values.');
    return value.map(function(entry) { return json(entry, depth + 1); });
  }
  if (!object(value)) invalid('Action arguments must contain JSON values.');
  var result = {};
  Object.keys(value).forEach(function(name) {
    if (name === '__proto__' || name === 'prototype' || name === 'constructor' || bytes(name) > 64) invalid('Invalid action argument name.');
    result[name] = json(value[name], depth + 1);
  });
  return result;
}
function reading(value) {
  known(value, ['plugin','category','item','property','instanceId','index']);
  var out = {category:identifier(value.category, 'source category'), item:identifier(value.item, 'source item'), property:identifier(value.property, 'reading property')};
  if (value.plugin !== undefined) out.plugin = uuid(value.plugin);
  if (value.instanceId !== undefined) out.instanceId = string(value.instanceId, 128, 'source instance');
  if (value.index !== undefined) {
    if (typeof value.index !== 'number' || value.index % 1 || value.index < 0 || value.index > 4095) invalid('Invalid source index.');
    out.index = value.index;
  }
  return out;
}
function action(value) {
  known(value, ['plugin','action','args','label','confirm','toggleProperty']);
  var out = {plugin:uuid(value.plugin), action:identifier(value.action, 'action name'), label:string(value.label, 32, 'action label')};
  if (value.args !== undefined) {
    if (!object(value.args)) invalid('Action arguments must be an object.');
    out.args = json(value.args, 0);
    if (bytes(JSON.stringify(out.args)) > 2048) invalid('Action arguments exceed 2048 bytes.');
  }
  if (value.confirm !== undefined) out.confirm = boolean(value.confirm, false, 'action confirmation');
  if (value.toggleProperty !== undefined) out.toggleProperty = identifier(value.toggleProperty, 'Boolean toggle property');
  return out;
}
function pin(value) {
  known(value, ['id','label','icon','builtin','reading','action','openApp']);
  var out = {id:string(value.id, 64, 'pin ID'), label:string(value.label, 32, 'pin name')};
  if (value.icon !== undefined) {
    if (ICONS.indexOf(value.icon) < 0) invalid('Unknown pin icon.');
    out.icon = value.icon;
  }
  if (value.builtin !== undefined) {
    if (value.builtin !== 'find-phone') invalid('Unknown built-in pin.');
    out.builtin = value.builtin;
  }
  if (value.reading !== undefined) out.reading = reading(value.reading);
  if (value.action !== undefined) out.action = action(value.action);
  if (out.builtin && out.action) invalid('Choose either the built-in action or a custom action.');
  if (value.openApp !== undefined) {
    known(value.openApp, ['watchAppUuid','label']);
    out.openApp = {watchAppUuid:uuid(value.openApp.watchAppUuid), label:string(value.openApp.label, 32, 'app label')};
  }
  return out;
}
function strings(value, label) {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > 128) invalid('Too many ' + label + '.');
  var seen = Object.create(null);
  return value.map(function(entry) {
    entry = string(entry, 192, label);
    if (seen[entry]) invalid('Duplicate ' + label + '.');
    seen[entry] = true; return entry;
  });
}
function defaults() {
  return {version:1, dark:false, notificationPreview:false, showNotifications:true,
    activityOrder:[], disabledActivities:[], pins:[
      {id:'weather', label:'Weather', icon:'weather', reading:{category:'weather', item:'location', property:'temperature', index:0}},
      {id:'phone', label:'Phone', icon:'phone', reading:{category:'phone', item:'phone_state', property:'battery_level', index:0}},
      {id:'watch-battery', label:'Watch', icon:'battery', reading:{category:'watch-local', item:'battery', property:'level'}},
      {id:'find-phone', label:'Find phone', icon:'find', builtin:'find-phone'}
    ]};
}
function normalize(value) {
  known(value, ['version','dark','notificationPreview','showNotifications','activityOrder','disabledActivities','pins']);
  if (value.version !== 1 || !Array.isArray(value.pins) || value.pins.length > 64) invalid('Invalid Dashboard settings version or pin count.');
  var seen = Object.create(null), out = {version:1,
    dark:boolean(value.dark, false, 'watch theme'),
    notificationPreview:boolean(value.notificationPreview, false, 'notification preview'),
    showNotifications:boolean(value.showNotifications, true, 'notification visibility'),
    activityOrder:strings(value.activityOrder, 'activity priority entries'),
    disabledActivities:strings(value.disabledActivities, 'hidden activity entries'),
    pins:value.pins.map(function(entry) {
      var item = pin(entry); if (seen[item.id]) invalid('Duplicate pin ID.'); seen[item.id] = true; return item;
    })};
  if (bytes(JSON.stringify(out)) > 32768) invalid('Dashboard settings exceed 32 KiB.');
  return out;
}
function load(storage) {
  try {
    var encoded = storage.getItem(KEY);
    return encoded === null || encoded === undefined ? defaults() : normalize(JSON.parse(encoded));
  } catch (error) { return null; }
}
function save(storage, value) {
  var out = normalize(value), encoded = JSON.stringify(out);
  storage.setItem(KEY, encoded);
  if (storage.getItem(KEY) !== encoded) invalid('Settings could not be confirmed.');
  return out;
}
return {key:KEY, icons:ICONS, defaults:defaults, normalize:normalize, load:load, save:save};
}
module.exports = createModel();
module.exports.browserFactory = createModel;

},
function(module,exports,require){
'use strict';

// Installed plugin declarations are public metadata. Never cache a source
// envelope, live instance, activity/card, observation or invocation arguments.
// This module is also bundled into plugin.js, whose SDK cannot enumerate peers.
var KEY='dashboard.catalogue.v1',MAX_BYTES=262144;
function object(value){return !!value&&typeof value==='object'&&!Array.isArray(value);}
function uuid(value){return typeof value==='string'&&/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(value)&&value!=='00000000-0000-0000-0000-000000000000';}
function text(value,limit){return typeof value==='string'?value.replace(/[\u0000-\u001f\u007f-\u009f]/g,' ').trim().slice(0,limit):'';}
function bytes(value){var size=0;for(var i=0;i<value.length;i++){var c=value.charCodeAt(i);if(c<128)size++;else if(c<2048)size+=2;else if(c>=55296&&c<=56319&&i+1<value.length&&value.charCodeAt(i+1)>=56320&&value.charCodeAt(i+1)<=57343){size+=4;i++;}else size+=3;}return size;}
function key(value,limit){return typeof value==='string'&&value.length>0&&value.length<=limit&&!/[\u0000-\u001f\u007f-\u009f]/.test(value)&&['__proto__','prototype','constructor'].indexOf(value)<0;}
function names(value,limit,count){return Array.isArray(value)?value.filter(function(v){return key(v,limit);}).slice(0,count):[];}
function spend(budget,value){budget.nodes++;budget.bytes+=typeof value==='string'?bytes(value):16;if(budget.nodes>1024||budget.bytes>16384)throw Error('Schema metadata is too large.');}
function schema(input,depth,budget){
  if(!object(input)||depth>6)throw Error('Schema metadata is too deep.');
  spend(budget,64);
  var out={};
  ['type','title','description'].forEach(function(name){if(typeof input[name]==='string'){out[name]=text(input[name],name==='description'?384:128);spend(budget,out[name]);}});
  ['minimum','maximum','minLength','maxLength','minItems','maxItems'].forEach(function(name){if(typeof input[name]==='number'&&isFinite(input[name]))out[name]=input[name];});
  if(typeof input.additionalProperties==='boolean')out.additionalProperties=input.additionalProperties;
  if(Array.isArray(input.required)){
    if(input.required.length>128||input.required.some(function(name){return !key(name,64);}))throw Error('Schema requirements are too large.');
    out.required=input.required.slice();out.required.forEach(function(name){spend(budget,name);});
  }
  if(Array.isArray(input.enum)){
    if(input.enum.length>64||input.enum.some(function(v){return !(v===null||typeof v==='boolean'||typeof v==='number'&&isFinite(v)||typeof v==='string'&&v.length<=256);}))throw Error('Schema choices are too large.');
    out.enum=input.enum.slice();out.enum.forEach(function(v){spend(budget,v);});
  }
  if(object(input.properties)){
    var fields=Object.keys(input.properties);if(fields.length>128||fields.some(function(name){return !key(name,64);}))throw Error('Schema fields are too large.');
    out.properties={};fields.forEach(function(name){spend(budget,name);out.properties[name]=schema(input.properties[name],depth+1,budget);});
  }
  if(object(input.items))out.items=schema(input.items,depth+1,budget);
  return out;
}
function source(input){
  if(!object(input)||!key(input.category,64))return null;
  var out={category:input.category,items:names(input.items,64,64),properties:{}};
  if(!out.items.length)return null;
  if(object(input.properties))Object.keys(input.properties).filter(function(name){return key(name,64);}).slice(0,128).forEach(function(name){out.properties[name]=names(input.properties[name],64,16);});
  if(typeof input.supportsMultiple==='boolean')out.supportsMultiple=input.supportsMultiple;
  return out;
}
function action(input){
  if(!object(input)||!key(input.name,64))return null;
  var out={name:input.name};
  if(typeof input.description==='string')out.description=text(input.description,384);
  if(object(input.parameters)){try{out.parameters=schema(input.parameters,0,{nodes:0,bytes:0});}catch(ignored){return null;}if(bytes(JSON.stringify(out.parameters))>16384)return null;}
  if(Array.isArray(input.targets))out.targets=names(input.targets,192,64);
  if(typeof input.destructive==='boolean')out.destructive=input.destructive;
  if(typeof input.requiresConfirmation==='boolean')out.requiresConfirmation=input.requiresConfirmation;
  return out;
}
function activitySource(value){
  // Matches pebble-activities 0.4.4 consumer.sourceItem(plugin, 3), without
  // starting that consumer or requiring npm modules in the config-only bundle.
  return value.category==='activity'&&Array.isArray(value.properties.schema_version)&&value.properties.schema_version.indexOf('numericValue')>=0&&
    value.items.some(function(item){return ['summary','live','card','session'].indexOf(item)>=0;});
}
function fromPlugins(input){
  if(!Array.isArray(input))throw Error('Plugin catalogue is invalid.');
  var seen=Object.create(null),plugins=[];
  input.slice(0,128).forEach(function(value){
    if(!object(value)||!uuid(value.uuid)||seen[value.uuid.toLowerCase()])return;
    seen[value.uuid.toLowerCase()]=true;
    plugins.push({uuid:value.uuid,name:text(value.name||value.displayName,96)||value.uuid,
      sources:(Array.isArray(value.sources)?value.sources:[]).slice(0,64).map(source).filter(Boolean),
      actions:(Array.isArray(value.actions)?value.actions:[]).slice(0,64).map(action).filter(Boolean)});
  });
  return {plugins:plugins,instances:[],activities:plugins.filter(function(plugin){return plugin.sources.some(activitySource);}).map(function(plugin){return {key:plugin.uuid,name:plugin.name};}).concat([{key:'builtin:music',name:'Music'}])};
}
function save(storage,catalogue){
  if(!storage||typeof storage.setItem!=='function')return false;
  var clean=fromPlugins(catalogue.plugins),value=JSON.stringify({version:1,plugins:clean.plugins});
  // Large declarations keep a bounded provider list, without caching truncated
  // action schemas that could misrepresent their required arguments.
  if(bytes(value)>MAX_BYTES){
    clean.plugins=clean.plugins.map(function(plugin){return {uuid:plugin.uuid,name:plugin.name,actions:[],sources:plugin.sources.filter(activitySource).slice(0,1).map(function(declaration){return {category:'activity',items:declaration.items.filter(function(item){return ['summary','live','card','session'].indexOf(item)>=0;}).slice(0,4),properties:{schema_version:['numericValue']}};})};});
    value=JSON.stringify({version:1,plugins:clean.plugins});
  }
  if(bytes(value)>MAX_BYTES)return false;
  try{if(typeof storage.getItem==='function'&&storage.getItem(KEY)===value)return true;storage.setItem(KEY,value);return true;}catch(ignored){return false;}
}
function load(storage){
  try{
    var value=storage&&storage.getItem(KEY);if(typeof value!=='string'||bytes(value)>MAX_BYTES)return null;
    var decoded=JSON.parse(value);if(!object(decoded)||decoded.version!==1||!Array.isArray(decoded.plugins)||decoded.plugins.length>128)return null;
    return fromPlugins(decoded.plugins);
  }catch(ignored){return null;}
}
function discover(pebble,storage){
  if(!pebble||typeof pebble.enumeratePlugins!=='function')return Promise.reject(Error('Installed plugin discovery is unavailable in this phone runtime.'));
  try{return Promise.resolve(pebble.enumeratePlugins()).then(function(plugins){var catalogue=fromPlugins(plugins);save(storage,catalogue);return catalogue;});}
  catch(error){return Promise.reject(error);}
}
module.exports={fromPlugins:fromPlugins,discover:discover,load:load,save:save,key:KEY,limit:MAX_BYTES};

}
]);
