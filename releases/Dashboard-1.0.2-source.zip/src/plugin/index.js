'use strict';

var settings = require('../pkjs/settings');
var metadata = require('../pkjs/catalogue');
var preferences=require('../pkjs/ui-preferences');
function safeText(value, max) { return typeof value === 'string' ? value.replace(/[\u0000-\u001f]/g, '').slice(0, max || 128) : ''; }
function object(value) { return !!value && typeof value === 'object' && !Array.isArray(value); }
function uuid(value) { return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value); }
function catalogue(plugins) {
  return metadata.fromPlugins(plugins);
}
function instanceName(instance) {
  var property = instance && instance.properties && instance.properties.name;
  return safeText(property && (property.shortText && property.shortText.text || property.longText && property.longText.text) || instance && instance.instanceId, 96);
}
function register(pebble, storage) {
  var ui=preferences.create({storage:storage});
  function uiResponse(message){var result;ui.handle(message,function(value){result=value;});return result;}
  pebble.registerConfigHandler(function(message, respond) {
    if(typeof message==='string'){try{message=JSON.parse(message);}catch(error){respond({ok:false});return;}}
    message = message || {};
    if(preferences.isRequest(message)){ui.handle(message,respond);return;}
    var type = message.type;
    if (!type || type === 'load_settings' || type === 'getSettings') {
      var loaded = settings.load(storage);
      var response={ok:true,settings:loaded||settings.defaults(),needsRepair:!loaded};
      if(message.includeUiPreferences)response.uiPreferences=uiResponse({type:'getUiPreferences'});
      respond(response);
    } else if (type === 'save_settings' || type === 'saveSettings') {
      try {
        var selected=message.uiPreferences===undefined?null:preferences.normalize(message.uiPreferences);
        if(message.uiPreferences!==undefined&&(!selected||message.settings.dark!==(selected.lastExplicit==='dark')))throw Error('Invalid display preferences.');
        var saved=settings.save(storage,message.settings),response={ok:true,settings:saved};
        if(selected){response.uiPreferences=uiResponse({type:'saveUiPreferences',settings:selected});if(!response.uiPreferences.ok)throw Error('Display preferences were not saved.');}
        respond(response);
      }
      catch (error) { respond({ok:false, message:safeText(error && error.message || 'Settings were not saved.', 160)}); }
    } else if (type === 'catalogue') {
      var saved=metadata.load(storage);
      respond({ok:true,catalogue:saved||catalogue([]),cached:true,
        message:saved?'Saved provider list. Open Dashboard on your watch to refresh available plugins.':'Open Dashboard on your watch once to discover installed activity providers.'});
    } else if (type === 'inspect_source') {
      var source = message.source;
      if (!object(source) || typeof source.category !== 'string' || typeof source.item !== 'string' ||
          source.category.length > 64 || source.item.length > 64 || source.plugin !== undefined && !uuid(source.plugin) ||
          source.category === 'phone' && source.item === 'find_my_phone') {
        respond({ok:false, message:'This source cannot be inspected. Find phone is an action, not a reading.'}); return;
      }
      if (typeof pebble.readSource !== 'function') { respond({ok:false, message:'Source inspection is unavailable. You can keep the configured instance.'}); return; }
      try {
        var request = {category:source.category, item:source.item, properties:['name']};
        if (source.plugin) request.plugin = source.plugin;
        Promise.resolve(pebble.readSource(request)).then(function(envelope) {
          if (!envelope || !Array.isArray(envelope.instances) || !uuid(envelope.pluginUuid) || source.plugin && source.plugin.toLowerCase() !== envelope.pluginUuid.toLowerCase()) {
            respond({ok:false, message:'Source data is unavailable or came from a different plugin.'}); return;
          }
          respond({ok:true, instances:envelope.instances.slice(0, 128).filter(function(instance) { return instance && typeof instance.instanceId === 'string' && instance.instanceId.length <= 128 && !/[\u0000-\u001f]/.test(instance.instanceId); }).map(function(instance) {
            return {plugin:envelope.pluginUuid, category:source.category, item:source.item, instanceId:instance.instanceId, name:instanceName(instance), properties:Object.keys(instance.properties || {}).slice(0, 128)};
          })});
        }, function() { respond({ok:false, message:'Could not read instances. Check source permissions in Pebble.'}); });
      } catch (error) { respond({ok:false, message:'Could not read source instances.'}); }
    } else respond({ok:false, message:'Unknown settings request.'});
  });
}
if (typeof Pebble !== 'undefined') register(Pebble, localStorage);
module.exports = {register:register, catalogue:catalogue};
