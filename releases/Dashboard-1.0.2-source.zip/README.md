# Dashboard

A stock PebbleOS app showing a current activity, the latest notification and two configurable
pins.

## Store update 1.0.1

Current source prepares Dashboard 1.0.1 for the reviewed Store update. The new numeric version supersedes the existing public 1.0.0 binary without changing the public UUID. Its exact PBW, Store package, source and checksums are under `releases/`; earlier artifacts remain unchanged.

## Activities: see what is happening now

Activities are live updates shown by compatible XOCE apps and watchfaces, such as a countdown, music or a new notification. This feature connects compatible XOCE products; support depends on the app or watchface you choose.

Start a countdown in Timer and open Dashboard to see its activity in the overview. Hold Up to browse all available activities. Dashboard has its own activity order and does not pause or resume timers; open Timer to change the countdown.

Sharing needs plugin support in the official Pebble phone app, the required permissions and a connected phone. Weather and battery readings use separate reading settings. Music and notification integration requires Android. Open Activity is optional; you can always open Timer from the watch’s app list.

## Download

[Version 0.6.3](https://github.com/xefensor/pebble-app-dashboard/releases/tag/v0.6.3) is a development prerelease.

[PBW](https://github.com/xefensor/pebble-app-dashboard/releases/download/v0.6.3/Dashboard-0.6.3.pbw),
[source](https://github.com/xefensor/pebble-app-dashboard/releases/download/v0.6.3/Dashboard-0.6.3-source.zip),
[debug files](https://github.com/xefensor/pebble-app-dashboard/releases/download/v0.6.3/Dashboard-0.6.3-debug.zip), and
[checksums](https://github.com/xefensor/pebble-app-dashboard/releases/download/v0.6.3/SHA256SUMS.txt).

Install the PBW through the Pebble phone app. No separate library installation is needed.

Choose activity sources and pins in the phone settings. Each pin has separate reading, Select
action and Hold Select destination choices. Enable the permissions needed by your chosen
sources. Timer Pause/Resume from Dashboard remains deferred.

[Usage and controls](docs/USAGE.md) · [Current UI](docs/UI.md).

## Compatibility

The release candidate targets **Pebble Time 2 / Emery** and **Round 2 / Gabbro**, using **Pebble SDK 4.44**. Duo is deferred. Portable and
emulator evidence is versioned; physical phone/watch checks retain their documented gaps.
Existing screenshots keep their original version and provenance.

## Setup and use

Install the PBW, connect the phone and configure sources and pins in its settings. Tap Select for the declared action, hold Select for the exact associated app, and hold Up/Down from Snapshot for Activities/Pinned. See [controls and safety rules](docs/UI.md).

The version notes below describe the published download. Development candidates
remain separate; use [CONTRIBUTING](CONTRIBUTING.md) for local builds.

## Version 0.6.3

- Adopt shared XOCE headers, readable rows, full-height action rails, icons and stock Pebble action-bar feedback.
- Keep immediate selection, complete first-use help, safe Cancel-first confirmations and exact tap/hold action bindings.
- Bundle UI 0.1.1 and the confirmed stay-open phone settings page.

## Version 1.0.0 — stable release preparation

Add Time 2 and Round 2 SDK 4.44 builds, compact overview fitting and current permission disclosures.

Xef accepted the reviewed implementation for stable release preparation on 2026-11-13. Actual test coverage remains recorded separately; no physical-device result is implied. Publication is a separate step.

## Development

Use Node 22, Python 3.12 and a C compiler. SDK builds additionally need Pebble SDK 4.44 on
PATH.

```sh
npm ci --ignore-scripts
npm test
npm run build
npm run check:artifact
```

[Contributor guide](CONTRIBUTING.md) · [Release preparation](docs/RELEASING.md) · [History index](docs/history/index.md).
Development outputs belong in ignored `build/`; published archives stay frozen.

## Licence

[PolyForm Noncommercial 1.0.0](LICENSE). Preserve bundled third-party notices and attribution.

The development checkout supports English, Czech, Slovak, German, French, Spanish,
Italian, Portuguese, Dutch, Polish, Danish, Swedish, Norwegian, Finnish, Hungarian,
Romanian and Turkish on watch screens and phone settings. Watch text follows the
watch language; settings follow the phone language. Regional locale codes and
Norwegian nb/nn are accepted; unsupported languages use English. Provider text,
user labels and saved bindings keep their original values. Frozen release downloads
retain their original language coverage until a new release is published.
